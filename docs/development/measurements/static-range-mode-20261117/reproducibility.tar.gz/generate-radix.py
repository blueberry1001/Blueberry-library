from pathlib import Path
p=Path(__file__).parent
s=(p/'cached.hpp').read_text().replace('#include <utility>','#include <utility>\n#include <type_traits>')
start=s.index('  std::vector<T> values = a;');end=s.index('  std::iota(order.begin(), order.end(), 0);',start)
before=s[:start];after=s[end:]
compression='''  std::vector<int> rank(n), representative, order(q);
  int m = 0;
  if constexpr (std::is_integral_v<T> && !std::is_same_v<T, bool>) {
    using U = std::make_unsigned_t<T>;
    std::vector<int> idx(n), tmp(n);
    std::iota(idx.begin(), idx.end(), 0);
    constexpr int digits = std::numeric_limits<U>::digits;
    constexpr U sign = std::is_signed_v<T> ? U(U(1) << (digits - 1)) : U(0);
    for (int shift = 0; shift < digits; shift += 8) {
      int count[256] = {};
      for (int i : idx) ++count[((U(a[i]) ^ sign) >> shift) & 255];
      int offset = 0;
      for (int& c : count) { int k = c; c = offset; offset += k; }
      for (int i : idx) tmp[count[((U(a[i]) ^ sign) >> shift) & 255]++] = i;
      idx.swap(tmp);
    }
    for (int i = 0; i < n; ++i) {
      if (!i || a[idx[i]] != a[idx[i - 1]]) { representative.push_back(idx[i]); ++m; }
      else representative.back() = idx[i];
      rank[idx[i]] = m - 1;
    }
  } else {
    std::vector<T> values = a;
    std::sort(values.begin(), values.end());
    values.erase(std::unique(values.begin(), values.end()), values.end());
    m = static_cast<int>(values.size());
    representative.resize(m);
    for (int i = 0; i < n; ++i) {
      rank[i] = static_cast<int>(std::lower_bound(values.begin(), values.end(), a[i]) - values.begin());
      representative[rank[i]] = i;
    }
  }
'''
(p/'radix.hpp').write_text(before+compression+after,newline='\n')
