#pragma once
#include <algorithm>
#include <cassert>
#include <cmath>
#include <numeric>
#include <limits>
#include <utility>
#include <type_traits>
#include <vector>

namespace blueberry {
// Each result is {a representative input index of a mode value, its frequency}.
// The representative may be outside the queried interval; empty returns {-1, 0}.
template <class T>
std::vector<std::pair<int, int>> static_range_mode(
    const std::vector<T>& a, const std::vector<std::pair<int, int>>& queries) {
  assert(a.size() < static_cast<std::size_t>(std::numeric_limits<int>::max()));
  assert(queries.size() <= static_cast<std::size_t>(std::numeric_limits<int>::max()));
  const int n = static_cast<int>(a.size()), q = static_cast<int>(queries.size());
  for ([[maybe_unused]] auto [l, r] : queries) assert(0 <= l && l <= r && r <= n);
  std::vector<int> rank(n), representative, order(q);
  int m = 0;
  if constexpr (std::is_integral_v<T> && !std::is_same_v<T, bool>) {
    using U = std::make_unsigned_t<T>;
    std::vector<int> idx(n), tmp(n);
    std::iota(idx.begin(), idx.end(), 0);
    constexpr int digits = std::numeric_limits<U>::digits;
    constexpr U sign = std::is_signed_v<T> ? U(U(1) << (digits - 1)) : U(0);
    for (int shift = 0; shift < digits; shift += 8) {
      int count[256] = {};
      for (int i : idx) ++count[((U(a[i]) ^ sign) >> shift) & 255];
      int offset = 0;
      for (int& c : count) { int k = c; c = offset; offset += k; }
      for (int i : idx) tmp[count[((U(a[i]) ^ sign) >> shift) & 255]++] = i;
      idx.swap(tmp);
    }
    for (int i = 0; i < n; ++i) {
      if (!i || a[idx[i]] != a[idx[i - 1]]) { representative.push_back(idx[i]); ++m; }
      else representative.back() = idx[i];
      rank[idx[i]] = m - 1;
    }
  } else {
    std::vector<T> values = a;
    std::sort(values.begin(), values.end());
    values.erase(std::unique(values.begin(), values.end()), values.end());
    m = static_cast<int>(values.size());
    representative.resize(m);
    for (int i = 0; i < n; ++i) {
      rank[i] = static_cast<int>(std::lower_bound(values.begin(), values.end(), a[i]) - values.begin());
      representative[rank[i]] = i;
    }
  }
  std::iota(order.begin(), order.end(), 0);
  const int block = std::max(1, static_cast<int>(n / std::sqrt(static_cast<double>(std::max(1, q)))));
  std::vector<int> blocks(q);
  for (int i = 0; i < q; ++i) blocks[i] = queries[i].first / block;
  std::sort(order.begin(), order.end(), [&](int x, int y) {
    int bx = blocks[x], by = blocks[y];
    if (bx != by) return bx < by;
    return (bx & 1) ? queries[x].second > queries[y].second : queries[x].second < queries[y].second;
  });
  std::vector<int> count(m), head(n + 1, -1), prev(m, -1), next(m, -1);
  int maximum = 0;
  auto change = [&](int x, int delta) {
    int f = count[x];
    if (f) {
      if (prev[x] == -1) head[f] = next[x]; else next[prev[x]] = next[x];
      if (next[x] != -1) prev[next[x]] = prev[x];
    }
    f = (count[x] += delta);
    if (f) {
      prev[x] = -1; next[x] = head[f];
      if (head[f] != -1) prev[head[f]] = x;
      head[f] = x;
    }
    maximum = std::max(maximum, f);
    if (maximum && head[maximum] == -1) --maximum;
  };
  std::vector<std::pair<int, int>> answer(q);
  int l = 0, r = 0;
  for (int id : order) {
    auto [ql, qr] = queries[id];
    while (l > ql) change(rank[--l], 1);
    while (r < qr) change(rank[r++], 1);
    while (l < ql) change(rank[l++], -1);
    while (r > qr) change(rank[--r], -1);
    answer[id] = {maximum ? representative[head[maximum]] : -1, maximum};
  }
  return answer;
}
}  // namespace blueberry
