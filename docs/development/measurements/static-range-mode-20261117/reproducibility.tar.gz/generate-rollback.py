from pathlib import Path
p=Path(__file__).parent
for original,name in [('cached.hpp','rollback.hpp'),('radix.hpp','rollback-radix.hpp')]:
 s=(p/original).read_text()
 start=s.index('  std::iota(order.begin(), order.end(), 0);')
 s=s[:start]+'''  std::iota(order.begin(), order.end(), 0);
  const int block = std::max(1, static_cast<int>(n / std::sqrt(static_cast<double>(std::max(1, q)))));
  std::vector<int> blocks(q);
  for (int i = 0; i < q; ++i) blocks[i] = queries[i].first / block;
  std::sort(order.begin(), order.end(), [&](int x, int y) {
    if (blocks[x] != blocks[y]) return blocks[x] < blocks[y];
    return queries[x].second < queries[y].second;
  });
  std::vector<int> count(m);
  std::vector<std::pair<int, int>> answer(q);
  int current_block = -1, end = 0, right = 0, best = -1, maximum = 0;
  auto add = [&](int index) {
    int x = rank[index], f = ++count[x];
    if (f > maximum) { maximum = f; best = x; }
  };
  for (int id : order) {
    auto [left, qr] = queries[id];
    if (current_block != blocks[id]) {
      for (int i = end; i < right; ++i) count[rank[i]] = 0;
      current_block = blocks[id];
      end = static_cast<int>(std::min(static_cast<long long>(n), (static_cast<long long>(current_block) + 1) * block));
      right = end; best = -1; maximum = 0;
    }
    if (qr <= end) {
      for (int i = left; i < qr; ++i) add(i);
      answer[id] = {maximum ? representative[best] : -1, maximum};
      for (int i = left; i < qr; ++i) --count[rank[i]];
      best = -1; maximum = 0;
    } else {
      while (right < qr) add(right++);
      int saved_best = best, saved_maximum = maximum;
      for (int i = left; i < end; ++i) add(i);
      answer[id] = {maximum ? representative[best] : -1, maximum};
      for (int i = left; i < end; ++i) --count[rank[i]];
      best = saved_best; maximum = saved_maximum;
    }
  }
  return answer;
}
}  // namespace blueberry
'''
 (p/name).write_text(s,newline='\n')
