#include <algorithm>
#include <cassert>
#include <iostream>
#include <map>
#include <random>
#include <string>
#include <vector>
#define blueberry rollback
#include "rollback.hpp"
#undef blueberry
#define blueberry rollback_radix
#include "rollback-radix.hpp"
#undef blueberry
#define blueberry final_candidate
#include "final.hpp"
#undef blueberry
using namespace std;
template<class T> void test(const vector<T>& a, const vector<pair<int,int>>& q) {
  auto b=rollback::static_range_mode(a,q), c=rollback_radix::static_range_mode(a,q), d=final_candidate::static_range_mode(a,q);
  for(int id=0;id<(int)q.size();++id){
    auto [l,r]=q[id]; map<T,int> counts;int m=0;
    for(int j=l;j<r;++j) m=max(m,++counts[a[j]]);
    for(auto ans:{b[id],c[id],d[id]}){if(ans.second!=m||(!m&&ans.first!=-1)||(m&&(ans.first<0||ans.first>=(int)a.size()||counts[a[ans.first]]!=m))){cerr<<"failure n="<<a.size()<<" l="<<l<<" r="<<r<<" got="<<ans.first<<","<<ans.second<<" expected="<<m<<'\n';exit(1);}}
  }
}
int main() {
 mt19937_64 rng(399921);
 for(int n=0;n<=110;++n) for(int rep=0;rep<12;++rep){
  vector<int>a(n);vector<long long>b(n);vector<string>c(n);vector<bool>d(n);
  for(int i=0;i<n;++i){auto x=rng();a[i]=int(x%13)-6;b[i]=(x&1)?(long long)x:(long long)(x%13)-6;c[i]=to_string(a[i]);d[i]=x&1;}
  vector<pair<int,int>>q;for(int i=0;i<600;++i){int l=rng()%(n+1),r=rng()%(n+1);if(l>r)swap(l,r);q.push_back({l,r});}
  test(a,q);test(b,q);test(c,q);test(d,q);
  if (rep==0) {
    vector<int> unique(n),same(n,42),binary(n);
    for(int i=0;i<n;++i){unique[i]=i;binary[i]=i%2;}
    test(unique,q);test(same,q);test(binary,q);
    test(a,{});
    if(n>=3) test(vector<int>{4,2,4,4},{{0,1},{1,2},{0,0},{3,4}});
  }
 }
 cout<<"OK seed=399921 types=int,int64,string,bool\n";
}
