from pathlib import Path
p=Path(__file__).parent
s=(p/'driver.cpp').read_text().replace('#undef blueberry\nusing namespace std;', '#undef blueberry\n#define blueberry rollback\n#include "rollback.hpp"\n#undef blueberry\n#define blueberry rollback_radix\n#include "rollback-radix.hpp"\n#undef blueberry\nusing namespace std;')
s=s.replace('  return cached::static_range_mode(a,q);','  if (variant==3) return cached::static_range_mode(a,q);\n  if (variant==4) return rollback::static_range_mode(a,q);\n  return rollback_radix::static_range_mode(a,q);')
(p/'driver2.cpp').write_text(s,newline='\n')
r=(p/'run.py').read_text().replace("'driver.cpp'","'driver2.cpp'").replace("('baseline','adaptive','nyaan-order','cached')","('baseline','adaptive','nyaan-order','cached','rollback','rollback-radix')").replace("'results.json'","'results2.json'").replace('range(4)','range(6)').replace('rep%4','rep%6').replace("compiler+'.exe'","compiler+'2.exe'")
(p/'run2.py').write_text(r,newline='\n')
