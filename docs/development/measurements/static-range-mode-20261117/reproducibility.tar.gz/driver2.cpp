#include <algorithm>
#include <cassert>
#include <chrono>
#include <iostream>
#include <map>
#include <random>
#include <string>
#include <vector>
#define blueberry baseline
#include "baseline.hpp"
#undef blueberry
#define blueberry adaptive
#include "adaptive.hpp"
#undef blueberry
#define blueberry nyaan_order
#include "nyaan-order.hpp"
#undef blueberry
#define blueberry cached
#include "cached.hpp"
#undef blueberry
#define blueberry rollback
#include "rollback.hpp"
#undef blueberry
#define blueberry rollback_radix
#include "rollback-radix.hpp"
#undef blueberry
using namespace std;
using Query = pair<int,int>;
template<class T> auto solve(int variant,const vector<T>&a,const vector<Query>&q) {
  if (variant==0) return baseline::static_range_mode(a,q);
  if (variant==1) return adaptive::static_range_mode(a,q);
  if (variant==2) return nyaan_order::static_range_mode(a,q);
  if (variant==3) return cached::static_range_mode(a,q);
  if (variant==4) return rollback::static_range_mode(a,q);
  return rollback_radix::static_range_mode(a,q);
}
int main(int argc,char**argv) {
  int variant=stoi(argv[1]), n=stoi(argv[2]), q=stoi(argv[3]), shape=stoi(argv[4]);
  mt19937 rng(720437);
  vector<int>a(n); for(int&i:a) i=int(rng()% (shape==1?20:100000));
  vector<Query> qs(q);
  for(auto&[l,r]:qs) { l=int(rng()%(n+1));r=int(rng()%(n+1));if(l>r) swap(l,r); if(shape==2) r=min(n,l+int(rng()%200)); }
  auto start=chrono::steady_clock::now();auto answers=solve(variant,a,qs);auto end=chrono::steady_clock::now();
  unsigned long long sum=0;for(auto [i,f]:answers){sum+=f;if(i<0&&f!=0)return 2;}
  cout<<chrono::duration<double,milli>(end-start).count()<<' '<<sum<<'\n';
}
