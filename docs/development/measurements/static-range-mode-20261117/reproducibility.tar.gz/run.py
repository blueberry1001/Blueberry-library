import hashlib,json,os,platform,statistics,subprocess,sys
from pathlib import Path
here=Path(__file__).resolve().parent
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=Path(r'C:\Program Files (x86)\Windows Kits\10'); ver='10.0.22621.0'
msvc=vc/'bin/Hostx64/x64/cl.exe'
clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(msvc.parent)+os.pathsep+env.get('PATH','')
env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/ver/p for p in ('ucrt','shared','um'))]))
env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/ver/p/'x64' for p in ('ucrt','um'))]))
cases=[(50000,100,0),(50000,3000,0),(50000,50000,0),(50000,200000,0),(50000,50000,1),(50000,50000,2)]
out={'status':'running','platform':platform.platform(),'warmups':1,'runs':5,'cpu_pinned':False,'cases':cases,'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [here/'driver.cpp',*(here/(n+'.hpp') for n in ('baseline','adaptive','nyaan-order','cached'))]},'rows':[]}
def save():(here/'results.json').write_text(json.dumps(out,indent=2)+'\n')
try:
 for compiler in ['clang','msvc']:
  exe=here/(compiler+'.exe')
  if compiler=='clang': cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG',str(here/'driver.cpp'),'-o',str(exe)]
  else: cmd=[str(msvc),'/nologo','/std:c++20','/EHsc','/O2','/DNDEBUG',str(here/'driver.cpp'),'/Fo'+str(here/'build.obj'),'/Fe'+str(exe)]
  pr=subprocess.run(cmd,cwd=here,env=env,capture_output=True,text=True,errors='replace'); row={'compiler':compiler,'command':cmd,'compile_exit':pr.returncode,'compile_output':pr.stdout+pr.stderr,'samples':[]};out['rows'].append(row);save()
  if pr.returncode: raise RuntimeError('compile failed '+compiler)
  for n,q,shape in cases:
   checksums=set()
   for rep in range(-1,5):
    order=list(range(4));order=order[rep%4:]+order[:rep%4]
    for var in order:
     pr=subprocess.run([str(exe),str(var),str(n),str(q),str(shape)],cwd=here,env=env,capture_output=True,text=True,errors='replace',timeout=120)
     if pr.returncode: raise RuntimeError('run failed: '+pr.stdout+pr.stderr)
     ms,checksum=pr.stdout.strip().split();checksums.add(checksum)
     row['samples'].append({'n':n,'q':q,'shape':shape,'rep':rep,'variant':var,'ms':float(ms),'checksum':checksum});save()
    if len(checksums)!=1: raise RuntimeError('checksum mismatch '+repr(checksums))
   print(compiler,n,q,shape,[round(statistics.median(x['ms'] for x in row['samples'] if x['q']==q and x['shape']==shape and x['variant']==v and x['rep']>=0),3) for v in range(4)],flush=True)
 out['status']='complete'
except BaseException as e:
 out['status']='failed';out['error']=repr(e);save();raise
save()
