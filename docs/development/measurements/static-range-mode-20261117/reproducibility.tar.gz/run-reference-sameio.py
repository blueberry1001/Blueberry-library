import hashlib,json,os,statistics,subprocess,time
from pathlib import Path
p=Path(__file__).parent;tmp=p/'official-tmp';vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');ver='10.0.22621.0';cl=vc/'bin/Hostx64/x64/cl.exe';clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(cl.parent)+os.pathsep+env.get('PATH','');env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/ver/x for x in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/ver/x/'x64' for x in ('ucrt','um'))]))
s=(tmp/'correct.cpp').read_text(encoding='utf-8');s='#include <iostream>\n'+s
for old,new in [('scanf("%d %d", &N, &Q);','std::cin >> N >> Q;'),('scanf("%d", &A[i]);','std::cin >> A[i];'),('scanf("%d %d", &L, &R);','std::cin >> L >> R;'),('printf("%d %d\\n", a, b);','std::cout << a << \' \' << b << \'\\n\';'),('signed main() {','signed main() { std::ios::sync_with_stdio(false); std::cin.tie(nullptr);')]:
 assert s.count(old)==1,(old,s.count(old));s=s.replace(old,new)
(p/'official-sameio.cpp.txt').write_text(s,encoding='utf-8',newline='\n');(tmp/'sameio.cpp').write_text(s,encoding='utf-8',newline='\n')
cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG',str(tmp/'sameio.cpp'),'-o',str(tmp/'sameio.exe')];a=subprocess.run(cmd,cwd=tmp,env=env,capture_output=True,text=True,errors='replace')
out={'status':'running','compile_command':cmd,'compile_exit':a.returncode,'compile_output':a.stdout+a.stderr,'warning':'CPU not pinned; external load unknown','samples':[]}
def save():(p/'reference-sameio.json').write_text(json.dumps(out,indent=2)+'\n')
try:
 if a.returncode:raise RuntimeError('compile failed')
 for seed in (3,4,5):
  inp=tmp/'sameio-input.txt'
  with inp.open('wb') as dst:r=subprocess.run([str(tmp/'random.exe'),str(seed)],stdout=dst,stderr=subprocess.PIPE,cwd=tmp,env=env)
  if r.returncode:raise RuntimeError('generation failed')
  cases=json.loads((p/'official-results.json').read_text())['cases'];expected_hash=next(x['input_sha256'] for x in cases if x['name']=='random' and x['seed']==seed)
  if hashlib.sha256(inp.read_bytes()).hexdigest()!=expected_hash:raise RuntimeError('input hash mismatch')
  for rep in range(-1,5):
   names=['baseline','candidate','sameio'];names=names[rep%3:]+names[:rep%3]
   for name in names:
    start=time.perf_counter()
    with inp.open('rb') as src,(tmp/(name+'-sameio.out')).open('wb') as dst:r=subprocess.run([str(tmp/(name+'.exe'))],stdin=src,stdout=dst,stderr=subprocess.PIPE,cwd=tmp,env=env,timeout=120)
    out['samples'].append({'seed':seed,'rep':rep,'variant':name,'ms':(time.perf_counter()-start)*1000,'exit':r.returncode,'stderr':r.stderr.decode(errors='replace')});save()
    if r.returncode:raise RuntimeError('run failed')
  with inp.open('rb') as src,(tmp/'correct-sameio.out').open('wb') as dst:r=subprocess.run([str(tmp/'correct.exe')],stdin=src,stdout=dst,stderr=subprocess.PIPE,cwd=tmp,env=env,timeout=120)
  if r.returncode or (tmp/'sameio-sameio.out').read_bytes() != (tmp/'correct-sameio.out').read_bytes():raise RuntimeError('reference outputs differ')
  out.setdefault('validated',[]).append({'seed':seed,'input_sha256':expected_hash,'reference_matches_official':True});save()
  print(seed,{name:round(statistics.median(x['ms'] for x in out['samples'] if x['seed']==seed and x['variant']==name and x['rep']>=0),2) for name in ['baseline','candidate','sameio']},flush=True)
 out['status']='complete'
except BaseException as e:out['status']='failed';out['error']=repr(e);raise
finally:save()
