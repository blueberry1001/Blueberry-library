from pathlib import Path
p = Path(__file__).parent
s = (p/'baseline.hpp').read_text()
old = '  const int block = std::max(1, static_cast<int>(std::sqrt(std::max(1, n))));'
assert s.count(old) == 1
for name, width, cached in [('adaptive','std::max(1, static_cast<int>(n / std::sqrt(static_cast<double>(std::max(1, q)))))',False),('nyaan-order','std::max(1, static_cast<int>(n / std::max(1.0, std::sqrt(q * (2.0 / 3.0)))))',False),('cached','std::max(1, static_cast<int>(n / std::sqrt(static_cast<double>(std::max(1, q)))))',True)]:
    t=s.replace(old, '  const int block = '+width+';')
    if cached:
        t=t.replace('  std::sort(order.begin(), order.end(), [&](int x, int y) {\n    int bx = queries[x].first / block, by = queries[y].first / block;', '  std::vector<int> blocks(q);\n  for (int i = 0; i < q; ++i) blocks[i] = queries[i].first / block;\n  std::sort(order.begin(), order.end(), [&](int x, int y) {\n    int bx = blocks[x], by = blocks[y];')
    (p/(name+'.hpp')).write_text(t, newline='\n')
