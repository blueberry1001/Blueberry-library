from pathlib import Path
p=Path(__file__).parent
s=(p/'rollback-radix.hpp').read_text().replace('#include <cassert>\n','')
s=s.replace('// Each result is {a representative input index of a mode value, its frequency}.\n// The representative may be outside the queried interval; empty returns {-1, 0}.\n','').replace('}  // namespace blueberry','}')
s=s.replace('  assert(a.size() < static_cast<std::size_t>(std::numeric_limits<int>::max()));\n  assert(queries.size() <= static_cast<std::size_t>(std::numeric_limits<int>::max()));\n','')
s=s.replace('  for ([[maybe_unused]] auto [l, r] : queries) assert(0 <= l && l <= r && r <= n);\n','  if (!q) return {};\n')
marker='  std::iota(order.begin(), order.end(), 0);'
assert s.count(marker)==1
s=s.replace(marker,'''  if (m <= 2 || m == n) {
    std::vector<std::pair<int, int>> answer(q, {-1, 0});
    if (m == 2 && m != n) {
      std::vector<int> prefix(n + 1);
      for (int i = 0; i < n; ++i) prefix[i + 1] = prefix[i] + (rank[i] == 0);
      for (int i = 0; i < q; ++i) {
        auto [l, r] = queries[i]; int x = prefix[r] - prefix[l], y = r - l - x;
        if (x || y) answer[i] = x >= y ? std::pair{representative[0], x} : std::pair{representative[1], y};
      }
    } else for (int i = 0; i < q; ++i) {
      auto [l, r] = queries[i];
      if (l != r) answer[i] = m == 1 ? std::pair{representative[0], r - l} : std::pair{l, 1};
    }
    return answer;
  }
''' +marker)
(p/'final.hpp').write_text(s,newline='\n')
