#pragma once
#include <atcoder/math>
#include <bit>
#include <cmath>
#include <cstdint>
#include <numeric>
#include <optional>
#include <vector>

namespace blueberry {
inline std::optional<std::int64_t> discrete_log(std::int64_t a, std::int64_t b, std::int64_t m) {
  a %= m; b %= m;
  if (a < 0) a += m;
  if (b < 0) b += m;
  std::int64_t factor = 1 % m, offset = 0;
  while (true) {
    if (b == factor) return offset;
    auto g = std::gcd(a, m);
    if (g == 1) break;
    if (b % g != 0) return std::nullopt;
    b /= g; m /= g;
    factor = factor * (a / g) % m;
    ++offset;
  }
  if (std::gcd(b, m) != 1) return std::nullopt;
  a %= m;
  b = b * atcoder::inv_mod(factor, m) % m;
  atcoder::internal::barrett mod(static_cast<unsigned int>(m));
  const auto base = static_cast<unsigned int>(a), target = static_cast<unsigned int>(b);
  unsigned int power = 1;
  for (int j = 0; j < 32; ++j) {
    if (power == target) return offset + j;
    if (j && power == 1) return std::nullopt;
    power = mod.mul(power, base);
  }
  const unsigned int width = static_cast<unsigned int>(std::sqrt(m)) + 1;
  const unsigned int capacity = std::bit_ceil(width * 2), mask = capacity - 1;
  const int shift = 64 - std::countr_zero(capacity);
  std::vector<std::uint64_t> table(capacity);
  auto hash = [shift](unsigned int x) { return static_cast<unsigned int>((x * 0x9e3779b97f4a7c15ULL) >> shift); };
  power = 1;
  for (unsigned int j = 0; j < width; ++j) {
    if (power == target) return offset + j;
    if (j && power == 1) return std::nullopt;
    auto slot = hash(power);
    while (table[slot]) slot = (slot + 1) & mask;
    table[slot] = (std::uint64_t(power) << 32) | j;
    power = mod.mul(power, base);
  }
  const auto step = static_cast<unsigned int>(atcoder::inv_mod(power, m));
  unsigned int cur = target;
  for (unsigned int i = 1; i <= width; ++i) {
    cur = mod.mul(cur, step);
    auto slot = hash(cur);
    while (table[slot] && (table[slot] >> 32) != cur) slot = (slot + 1) & mask;
    if (table[slot]) return offset + std::int64_t(i) * width + static_cast<unsigned int>(table[slot]);
  }
  return std::nullopt;
}
}
