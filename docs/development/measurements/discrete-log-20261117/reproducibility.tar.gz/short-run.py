import ctypes,json,os,pathlib,subprocess,time,traceback
r=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10');v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
acl=pathlib.Path(r'C:\Users\kubar\Documents\GitHub\Blueberry-library\.deps\ac-library')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/p for p in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/p/'x64' for p in ('ucrt','um'))]))
k=ctypes.WinDLL('kernel32');k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<16)
log={'runs':[]}
def call(cmd):
 start=time.perf_counter();p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,text=True,errors='replace',timeout=300)
 item={'cmd':list(map(str,cmd)),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'wall_seconds':time.perf_counter()-start};log['runs'].append(item);(r/'short-results.json').write_text(json.dumps(log,indent=2))
 if p.returncode:raise RuntimeError(item)
try:
 for n in (32,128,512):(r/f'ph{n}.hpp').write_text((r/'discrete-log-ph.hpp').read_text().replace('j<512','j<'+str(n)))
 exe=r/'short.exe';call([clang,'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG','-I',acl,r/'short.cpp','-o',exe])
 for kind in range(4):
  for rep in range(3):
   for impl in ((0,1,2) if rep%2==0 else (2,1,0)):call([exe,str(kind),str(impl)])
 log['status']='complete';(r/'short-results.json').write_text(json.dumps(log,indent=2))
except BaseException:
 log['status']='failed';log['traceback']=traceback.format_exc();(r/'short-results.json').write_text(json.dumps(log,indent=2));raise
