#include <chrono>
#include <cstdlib>
#include <cstdint>
#include <iostream>
#include <random>
#include <vector>
#define blueberry ph32
#include "ph32.hpp"
#undef blueberry
#define blueberry ph128
#include "ph128.hpp"
#undef blueberry
#define blueberry ph512
#include "ph512.hpp"
#undef blueberry
struct Q { int a,b,m; };
int main(int argc,char** argv) {
  int kind=std::atoi(argv[1]), impl=std::atoi(argv[2]);
  std::mt19937_64 rng(132841);std::vector<Q> q;
  for(int i=0;i<2000;++i) {
    int m=(i&1)?998244353:1000000007,a=2+rng()%(m-2);
    unsigned e=kind==0?rng()%32:kind==1?32+rng()%96:kind==2?128+rng()%384:1000+rng()%100000000;
    long long b=1,v=a;for(;e;e>>=1,v=v*v%m)if(e&1)b=b*v%m;
    q.push_back({a,int(b),m});
  }
  auto t=std::chrono::steady_clock::now();long long sum=0;
  for(auto [a,b,m]:q)sum+=(impl==0?ph32::discrete_log(a,b,m):impl==1?ph128::discrete_log(a,b,m):ph512::discrete_log(a,b,m)).value_or(-1);
  std::cout<<kind<<' '<<impl<<' '<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t).count()<<' '<<sum<<'\n';
}
