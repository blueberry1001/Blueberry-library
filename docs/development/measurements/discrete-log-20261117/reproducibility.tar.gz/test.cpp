#include <algorithm>
#include <cstdint>
#include <iostream>
#include <limits>
#include <random>
#include <vector>
#define blueberry before
#include "baseline.hpp"
#undef blueberry
#include "discrete-log.hpp"
int main() {
  for (int m = 1; m <= 250; ++m) for (int a = 0; a < m; ++a) {
    std::vector<int> answer(m, -1);
    int x = 1 % m;
    for (int t = 0; answer[x] == -1; ++t, x = int(1LL*x*a % m)) answer[x] = t;
    for (int b = 0; b < m; ++b) for (int d = 0; d < 2; ++d) {
      auto r = blueberry::discrete_log(a - d*m, b - d*m, m).value_or(-1);
      if (r != answer[b]) { std::cerr << a << ' ' << b << ' ' << m << ' ' << r << ' ' << answer[b] << '\n'; return 1; }
    }
  }
  std::mt19937_64 rng(891724);
  for (int i=0; i<20000; ++i) {
    const int m = 1 + int(rng()%2000000), a = int(rng()%m), b = int(rng()%m);
    auto x = before::discrete_log(a,b,m), y = blueberry::discrete_log(a,b,m);
    if (x != y) { std::cerr << a << ' ' << b << ' ' << m << '\n'; return 2; }
  }
  const std::int64_t lo = std::numeric_limits<std::int64_t>::min(), hi = std::numeric_limits<std::int64_t>::max();
  for (auto a : {lo, hi, std::int64_t(-1), std::int64_t(0), std::int64_t(1)})
    for (auto b : {lo, hi, std::int64_t(-1), std::int64_t(0), std::int64_t(1)})
      for (auto m : {1,2,3,4,6,97,1000000007,2147483647})
        if (before::discrete_log(a,b,m) != blueberry::discrete_log(a,b,m)) return 3;
  std::cout << "exhaustive+random+limits passed\n";
}
