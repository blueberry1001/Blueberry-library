import ctypes, json, os, pathlib, subprocess, time, traceback
r=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10'); v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
acl=pathlib.Path(r'C:\Users\kubar\Documents\GitHub\Blueberry-library\.deps\ac-library')
env=os.environ.copy(); env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH']; env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/p for p in ('ucrt','shared','um'))])); env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/p/'x64' for p in ('ucrt','um'))]))
k=ctypes.WinDLL('kernel32',use_last_error=True); k.GetCurrentProcess.restype=ctypes.c_void_p
k.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]; k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
p=k.GetCurrentProcess(); old=ctypes.c_size_t(); system=ctypes.c_size_t(); assert k.GetProcessAffinityMask(p,ctypes.byref(old),ctypes.byref(system)); mask=1<<16; assert old.value&mask; assert k.SetProcessAffinityMask(p,mask)
log={'affinity':hex(mask),'runs':[]}
def save(): (r/'results.json').write_text(json.dumps(log,indent=2)+'\n')
def call(cmd):
    start=time.perf_counter(); p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,text=True,errors='replace',timeout=400)
    result={'cmd':list(map(str,cmd)),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'wall_seconds':time.perf_counter()-start};log['runs'].append(result);save()
    if p.returncode: raise RuntimeError(result)
try:
 for cc in ('clang','msvc'):
  for std in ('20','23'):
   for release in (False,True):
    exe=r/f'test-{cc}-{std}-{release}.exe'
    if cc=='clang': cmd=[clang,'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++'+std,'-O2',*(['-DNDEBUG'] if release else []),'-I',acl,r/'test.cpp','-o',exe]
    else: cmd=[vc/'bin/Hostx64/x64/cl.exe','/nologo','/std:'+('c++20' if std=='20' else 'c++latest'),'/O2',*(['/DNDEBUG'] if release else []),'/EHsc','/I'+str(acl),r/'test.cpp','/Fe:'+str(exe)]
    call(cmd);call([exe])
 for cc in ('clang','msvc'):
  exe=r/f'bench-{cc}.exe'
  if cc=='clang': cmd=[clang,'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG','-I',acl,r/'bench.cpp','-o',exe]
  else:cmd=[vc/'bin/Hostx64/x64/cl.exe','/nologo','/std:c++20','/O2','/DNDEBUG','/EHsc','/I'+str(acl),r/'bench.cpp','/Fe:'+str(exe)]
  call(cmd)
  for kind in range(5):
   for repeat in range(5):
    for impl in ((0,1) if repeat%2==0 else (1,0)): call([exe,str(kind),str(impl)])
 log['status']='complete';save()
except BaseException:
 log['status']='failed';log['traceback']=traceback.format_exc();save();raise
