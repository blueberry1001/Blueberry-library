import ctypes,hashlib,json,os,pathlib,subprocess,time,traceback
r=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10');v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
acl=pathlib.Path(r'C:\Users\kubar\Documents\GitHub\Blueberry-library\.deps\ac-library')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/p for p in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/p/'x64' for p in ('ucrt','um'))]))
k=ctypes.WinDLL('kernel32');k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<16)
log={'runs':[]}
def call(cmd,**kw):
 start=time.perf_counter();p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,timeout=300,**kw)
 item={'cmd':list(map(str,cmd)),'exit':p.returncode,'stderr':p.stderr.decode(errors='replace'),'wall_seconds':time.perf_counter()-start,'out_sha256':hashlib.sha256(p.stdout).hexdigest()}
 log['runs'].append(item);(r/'official-results.json').write_text(json.dumps(log,indent=2))
 if p.returncode:raise RuntimeError(item)
 return p.stdout
common=[clang,'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG']
try:
 exe=r/'official-solve.exe';call(common+['-I',acl,r/'official-solve.cpp','-o',exe])
 cases=[('example',0,(r/'official/example_00.in').read_bytes())]
 for name,count in [('small',3),('random',3),('max_random',3),('even_mod',2),('even_mod_impossible',2),('max_random_yes',2),('max_random_yes_prime',2),('random_prime',2)]:
  gen=r/('official-'+name+'.exe');call(common+[r/'official'/f'{name}.cpp','-o',gen])
  for seed in range(count):cases.append((name,seed,call([gen,str(seed)])))
 for name,seed,data in cases:
  outputs=[]
  for mode in range(3):outputs.append(call([exe,str(mode)],input=data))
  if len(set(outputs))!=1:raise RuntimeError(f'mismatch {name} {seed}')
  log.setdefault('cases',[]).append({'name':name,'seed':seed,'input_sha256':hashlib.sha256(data).hexdigest(),'output_sha256':hashlib.sha256(outputs[0]).hexdigest()})
 log['status']='complete';(r/'official-results.json').write_text(json.dumps(log,indent=2))
except BaseException:
 log['status']='failed';log['traceback']=traceback.format_exc();(r/'official-results.json').write_text(json.dumps(log,indent=2));raise
