#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <random>
#include <vector>
#define blueberry before
#include "baseline.hpp"
#undef blueberry
#include "discrete-log.hpp"
struct Q { int a,b,m; };
int main(int argc,char** argv) {
  int kind=std::atoi(argv[1]), impl=std::atoi(argv[2]);
  std::mt19937_64 rng(325463);
  std::vector<Q> q;
  for(int i=0;i<200;++i) {
    int m=kind==0?1000000007:kind==1?998244353:kind==2?1000000:kind==3?2147483647:1000000007;
    int a=kind==4?m-1:2+rng()%(m-2),b=kind==4?m-2:rng()%m;
    q.push_back({a,b,m});
  }
  auto start=std::chrono::steady_clock::now();
  std::int64_t sum=0;
  for(auto [a,b,m]:q) sum+=(impl?blueberry::discrete_log(a,b,m):before::discrete_log(a,b,m)).value_or(-1);
  auto end=std::chrono::steady_clock::now();
  std::cout<<kind<<' '<<impl<<' '<<std::chrono::duration<double,std::milli>(end-start).count()<<' '<<sum<<'\n';
}
