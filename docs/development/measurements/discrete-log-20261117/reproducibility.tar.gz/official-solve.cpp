#include <chrono>
#include <cstdlib>
#include <iostream>
#include <vector>
#define blueberry before
#include "baseline.hpp"
#undef blueberry
#define blueberry bsgs
#include "discrete-log.hpp"
#undef blueberry
#include "discrete-log-ph.hpp"
struct Query { long long a,b,m; };
int main(int argc,char** argv) {
  std::ios::sync_with_stdio(false); std::cin.tie(nullptr);
  int t; std::cin>>t; std::vector<Query> q(t);
  for(auto& [a,b,m]:q) std::cin>>a>>b>>m;
  int mode=std::atoi(argv[1]); auto start=std::chrono::steady_clock::now();
  std::vector<long long> results; results.reserve(t);
  for(auto [a,b,m]:q) results.push_back((mode==0?before::discrete_log(a,b,m):mode==1?bsgs::discrete_log(a,b,m):blueberry::discrete_log(a,b,m)).value_or(-1));
  auto stop=std::chrono::steady_clock::now();
  std::cerr<<std::chrono::duration<double,std::milli>(stop-start).count()<<'\n';
  for(auto x:results) std::cout<<x<<'\n';
}
