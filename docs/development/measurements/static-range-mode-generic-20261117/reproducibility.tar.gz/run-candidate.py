import json, os, subprocess
from pathlib import Path
here=Path(__file__).resolve().parent
repo=here/'candidate'
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');version='10.0.22621.0'
msvc=vc/'bin/Hostx64/x64/cl.exe';clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(msvc.parent)+os.pathsep+env.get('PATH','')
env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/version/p for p in ('ucrt','shared','um'))]))
env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/version/p/'x64' for p in ('ucrt','um'))]))
out=[]
for compiler,std in [('msvc','c++20'),('msvc','c++latest'),('clang','gnu++20'),('clang','gnu++23')]:
 exe=here/f'{compiler}-{std.replace("+","p")}.exe'
 if compiler=='msvc':cmd=[str(msvc),'/nologo',f'/std:{std}','/EHsc','/O2','/I'+str(repo),str(here/'check.cpp'),'/Fo'+str(exe)+'.obj','/Fe'+str(exe)]
 else:cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link',f'-std={std}','-O2','-I'+str(repo),str(here/'check.cpp'),'-o',str(exe)]
 c=subprocess.run(cmd,env=env,capture_output=True,text=True,errors='replace');row={'compiler':compiler,'std':std,'command':cmd,'compile_exit':c.returncode,'compile_output':c.stdout+c.stderr};out.append(row)
 if c.returncode:print(json.dumps(out,indent=2));break
 t=subprocess.run([str(exe)],env=env,capture_output=True,text=True,errors='replace',timeout=180);row.update({'run_exit':t.returncode,'output':t.stdout+t.stderr});print(compiler,std,t.returncode,flush=True)
 if t.returncode:break
(here/'candidate-result.json').write_text(json.dumps(out,indent=2)+'\n')
