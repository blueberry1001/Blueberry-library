import json, os, subprocess
from pathlib import Path
here=Path(__file__).resolve().parent;repo=here/'baseline'
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');ver='10.0.22621.0'
clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env.get('PATH','')
env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/ver/p for p in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/ver/p/'x64' for p in ('ucrt','um'))]))
cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-I'+str(repo),str(here/'copy-only.cpp'),'-o',str(here/'copy-only.exe')]
p=subprocess.run(cmd,env=env,capture_output=True,text=True,errors='replace');(here/'copy-result.json').write_text(json.dumps({'command':cmd,'exit':p.returncode,'output':p.stdout+p.stderr},indent=2))
print(p.returncode, (p.stdout+p.stderr)[:1800])
