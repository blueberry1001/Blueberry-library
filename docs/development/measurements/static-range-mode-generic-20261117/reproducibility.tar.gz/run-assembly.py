import difflib, hashlib, json, os, subprocess
from pathlib import Path
here=Path(__file__).resolve().parent
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');ver='10.0.22621.0'
clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/ver/p for p in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/ver/p/'x64' for p in ('ucrt','um'))]))
rows=[]
for name,root in [('baseline',here/'baseline'),('candidate',here/'candidate')]:
 output=here/f'{name}.s';cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-std=gnu++20','-O2','-DNDEBUG','-fno-ident','-I'+str(root),'-S',str(here/'assembly.cpp'),'-o',str(output)]
 p=subprocess.run(cmd,env=env,capture_output=True,text=True,errors='replace');rows.append({'name':name,'command':cmd,'exit':p.returncode,'output':p.stdout+p.stderr})
 if p.returncode:break
 rows[-1]['sha256']=hashlib.sha256(output.read_bytes()).hexdigest()
if len(rows)==2 and all(not x['exit'] for x in rows):
 a=(here/'baseline.s').read_text().splitlines();b=(here/'candidate.s').read_text().splitlines()
 (here/'assembly.diff').write_text('\n'.join(difflib.unified_diff(a,b,fromfile='baseline',tofile='candidate'))+'\n')
 print('identical=',a==b,'lines=',len(a),len(b))
else:print(rows)
(here/'assembly-result.json').write_text(json.dumps(rows,indent=2)+'\n')
