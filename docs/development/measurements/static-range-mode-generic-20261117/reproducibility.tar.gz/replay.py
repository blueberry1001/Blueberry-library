import json, shutil, subprocess, sys, time
from pathlib import Path

source=Path(__file__).resolve().parent
output=Path.cwd()/'.build'/f'static-range-mode-generic-{time.time_ns()}'
output.parent.mkdir(parents=True,exist_ok=True)
shutil.copytree(source,output)
for script in ['run-copy.py','run-no-swap.py','run-fallback.py','run.py','run-candidate.py','run-assembly.py']:
    result=subprocess.run([sys.executable,str(output/script)],cwd=output,capture_output=True,text=True,errors='replace')
    (output/f'{script}.log').write_text(result.stdout+result.stderr,encoding='utf-8')
    print(script,'exit',result.returncode,flush=True)
    if result.returncode:
        print('Results:',output);sys.exit(result.returncode)
def load(name):return json.loads((output/name).read_text())
copy=load('copy-result.json');no_swap=load('no-swap-result.json');fallback=load('fallback-result.json')
ordinary=load('result.json');candidate=load('candidate-result.json');assembly=load('assembly-result.json')
valid=(copy['exit']!=0 and len(no_swap)==2 and no_swap[0]['compile_exit']!=0 and no_swap[1]['compile_exit']==0 and no_swap[1]['run_exit']==0)
for rows in [fallback,ordinary,candidate]:
    valid=valid and len(rows)==4 and all(row['compile_exit']==0 and row['run_exit']==0 for row in rows)
valid=valid and len(assembly)==2 and all(row['exit']==0 for row in assembly) and assembly[0]['sha256']==assembly[1]['sha256']
print('Results:',output)
if not valid:sys.exit(1)
