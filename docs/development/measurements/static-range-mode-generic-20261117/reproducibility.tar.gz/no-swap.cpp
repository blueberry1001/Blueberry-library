#include <type_traits>
#include "blueberry/data-structure/static-range-mode.hpp"
struct Key {
  int x;
  explicit Key(int v): x(v) {}
  Key(const Key&) = default;
  Key& operator=(const Key&) = default;
  Key(Key&&) = default;
  Key& operator=(Key&&) = default;
  friend void swap(Key&, Key&) = delete;
  friend bool operator<(const Key& a, const Key& b) { return a.x < b.x; }
  friend bool operator==(const Key& a, const Key& b) { return a.x == b.x; }
};
static_assert(std::is_move_constructible_v<Key> && std::is_move_assignable_v<Key> && !std::is_swappable_v<Key>);
int main() {
  const std::vector<Key> a{Key(1),Key(2),Key(1),Key(3)};
  auto ans = blueberry::static_range_mode(a, {{0,4}});
  return ans[0].second != 2;
}
