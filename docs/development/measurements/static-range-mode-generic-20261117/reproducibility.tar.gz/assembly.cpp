#include "blueberry/data-structure/static-range-mode.hpp"
struct Key {
  int x;
  friend bool operator<(const Key& a, const Key& b) { return a.x < b.x; }
  friend bool operator==(const Key& a, const Key& b) { return a.x == b.x; }
};
auto use_integer(const std::vector<int>& a, const std::vector<std::pair<int,int>>& q) {
  return blueberry::static_range_mode(a, q);
}
auto use_key(const std::vector<Key>& a, const std::vector<std::pair<int,int>>& q) {
  return blueberry::static_range_mode(a, q);
}
