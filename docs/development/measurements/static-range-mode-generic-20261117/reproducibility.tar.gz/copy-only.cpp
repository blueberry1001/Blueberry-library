#include "blueberry/data-structure/static-range-mode.hpp"
struct Key {
  int x;
  explicit Key(int v): x(v) {}
  Key(const Key&) = default;
  Key& operator=(const Key&) = default;
  Key(Key&&) = delete;
  Key& operator=(Key&&) = delete;
  friend bool operator<(const Key& a, const Key& b) { return a.x < b.x; }
  friend bool operator==(const Key& a, const Key& b) { return a.x == b.x; }
};
int main() {
  const std::vector<Key> a{Key(1),Key(2)};
  auto ans = blueberry::static_range_mode(a, {{0,2}});
  return ans[0].second != 1;
}
