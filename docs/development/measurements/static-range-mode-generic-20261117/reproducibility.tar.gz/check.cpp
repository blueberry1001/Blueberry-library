#include <algorithm>
#include <cstdint>
#include <iostream>
#include <limits>
#include <map>
#include <random>
#include <vector>
#include "blueberry/data-structure/static-range-mode.hpp"

template<class T> bool check(std::mt19937_64& rng, const char* name) {
  for (int n : {0, 1, 2, 3, 7, 8, 15, 16, 31, 32, 63, 64, 100}) for (int repeat = 0; repeat < 8; ++repeat) {
    std::vector<T> a(n);
    for (int i=0;i<n;++i) {
      auto x=rng()%12;
      if(x==0) a[i]=std::numeric_limits<T>::min();
      else if(x==1) a[i]=std::numeric_limits<T>::max();
      else if(x==2) a[i]=T(0);
      else a[i]=T(static_cast<int>(x)-7);
    }
    std::vector<std::pair<int,int>> q;
    for(int l=0;l<=n;++l)for(int r=l;r<=n;++r)q.push_back({l,r});
    std::shuffle(q.begin(),q.end(),rng);
    const auto answer=blueberry::static_range_mode(a,q);
    if(answer.size()!=q.size()){std::cerr<<name<<" size\n";return false;}
    for(std::size_t i=0;i<q.size();++i) {
      auto [l,r]=q[i];std::map<T,int> count;int best=0;
      for(int k=l;k<r;++k) best=std::max(best,++count[T(a[k])]);
      auto [idx,freq]=answer[i];
      if(freq!=best || (!best && idx!=-1) || (best && (idx<0 || idx>=n || count[T(a[idx])]!=best))) {
        std::cerr<<name<<" n="<<n<<" repeat="<<repeat<<" query="<<l<<','<<r<<" actual="<<idx<<','<<freq<<" expected frequency="<<best<<'\n';return false;
      }
    }
  }
  return true;
}
int main(){std::mt19937_64 r(20261117);
 return !(check<std::int8_t>(r,"i8") && check<std::uint8_t>(r,"u8") && check<std::int16_t>(r,"i16") && check<std::uint16_t>(r,"u16") && check<std::int32_t>(r,"i32") && check<std::uint32_t>(r,"u32") && check<std::int64_t>(r,"i64") && check<std::uint64_t>(r,"u64") && check<bool>(r,"bool") && check<char8_t>(r,"char8") && check<char16_t>(r,"char16") && check<char32_t>(r,"char32") && check<wchar_t>(r,"wchar")); }
