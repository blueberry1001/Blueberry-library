#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <vector>
#include "baseline_renamed.hpp"
#include "final.hpp"
#include "pr83-renamed.hpp"
#include "hybrid-renamed.hpp"
struct Mint {
  static constexpr std::uint32_t mod=998244353;
  std::uint32_t v=0;
  Mint& operator+=(Mint x){ v+=x.v; if(v>=mod)v-=mod;return *this; }
  Mint& operator-=(Mint x){ if(v<x.v)v+=mod;v-=x.v;return *this; }
  Mint& operator*=(Mint x){ v=std::uint64_t(v)*x.v%mod;return *this; }
};
int main(int argc,char**argv){
  const int mode=std::atoi(argv[1]),variant=std::atoi(argv[2]);int n;if(std::scanf("%d",&n)!=1)return 1;
  std::vector<Mint>a(n+1),b(n+1);for(int i=1;i<=n;++i)std::scanf("%u",&a[i].v);for(int i=1;i<=n;++i)std::scanf("%u",&b[i].v);
  auto c=variant==0 ? (mode?blueberry_old::lcm_convolution(a,b):blueberry_old::gcd_convolution(a,b)) : variant==1 ? (mode?blueberry::lcm_convolution(a,b):blueberry::gcd_convolution(a,b)) : variant==2 ? (mode?blueberry_pr83::lcm_convolution(a,b):blueberry_pr83::gcd_convolution(a,b)) : (mode?blueberry_hybrid::lcm_convolution(a,b):blueberry_hybrid::gcd_convolution(a,b));
  for(int i=1;i<=n;++i)std::printf("%u%c",c[i].v,i==n?'\n':' ');
}
