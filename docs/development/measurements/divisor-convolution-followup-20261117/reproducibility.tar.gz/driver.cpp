#include <algorithm>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <random>
#include <string>
#include <vector>
#include "baseline_renamed.hpp"
#include "final.hpp"
#include "pr83-renamed.hpp"
#include "hybrid-renamed.hpp"
#include "hybrid4096-renamed.hpp"
#include "hybrid-reserve-renamed.hpp"
#include "candidate.hpp"
#include "candidate1.hpp"
#include "nyaan.hpp"
struct Mint {
  static constexpr std::uint32_t mod = 998244353;
  std::uint32_t v = 0;
  Mint() = default;
  Mint(std::uint32_t x): v(x % mod) {}
  Mint& operator+=(Mint x) { v += x.v; if (v >= mod) v -= mod; return *this; }
  Mint& operator-=(Mint x) { if (v < x.v) v += mod; v -= x.v; return *this; }
  Mint& operator*=(Mint x) { v = (std::uint64_t(v) * x.v) % mod; return *this; }
  friend bool operator==(Mint x, Mint y) { return x.v == y.v; }
};
template <class T> auto solve(int v, int mode, std::vector<T> a, std::vector<T> b) {
  if (v == 0) return mode ? blueberry_old::lcm_convolution(std::move(a), std::move(b)) : blueberry_old::gcd_convolution(std::move(a), std::move(b));
  if (v == 1) return mode ? blueberry_fast::convolution<true>(std::move(a), std::move(b)) : blueberry_fast::convolution<false>(std::move(a), std::move(b));
  if (v == 3) return mode ? blueberry_fused::convolution<true>(std::move(a), std::move(b)) : blueberry_fused::convolution<false>(std::move(a), std::move(b));
  if (v == 4) return mode ? blueberry::lcm_convolution(std::move(a), std::move(b)) : blueberry::gcd_convolution(std::move(a), std::move(b));
  if (v == 5) return mode ? blueberry_pr83::lcm_convolution(std::move(a), std::move(b)) : blueberry_pr83::gcd_convolution(std::move(a), std::move(b));
  if (v == 6) return mode ? blueberry_hybrid::lcm_convolution(std::move(a), std::move(b)) : blueberry_hybrid::gcd_convolution(std::move(a), std::move(b));
  if (v == 7) return mode ? blueberry_hybrid4096::lcm_convolution(std::move(a), std::move(b)) : blueberry_hybrid4096::gcd_convolution(std::move(a), std::move(b));
  if (v == 8) return mode ? blueberry_hybrid_reserve::lcm_convolution(std::move(a), std::move(b)) : blueberry_hybrid_reserve::gcd_convolution(std::move(a), std::move(b));
  if (!mode) { auto r = gcd_convolution(a,b); if (!r.empty()) r[0] = T{}; return r; }
  return std::vector<T>{};
}
template <class T> bool check(std::uint64_t seed) {
  std::mt19937_64 gen(seed);
  for (int n = 0; n <= 180; ++n) for (int rep = 0; rep < 3; ++rep) {
    std::vector<T> a(n),b(n);
    for (auto& x:a) x=T(gen()%17); for (auto& x:b) x=T(gen()%17);
    for (int mode=0;mode<2;++mode) {
      auto old=solve(0,mode,a,b), fast=solve(1,mode,a,b);
      if(old!=fast) { std::cerr<<"mismatch seed="<<seed<<" n="<<n<<" mode="<<mode<<'\n';return false; }
      if(solve(3,mode,a,b)!=old){ std::cerr<<"candidate1 mismatch seed="<<seed<<" n="<<n<<" mode="<<mode<<'\n';return false; }
      if(solve(5,mode,a,b)!=old){ std::cerr<<"pr83 mismatch seed="<<seed<<" n="<<n<<" mode="<<mode<<'\n';return false; }
      if(solve(6,mode,a,b)!=old){ std::cerr<<"hybrid mismatch seed="<<seed<<" n="<<n<<" mode="<<mode<<'\n';return false; }
      if(solve(7,mode,a,b)!=old){ std::cerr<<"hybrid4096 mismatch seed="<<seed<<" n="<<n<<" mode="<<mode<<'\n';return false; }
      if(solve(8,mode,a,b)!=old){ std::cerr<<"reserve mismatch seed="<<seed<<" n="<<n<<" mode="<<mode<<'\n';return false; }
      std::vector<T> slow(n);
      for (int i=1;i<n;++i) for (int j=1;j<n;++j) { auto x=a[i]; x*=b[j]; auto k=mode?std::lcm(i,j):std::gcd(i,j); if(k<n) slow[k]+=x; }
      if(slow!=fast){ std::cerr<<"brute mismatch seed="<<seed<<" n="<<n<<" mode="<<mode<<'\n';return false; }
      if(!mode && n && solve(2,0,a,b)!=old){ std::cerr<<"Nyaan mismatch seed="<<seed<<" n="<<n<<'\n';return false; }
    }
  }
  for (int n : {511, 512, 513, 1023, 1024, 1025, 2047, 2048, 2049, 4095, 4096, 4097, 65536}) {
    std::vector<T> a(n), b(n); for (auto& x:a) x=T(gen()%17); for (auto& x:b) x=T(gen()%17);
    for (int mode=0; mode<2; ++mode) {
      auto old=solve(0,mode,a,b);
      if (old != solve(4,mode,a,b) || old != solve(5,mode,a,b) || old != solve(6,mode,a,b) || old != solve(7,mode,a,b) || old != solve(8,mode,a,b)) {
        std::cerr<<"candidate mismatch seed="<<seed<<" n="<<n<<" mode="<<mode<<'\n'; return false;
      }
    }
  }
  return true;
}
int main(int argc,char** argv) {
  if(argc==2) return check<Mint>(std::stoull(argv[1])) && check<std::uint64_t>(std::stoull(argv[1])) ? 0 : 1;
  int v=std::stoi(argv[1]),mode=std::stoi(argv[2]),n=std::stoi(argv[3]),reps=std::stoi(argv[4]);
  std::mt19937_64 rng(20261117); std::vector<Mint>a(n),b(n);
  for(auto&x:a)x=Mint(rng());for(auto&x:b)x=Mint(rng());
  std::uint64_t checksum=0;auto t=std::chrono::steady_clock::now();
  for(int i=0;i<reps;++i){auto r=solve(v,mode,a,b); for(std::size_t j=0;j<r.size();j+=std::max<std::size_t>(1,r.size()/101)) checksum+=r[j].v;}
  auto e=std::chrono::steady_clock::now();std::cout<<v<<' '<<mode<<' '<<n<<' '<<reps<<' '<<std::chrono::duration<double,std::milli>(e-t).count()<<' '<<checksum<<'\n';
}
