import json, shutil, subprocess, sys, time
from pathlib import Path

source=Path(__file__).resolve().parent
output=Path.cwd()/'.build'/f'divisor-convolution-followup-{time.time_ns()}'
output.parent.mkdir(parents=True,exist_ok=True)
shutil.copytree(source,output)
steps=[('run-assert-assembly.py','assert-assembly-results.json'),('run-comparison.py','comparison-results.json'),('run-focused.py','focused-results.json'),('run-threshold.py','threshold-results.json'),('run-reserve.py','reserve-results.json'),('run-matrix.py','matrix-results.json'),('run-matrix-debug.py','matrix-debug-results.json'),('run-official.py','official-results.json'),('run-e2e.py','e2e-results.json'),('run-memory.py','memory-results.json')]
for script,record in steps:
    result=subprocess.run([sys.executable,str(output/script)],cwd=output,capture_output=True,text=True,errors='replace')
    (output/f'{script}.log').write_text(result.stdout+result.stderr,encoding='utf-8')
    data=json.loads((output/record).read_text()) if (output/record).exists() else {}
    status=data.get('status','missing')
    print(script,'exit',result.returncode,'status',status,flush=True)
    if result.returncode or status!='complete' or (script=='run-assert-assembly.py' and not data.get('same_asm')):
        print('Results:',output);sys.exit(result.returncode or 1)
print('Results:',output)
