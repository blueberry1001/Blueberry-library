import ctypes,hashlib,json,os,subprocess,sys,time
from pathlib import Path
here=Path(__file__).resolve().parent
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');version='10.0.22621.0'
msvc=vc/'bin/Hostx64/x64/cl.exe';clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(msvc.parent)+os.pathsep+env.get('PATH','')
env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/version/p for p in ('ucrt','shared','um'))]))
env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/version/p/'x64' for p in ('ucrt','um'))]))
out={'status':'running','note':'2x2 matrices over F17, multiplication not commutative; exact brute force for all array sizes including 1023/1024/1025','hashes':{p:hashlib.sha256((here/p).read_bytes()).hexdigest() for p in ['matrix-test.cpp','pr83-original.hpp','hybrid.hpp']},'rows':[]}
def save():(here/'matrix-debug-results.json').write_text(json.dumps(out,indent=2)+'\n')
try:
 k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];k.SetProcessAffinityMask.restype=ctypes.c_int
 if not k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<4):raise OSError(ctypes.get_last_error(),'CPU4 affinity failed')
 probe=subprocess.run([sys.executable,str(here/'report-affinity.py')],capture_output=True,text=True,errors='replace',timeout=30);out['inherited_affinity']={'exit':probe.returncode,'stdout':probe.stdout,'stderr':probe.stderr};save()
 if probe.returncode or json.loads(probe.stdout)['process_mask']!='0x10':raise RuntimeError('child affinity not verified')
 for variant in ['pr83','hybrid']:
  inc=here/f'matrix-{variant}'
  for compiler,std in [('msvc','c++20'),('msvc','c++latest'),('clang','gnu++20'),('clang','gnu++23')]:
   exe=here/f'matrix-debug-{variant}-{compiler}-{std.replace("+","p")}.exe'
   if compiler=='msvc':cmd=[str(msvc),'/nologo',f'/std:{std}','/EHsc','/O2','/I'+str(inc),str(here/'matrix-test.cpp'),'/Fo'+str(exe)+'.obj','/Fe'+str(exe)]
   else:cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link',f'-std={std}','-O2','-I'+str(inc),str(here/'matrix-test.cpp'),'-o',str(exe)]
   p=subprocess.run(cmd,env=env,capture_output=True,text=True,errors='replace',timeout=120);row={'variant':variant,'compiler':compiler,'standard':std,'command':cmd,'compile_exit':p.returncode,'compile_output':p.stdout+p.stderr,'tests':[]};out['rows'].append(row);save()
   if p.returncode:raise RuntimeError('compile failed')
   for seed in [1,2,17]:
    t=time.perf_counter();p=subprocess.run([str(exe),str(seed)],env=env,capture_output=True,text=True,errors='replace',timeout=120)
    row['tests'].append({'seed':seed,'exit':p.returncode,'seconds':time.perf_counter()-t,'stdout':p.stdout,'stderr':p.stderr});save()
    if p.returncode:raise RuntimeError('matrix mismatch')
   print(variant,compiler,std,'ok',flush=True)
 out['status']='complete'
except BaseException as e:
 out['status']='failed';out['error']=repr(e);save();raise
save()
