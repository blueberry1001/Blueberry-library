import json,statistics
from pathlib import Path
data=json.loads(Path('focused-results.json').read_text())
for r in data['rows']:
 print(r['compiler'],r['type'])
 for mode in [0,1]:
  for n in [16,128,512,1023,1024,4096,65536,1000001]:
   v=[5,6] if r['type']=='mint' else [2,3]
   x=[]
   for i in v:
    rows=[s for s in r['samples'] if s['mode']==mode and s['n']==n and s['variant']==i and s['rep']>=0]
    x.append((rows[0]['reps'],round(statistics.median(s['ms'] for s in rows),3),round(min(s['ms'] for s in rows),3),round(max(s['ms'] for s in rows),3)))
   print(mode,n,x)
