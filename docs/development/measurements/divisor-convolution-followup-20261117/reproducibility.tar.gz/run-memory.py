import ctypes,hashlib,json,os,platform,subprocess,sys,time
from pathlib import Path
from ctypes import wintypes
here=Path(__file__).resolve().parent;work=here/'official-work'
repo=Path(os.environ.get('LIBRARY_CHECKER_PROBLEMS', r'C:\Users\kubar\Documents\GitHub\Blueberry-library\.verification\library-checker-problems'))
class Memory(ctypes.Structure):
 _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD),('PeakWorkingSetSize',ctypes.c_size_t),('WorkingSetSize',ctypes.c_size_t),('QuotaPeakPagedPoolUsage',ctypes.c_size_t),('QuotaPagedPoolUsage',ctypes.c_size_t),('QuotaPeakNonPagedPoolUsage',ctypes.c_size_t),('QuotaNonPagedPoolUsage',ctypes.c_size_t),('PagefileUsage',ctypes.c_size_t),('PeakPagefileUsage',ctypes.c_size_t)]
out={'status':'running','platform':platform.platform(),'note':'Windows process peak working set / peak pagefile usage via GetProcessMemoryInfo polling every ~2ms, official max_random_00 as cached file, stdout to null, CPU4 fixed; peak reported by OS counters, not time benchmark.','runs':[]}
def save():(here/'memory-results.json').write_text(json.dumps(out,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest()
try:
 k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];k.SetProcessAffinityMask.restype=ctypes.c_int
 if not k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<4):raise OSError(ctypes.get_last_error(),'CPU4 affinity failed')
 q=subprocess.run([sys.executable,str(here/'report-affinity.py')],capture_output=True,text=True,errors='replace',timeout=30);out['inherited_affinity']={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};save()
 if q.returncode or json.loads(q.stdout)['process_mask']!='0x10':raise RuntimeError('child affinity not verified')
 ps=ctypes.WinDLL('psapi',use_last_error=True);ps.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(Memory),wintypes.DWORD];ps.GetProcessMemoryInfo.restype=wintypes.BOOL
 for mode,name in enumerate(['gcd_convolution','lcm_convolution']):
  dst=work/name;inp=dst/'memory-input.tmp';expected=json.loads((repo/'convolution'/name/'hash.json').read_text())
  with open(inp,'wb') as f:q=subprocess.run([dst/'max_random.exe','0'],stdout=f,stderr=subprocess.PIPE,timeout=120)
  if q.returncode or sha(inp)!=expected['max_random_00.in']:raise RuntimeError('input mismatch')
  for rep in range(4):
   for v in ([2,3] if rep%2==0 else [3,2]):
    row={'mode':name,'rep':rep,'variant':'pr83' if v==2 else 'hybrid','samples':0,'peak_working_set_bytes':0,'peak_pagefile_bytes':0};out['runs'].append(row);save()
    with open(inp,'rb') as fi,open(os.devnull,'wb') as fo:
     p=subprocess.Popen([work/'candidate.exe',str(mode),str(v)],stdin=fi,stdout=fo,stderr=subprocess.PIPE)
     while p.poll() is None:
      info=Memory();info.cb=ctypes.sizeof(Memory)
      if ps.GetProcessMemoryInfo(int(p._handle),ctypes.byref(info),info.cb):
       row['samples']+=1;row['peak_working_set_bytes']=max(row['peak_working_set_bytes'],info.PeakWorkingSetSize);row['peak_pagefile_bytes']=max(row['peak_pagefile_bytes'],info.PeakPagefileUsage)
      time.sleep(.002)
     row['exit']=p.returncode;row['stderr']=p.stderr.read().decode('utf8','replace');save()
    if row['exit'] or not row['samples']:raise RuntimeError('process or memory poll failed')
  inp.unlink()
  print(name,[(r['variant'],r['rep'],r['peak_working_set_bytes'],r['peak_pagefile_bytes']) for r in out['runs'] if r['mode']==name],flush=True)
 out['status']='complete'
except BaseException as e:
 out['status']='failed';out['error']=repr(e);save();raise
save()
