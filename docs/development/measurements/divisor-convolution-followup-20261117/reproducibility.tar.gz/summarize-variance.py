import json,statistics
from pathlib import Path
d=json.loads(Path('comparison-results.json').read_text())
for row in d['builds']:
 for mode,n in [(0,512),(1,512),(0,65536),(1,65536),(0,1000001),(1,1000001)]:
  vs=[5,6] if row['type']=='mint' else [2,3]
  print(row['compiler'],row['type'],mode,n)
  for v in vs:
   vals=[round(s['ms'],3) for s in row['samples'] if s['mode']==mode and s['n']==n and s['variant']==v and s['rep']>=0]
   print(v,vals,'median',round(statistics.median(vals),3),'range',round(max(vals)-min(vals),3))
