import ctypes,hashlib,json,os,platform,statistics,subprocess,sys
from pathlib import Path
here=Path(__file__).resolve().parent
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');version='10.0.22621.0'
msvc=vc/'bin/Hostx64/x64/cl.exe';clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(msvc.parent)+os.pathsep+env.get('PATH','')
env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/version/p for p in ('ucrt','shared','um'))]))
env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/version/p/'x64' for p in ('ucrt','um'))]))
out={'status':'running','platform':platform.platform(),'cpu':platform.processor(),'note':'Logical CPU4 fixed, child affinity verified; sibling 5/OS can contend; per-run elapsed includes copies, allocation, transform, checksum. Three variants in same executable with same input/flags; warmup1 + 12 runs, balanced rotation.','hashes':{f:hashlib.sha256((here/f).read_bytes()).hexdigest() for f in ['pr83-original.hpp','pr83-renamed.hpp','hybrid.hpp','hybrid-renamed.hpp','hybrid4096.hpp','hybrid4096-renamed.hpp','driver.cpp','u64-driver.cpp']},'rows':[]}
def save():(here/'threshold-results.json').write_text(json.dumps(out,indent=2)+'\n')
try:
 k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];k.SetProcessAffinityMask.restype=ctypes.c_int
 if not k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<4):raise OSError(ctypes.get_last_error(),'CPU4 affinity failed')
 p=subprocess.run([sys.executable,str(here/'report-affinity.py')],capture_output=True,text=True,errors='replace',timeout=30);out['inherited_affinity']={'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr};save()
 if p.returncode or json.loads(p.stdout)['process_mask']!='0x10':raise RuntimeError('child affinity not verified')
 for compiler in ['msvc','clang']:
  for typ in ['mint','u64']:
   exe=here/f'threshold-{compiler}-{typ}.exe';src=here/('driver.cpp' if typ=='mint' else 'u64-driver.cpp')
   if compiler=='msvc':cmd=[str(msvc),'/nologo','/std:c++20','/EHsc','/O2','/DNDEBUG',str(src),'/Fo'+str(exe)+'.obj','/Fe'+str(exe)]
   else:cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG',str(src),'-o',str(exe)]
   p=subprocess.run(cmd,env=env,capture_output=True,text=True,errors='replace',timeout=180);row={'compiler':compiler,'type':typ,'command':cmd,'exit':p.returncode,'output':p.stdout+p.stderr,'samples':[]};out['rows'].append(row);save()
   if p.returncode:raise RuntimeError('compile failed')
   if typ=='mint':
    row['tests']=[]
    for seed in [1,2,17]:
     p=subprocess.run([str(exe),str(seed)],env=env,capture_output=True,text=True,errors='replace',timeout=120)
     row['tests'].append({'seed':seed,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});save()
     if p.returncode:raise RuntimeError('differential test failed')
   for mode in [0,1]:
    for n,reps in [(1023,3000),(1024,3000),(1025,3000),(2048,1200),(4095,500),(4096,500),(4097,500)]:
     variants=[5,6,7] if typ=='mint' else [2,3,4];hashes=set()
     for rep in range(-1,12):
      order=variants[rep%len(variants):]+variants[:rep%len(variants)]
      for variant in order:
       p=subprocess.run([str(exe),str(variant),str(mode),str(n),str(reps)],env=env,capture_output=True,text=True,errors='replace',timeout=120)
       if p.returncode:raise RuntimeError('run failed '+p.stderr)
       f=p.stdout.split();hashes.add(f[5]);row['samples'].append({'mode':mode,'n':n,'reps':reps,'rep':rep,'variant':variant,'ms':float(f[4]),'checksum':f[5]});save()
      if len(hashes)!=1:raise RuntimeError('checksum mismatch '+str(hashes))
     print(compiler,typ,mode,n,[(v,round(statistics.median(x['ms'] for x in row['samples'] if x['mode']==mode and x['n']==n and x['rep']>=0 and x['variant']==v),3)) for v in variants],flush=True)
 out['status']='complete'
except BaseException as e:
 out['status']='failed';out['error']=repr(e);save();raise
save()
