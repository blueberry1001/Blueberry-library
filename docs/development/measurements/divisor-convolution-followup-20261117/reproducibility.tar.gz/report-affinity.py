import ctypes,json
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p
k.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)];k.GetProcessAffinityMask.restype=ctypes.c_int
p=ctypes.c_size_t();s=ctypes.c_size_t()
if not k.GetProcessAffinityMask(k.GetCurrentProcess(),ctypes.byref(p),ctypes.byref(s)):raise OSError(ctypes.get_last_error())
print(json.dumps({'process_mask':hex(p.value),'system_mask':hex(s.value)}))
