#pragma once
#include <cstddef>
#include <vector>

namespace blueberry {
namespace detail {
template <bool Divisor, bool Inverse, bool Paired = false, class T>
void divisor_transform(std::vector<T>& a, std::vector<T>* b = nullptr) {
  const std::size_t n = a.size();
  std::vector<bool> composite(n);
  for (std::size_t p = 2; p < n; ++p) {
    if (composite[p]) continue;
    const auto count = (n - 1) / p;
    for (std::size_t j = 1; j <= count; ++j) {
      composite[j * p] = true;
      const auto i = (Divisor != Inverse) ? j : count + 1 - j;
      if constexpr (Divisor) {
        if constexpr (Inverse) { a[i * p] -= a[i]; if constexpr (Paired) (*b)[i * p] -= (*b)[i]; }
        else { a[i * p] += a[i]; if constexpr (Paired) (*b)[i * p] += (*b)[i]; }
      } else {
        if constexpr (Inverse) { a[i] -= a[i * p]; if constexpr (Paired) (*b)[i] -= (*b)[i * p]; }
        else { a[i] += a[i * p]; if constexpr (Paired) (*b)[i] += (*b)[i * p]; }
      }
    }
  }
}
template <bool Divisor, class T>
void divisor_convolution(std::vector<T>& a, std::vector<T>& b) {
  const auto n = a.size();
  std::vector<bool> composite(n);
  std::vector<std::size_t> primes;
  for (std::size_t p = 2; p < n; ++p) {
    if (composite[p]) continue;
    primes.push_back(p);
    const auto count = (n - 1) / p;
    for (std::size_t j = 1; j <= count; ++j) {
      composite[j * p] = true;
      const auto i = Divisor ? j : count + 1 - j;
      if constexpr (Divisor) { a[i * p] += a[i]; b[i * p] += b[i]; }
      else { a[i] += a[i * p]; b[i] += b[i * p]; }
    }
  }
  for (std::size_t i = 1; i < n; ++i) a[i] *= b[i];
  for (const auto p : primes) {
    const auto count = (n - 1) / p;
    for (std::size_t j = 1; j <= count; ++j) {
      const auto i = Divisor ? count + 1 - j : j;
      if constexpr (Divisor) a[i * p] -= a[i];
      else a[i] -= a[i * p];
    }
  }
}
}  // namespace detail
template <class T> void divisor_zeta(std::vector<T>& a) {
  detail::divisor_transform<true, false>(a);
}
template <class T> void divisor_mobius(std::vector<T>& a) {
  detail::divisor_transform<true, true>(a);
}
template <class T> void multiple_zeta(std::vector<T>& a) {
  detail::divisor_transform<false, false>(a);
}
template <class T> void multiple_mobius(std::vector<T>& a) {
  detail::divisor_transform<false, true>(a);
}
template <class T>
std::vector<T> gcd_convolution(std::vector<T> a, std::vector<T> b) {
  if (a.size() < 4096) {
    detail::divisor_transform<false, false, true>(a, &b);
    for (std::size_t i = 1; i < a.size(); ++i) a[i] *= b[i];
    multiple_mobius(a);
  } else detail::divisor_convolution<false>(a, b);
  if (!a.empty()) a[0] = T{};
  return a;
}
template <class T>
std::vector<T> lcm_convolution(std::vector<T> a, std::vector<T> b) {
  if (a.size() < 4096) {
    detail::divisor_transform<true, false, true>(a, &b);
    for (std::size_t i = 1; i < a.size(); ++i) a[i] *= b[i];
    divisor_mobius(a);
  } else detail::divisor_convolution<true>(a, b);
  if (!a.empty()) a[0] = T{};
  return a;
}
}  // namespace blueberry
