import hashlib, json
from pathlib import Path
root=Path(__file__).resolve().parent
source=(root/'pr83-original.hpp').read_bytes()
name=b'namespace blueberry {'
assert source.count(name)==1
renamed=source.replace(name,b'namespace blueberry_pr83 {',1)
(root/'pr83-renamed.hpp').write_bytes(renamed)
(root/'source-hashes.json').write_text(json.dumps({'pr83_commit':'bf28f6a0928df10a4f0357a3242e89ec89b7ae7b','pr83_git_blob':'0d5d326081d35308c0be6ba9cc8b0582b14c2041','files':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ['pr83-original.hpp','pr83-renamed.hpp','baseline_renamed.hpp','final.hpp']}},indent=2)+'\n')
