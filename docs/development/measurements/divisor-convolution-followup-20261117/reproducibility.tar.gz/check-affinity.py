import ctypes, json
k=ctypes.WinDLL('kernel32', use_last_error=True)
k.GetCurrentProcess.restype=ctypes.c_void_p
k.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
k.GetProcessAffinityMask.restype=ctypes.c_int
k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
k.SetProcessAffinityMask.restype=ctypes.c_int
p=k.GetCurrentProcess();pm=ctypes.c_size_t();sm=ctypes.c_size_t()
before=k.GetProcessAffinityMask(p,ctypes.byref(pm),ctypes.byref(sm));beforemask=pm.value
ctypes.set_last_error(0);result=k.SetProcessAffinityMask(p,1<<4);error=ctypes.get_last_error()
after=k.GetProcessAffinityMask(p,ctypes.byref(pm),ctypes.byref(sm))
print(json.dumps({'before_query':before,'before_process_mask':hex(beforemask),'system_mask':hex(sm.value),'set_result':result,'set_error':error,'after_query':after,'after_process_mask':hex(pm.value)}))
