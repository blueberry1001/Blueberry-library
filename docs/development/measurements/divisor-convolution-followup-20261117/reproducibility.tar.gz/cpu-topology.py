import ctypes,json,struct
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.GetLogicalProcessorInformationEx.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)]
k.GetLogicalProcessorInformationEx.restype=ctypes.c_int
length=ctypes.c_ulong();k.GetLogicalProcessorInformationEx(0,None,ctypes.byref(length))
data=ctypes.create_string_buffer(length.value)
if not k.GetLogicalProcessorInformationEx(0,data,ctypes.byref(length)):raise OSError(ctypes.get_last_error())
buf=data.raw[:length.value];off=0;cores=[]
while off<len(buf):
 rel,size=struct.unpack_from('<II',buf,off);count=struct.unpack_from('<H',buf,off+30)[0];groups=[]
 for i in range(count):
  mask,group=struct.unpack_from('<QH',buf,off+32+i*16);groups.append({'group':group,'mask':hex(mask),'logical_cpus':[j for j in range(64) if mask & (1<<j)]})
 cores.append({'efficiency_class':buf[off+9],'groups':groups});off+=size
print(json.dumps(cores,indent=2))
