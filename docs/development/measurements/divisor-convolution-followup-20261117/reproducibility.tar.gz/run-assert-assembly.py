import ctypes,difflib,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
here=Path(__file__).resolve().parent
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');ver='10.0.22621.0'
clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/ver/p for p in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/ver/p/'x64' for p in ('ucrt','um'))]))
out={'status':'running','note':'Windows Clang 18 gnu++20 -O2 -DNDEBUG -fno-ident; wrappers instantiate GCD/LCM with mint and uint64; only header assertion/include removal differs','rows':[]}
def save():(here/'assert-assembly-results.json').write_text(json.dumps(out,indent=2)+'\n')
try:
 k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];k.SetProcessAffinityMask.restype=ctypes.c_int
 if not k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<4):raise OSError(ctypes.get_last_error(),'CPU4 affinity failed')
 q=subprocess.run([sys.executable,str(here/'report-affinity.py')],capture_output=True,text=True,errors='replace',timeout=30);out['inherited_affinity']={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};save()
 if q.returncode or json.loads(q.stdout)['process_mask']!='0x10':raise RuntimeError('child affinity not verified')
 for tag,source in [('before',here/'hybrid-pre-assert-removal.hpp.txt'),('after',here/'hybrid.hpp')]:
  inc=here/'assert-asm'/tag;header=inc/'blueberry/math/divisor-convolution.hpp';header.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,header)
  asm=here/f'assert-{tag}.s';cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-std=gnu++20','-O2','-DNDEBUG','-fno-ident','-I'+str(inc),'-S',str(here/'assert-assembly.cpp'),'-o',str(asm)]
  p=subprocess.run(cmd,env=env,capture_output=True,text=True,errors='replace',timeout=120);row={'tag':tag,'command':cmd,'header_sha256':hashlib.sha256(header.read_bytes()).hexdigest(),'exit':p.returncode,'stderr':p.stderr};out['rows'].append(row);save()
  if p.returncode:raise RuntimeError('compile failed')
  row['asm_sha256']=hashlib.sha256(asm.read_bytes()).hexdigest();save()
 before=(here/'assert-before.s').read_text().splitlines();after=(here/'assert-after.s').read_text().splitlines()
 (here/'assert-assembly.diff').write_text('\n'.join(difflib.unified_diff(before,after,fromfile='before',tofile='after'))+'\n')
 out['same_asm']=before==after;out['lines']=[len(before),len(after)];out['status']='complete';save()
 print('same=',out['same_asm'],'lines=',out['lines'],flush=True)
except BaseException as e:
 out['status']='failed';out['error']=repr(e);save();raise
