#include <cstdint>
#include <utility>
#include "blueberry/math/divisor-convolution.hpp"
struct Mint {
  std::uint32_t x = 0;
  Mint& operator+=(Mint y) { x+=y.x; if(x>=998244353)x-=998244353; return *this; }
  Mint& operator-=(Mint y) { if(x<y.x)x+=998244353; x-=y.x; return *this; }
  Mint& operator*=(Mint y) { x=std::uint64_t(x)*y.x%998244353; return *this; }
};
auto gcd_mint(std::vector<Mint> a,std::vector<Mint> b) { return blueberry::gcd_convolution(std::move(a),std::move(b)); }
auto lcm_mint(std::vector<Mint> a,std::vector<Mint> b) { return blueberry::lcm_convolution(std::move(a),std::move(b)); }
auto gcd_u64(std::vector<std::uint64_t> a,std::vector<std::uint64_t> b) { return blueberry::gcd_convolution(std::move(a),std::move(b)); }
auto lcm_u64(std::vector<std::uint64_t> a,std::vector<std::uint64_t> b) { return blueberry::lcm_convolution(std::move(a),std::move(b)); }
