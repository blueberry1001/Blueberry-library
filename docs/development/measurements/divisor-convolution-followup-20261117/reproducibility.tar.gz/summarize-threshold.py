import json,statistics
from pathlib import Path
d=json.loads(Path('threshold-results.json').read_text())
for row in d['rows']:
 for mode in [0,1]:
  for n in [1024,2048,4095,4096]:
   variants=[5,6,7] if row['type']=='mint' else [2,3,4]
   print(row['compiler'],row['type'],'gcd' if not mode else 'lcm','n',n,end=' ')
   for v in variants:
    s=[x['ms'] for x in row['samples'] if x['mode']==mode and x['n']==n and x['variant']==v and x['rep']>=0]
    print(v,'median',round(statistics.median(s),3),'min',round(min(s),3),'max',round(max(s),3),end='; ')
   print()
