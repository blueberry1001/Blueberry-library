from pathlib import Path
here=Path(__file__).resolve().parent
pr83=(here/'pr83-original.hpp').read_text()
ours=(here/'final.hpp').read_text()
start=ours.index('template <bool Divisor, class T>\nvoid divisor_convolution')
end=ours.index('}  // namespace detail',start)
helper=ours[start:end]
assert pr83.count('}  // namespace detail')==1
hybrid=pr83.replace('}  // namespace detail',helper+'}  // namespace detail',1)
for div,prefix in [('false','multiple'),('true','divisor')]:
 old=f'''  detail::divisor_transform<{div}, false, true>(a, &b);
  for (std::size_t i = 1; i < a.size(); ++i) a[i] *= b[i];
  {prefix}_mobius(a);'''
 new=f'''  if (a.size() < 1024) {{
    detail::divisor_transform<{div}, false, true>(a, &b);
    for (std::size_t i = 1; i < a.size(); ++i) a[i] *= b[i];
    {prefix}_mobius(a);
  }} else detail::divisor_convolution<{div}>(a, b);'''
 assert hybrid.count(old)==1
 hybrid=hybrid.replace(old,new,1)
assert hybrid.count('#include <cassert>\n')==1
hybrid=hybrid.replace('#include <cassert>\n','',1)
assert hybrid.count('  assert(a.size() == b.size());\n')==2
hybrid=hybrid.replace('  assert(a.size() == b.size());\n','')
(here/'hybrid.hpp').write_text(hybrid,encoding='utf-8',newline='\n')
assert hybrid.count('namespace blueberry {')==1
(here/'hybrid-renamed.hpp').write_text(hybrid.replace('namespace blueberry {','namespace blueberry_hybrid {',1),encoding='utf-8',newline='\n')
