from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'hybrid.hpp').read_text()
assert s.count('a.size() < 1024')==2
s=s.replace('a.size() < 1024','a.size() < 4096')
(p/'hybrid4096.hpp').write_text(s,encoding='utf-8',newline='\n')
assert s.count('namespace blueberry {')==1
(p/'hybrid4096-renamed.hpp').write_text(s.replace('namespace blueberry {','namespace blueberry_hybrid4096 {',1),encoding='utf-8',newline='\n')
