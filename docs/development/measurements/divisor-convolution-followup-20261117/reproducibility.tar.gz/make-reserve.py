from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'hybrid.hpp').read_text()
needle='  std::vector<std::size_t> primes;\n'
assert s.count(needle)==1
s=s.replace(needle,needle+'  if (n < 8192) primes.reserve(n / 4);\n',1)
(p/'hybrid-reserve.hpp').write_text(s,encoding='utf-8',newline='\n')
assert s.count('namespace blueberry {')==1
(p/'hybrid-reserve-renamed.hpp').write_text(s.replace('namespace blueberry {','namespace blueberry_hybrid_reserve {',1),encoding='utf-8',newline='\n')
