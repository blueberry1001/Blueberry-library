import hashlib,json,os,platform,statistics,subprocess
from pathlib import Path
here=Path(__file__).resolve().parent
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');version='10.0.22621.0'
msvc=vc/'bin/Hostx64/x64/cl.exe';clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(msvc.parent)+os.pathsep+env.get('PATH','')
env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/version/p for p in ('ucrt','shared','um'))]))
env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/version/p/'x64' for p in ('ucrt','um'))]))
out={'status':'running','platform':platform.platform(),'cpu':platform.processor(),'note':'Windows, CPU unpinned and shared with other sessions. All variants compiled in same executable with same flags and input; times include vector copies, allocation, operations and checksum; input generation excluded. 1 warmup + 7 repetitions; rotated order. uint64_t arithmetic wraps modulo 2^64.','hashes':{f:hashlib.sha256((here/f).read_bytes()).hexdigest() for f in ['pr83-original.hpp','pr83-renamed.hpp','baseline_renamed.hpp','final.hpp','driver.cpp','u64-driver.cpp']},'builds':[]}
def save():(here/'comparison-results.json').write_text(json.dumps(out,indent=2)+'\n')
try:
 for compiler in ['msvc','clang']:
  for typ in ['mint','u64']:
   exe=here/f'{compiler}-{typ}.exe';src=here/('driver.cpp' if typ=='mint' else 'u64-driver.cpp')
   if compiler=='msvc':cmd=[str(msvc),'/nologo','/std:c++20','/EHsc','/O2','/DNDEBUG',str(src),'/Fo'+str(exe)+'.obj','/Fe'+str(exe)]
   else:cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG',str(src),'-o',str(exe)]
   q=subprocess.run(cmd,env=env,capture_output=True,text=True,errors='replace',timeout=180)
   row={'compiler':compiler,'type':typ,'command':cmd,'exit':q.returncode,'output':q.stdout+q.stderr,'tests':[],'samples':[]};out['builds'].append(row);save()
   if q.returncode:raise RuntimeError('compile failed')
   if typ=='mint':
    for seed in [1,2,17]:
     q=subprocess.run([str(exe),str(seed)],env=env,capture_output=True,text=True,errors='replace',timeout=120)
     row['tests'].append({'seed':seed,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr});save()
     if q.returncode:raise RuntimeError('differential test failed')
   for mode in [0,1]:
    for n,reps in [(16,40000),(64,10000),(128,5000),(256,2000),(384,1000),(511,1000),(512,1000),(513,1000),(1024,300),(4096,40),(65536,4),(1000001,1)]:
     variants=[0,4,5] if typ=='mint' else [0,1,2];hashes=set()
     for rep in range(-1,7):
      order=variants[rep%3:]+variants[:rep%3]
      if rep%2==1:order=list(reversed(order))
      for variant in order:
       q=subprocess.run([str(exe),str(variant),str(mode),str(n),str(reps)],env=env,capture_output=True,text=True,errors='replace',timeout=120)
       if q.returncode:raise RuntimeError('run failed '+q.stdout+q.stderr)
       f=q.stdout.split();hashes.add(f[5]);row['samples'].append({'mode':mode,'n':n,'reps':reps,'rep':rep,'variant':variant,'ms':float(f[4]),'checksum':f[5]});save()
      if len(hashes)!=1:raise RuntimeError('checksum mismatch '+str(hashes))
     print(compiler,typ,mode,n,[(v,round(statistics.median(s['ms'] for s in row['samples'] if s['mode']==mode and s['n']==n and s['rep']>=0 and s['variant']==v),3)) for v in variants],flush=True)
 out['status']='complete'
except BaseException as e:
 out['status']='failed';out['error']=repr(e);save();raise
save()
