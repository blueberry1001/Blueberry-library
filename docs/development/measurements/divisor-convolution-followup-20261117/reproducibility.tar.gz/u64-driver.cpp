#include <algorithm>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <random>
#include <string>
#include <vector>
#include "baseline_renamed.hpp"
#include "final.hpp"
#include "pr83-renamed.hpp"
#include "hybrid-renamed.hpp"
#include "hybrid4096-renamed.hpp"
#include "hybrid-reserve-renamed.hpp"
int main(int, char** argv) {
  int variant=std::stoi(argv[1]), mode=std::stoi(argv[2]), n=std::stoi(argv[3]), reps=std::stoi(argv[4]);
  std::mt19937_64 rng(20261117);std::vector<std::uint64_t>a(n),b(n);
  for(auto& x:a)x=rng();for(auto& x:b)x=rng();
  auto start=std::chrono::steady_clock::now();std::uint64_t checksum=0;
  for(int rep=0;rep<reps;++rep){
    auto c=variant==0 ? (mode?blueberry_old::lcm_convolution(a,b):blueberry_old::gcd_convolution(a,b)) : variant==1 ? (mode?blueberry::lcm_convolution(a,b):blueberry::gcd_convolution(a,b)) : variant==2 ? (mode?blueberry_pr83::lcm_convolution(a,b):blueberry_pr83::gcd_convolution(a,b)) : variant==3 ? (mode?blueberry_hybrid::lcm_convolution(a,b):blueberry_hybrid::gcd_convolution(a,b)) : variant==4 ? (mode?blueberry_hybrid4096::lcm_convolution(a,b):blueberry_hybrid4096::gcd_convolution(a,b)) : (mode?blueberry_hybrid_reserve::lcm_convolution(a,b):blueberry_hybrid_reserve::gcd_convolution(a,b));
    for(std::size_t i=0;i<c.size();i+=std::max<std::size_t>(1,c.size()/101))checksum+=c[i];
  }
  auto ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
  std::cout<<variant<<' '<<mode<<' '<<n<<' '<<reps<<' '<<ms<<' '<<checksum<<'\n';
}
