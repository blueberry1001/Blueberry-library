import ctypes,hashlib,json,os,platform,statistics,subprocess,sys,time
from pathlib import Path
here=Path(__file__).resolve().parent;work=here/'official-work'
repo=Path(os.environ.get('LIBRARY_CHECKER_PROBLEMS', r'C:\Users\kubar\Documents\GitHub\Blueberry-library\.verification\library-checker-problems'))
out={'status':'running','platform':platform.platform(),'cpu':platform.processor(),'note':'Logical CPU4 fixed; process start, scanf, vector copies, transform and printf included. All variants in the same Clang 18 gnu++20 -O2 executable, input and output cached local files; warmup1 plus 8 alternating repetitions. SMT sibling5 and OS may interfere.','hashes':{p:hashlib.sha256((here/p).read_bytes()).hexdigest() for p in ['pr83-original.hpp','hybrid.hpp','official.cpp']},'runs':[]}
def save():(here/'e2e-results.json').write_text(json.dumps(out,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest()
try:
 k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];k.SetProcessAffinityMask.restype=ctypes.c_int
 if not k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<4):raise OSError(ctypes.get_last_error(),'CPU4 affinity failed')
 q=subprocess.run([sys.executable,str(here/'report-affinity.py')],capture_output=True,text=True,errors='replace',timeout=30);out['inherited_affinity']={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};save()
 if q.returncode or json.loads(q.stdout)['process_mask']!='0x10':raise RuntimeError('child affinity not verified')
 for mode,name in enumerate(['gcd_convolution','lcm_convolution']):
  dst=work/name;inp=dst/'e2e-input.tmp';result=dst/'e2e-output.tmp'
  with open(inp,'wb') as f:q=subprocess.run([dst/'max_random.exe','0'],stdout=f,stderr=subprocess.PIPE,timeout=120)
  expected=json.loads((repo/'convolution'/name/'hash.json').read_text())
  if q.returncode or sha(inp)!=expected['max_random_00.in']:raise RuntimeError('generator hash mismatch')
  for rep in range(-1,8):
   for v in ([2,3] if rep%2==0 else [3,2]):
    t=time.perf_counter()
    with open(inp,'rb') as fi,open(result,'wb') as fo:
     q=subprocess.run([work/'candidate.exe',str(mode),str(v)],stdin=fi,stdout=fo,stderr=subprocess.PIPE,timeout=120)
    ms=(time.perf_counter()-t)*1000
    row={'mode':name,'case':'max_random_00','rep':rep,'variant':'pr83' if v==2 else 'hybrid','ms':ms,'exit':q.returncode,'sha256_lf':sha(result),'stderr':q.stderr.decode('utf8','replace')};out['runs'].append(row);save()
    if q.returncode or row['sha256_lf']!=expected['max_random_00.out']:raise RuntimeError('output mismatch')
  for v in ['pr83','hybrid']:
   samples=[s['ms'] for s in out['runs'] if s['mode']==name and s['rep']>=0 and s['variant']==v]
   print(name,v,'median',round(statistics.median(samples),3),'min',round(min(samples),3),'max',round(max(samples),3),flush=True)
  inp.unlink();result.unlink()
 out['status']='complete'
except BaseException as e:
 out['status']='failed';out['error']=repr(e);save();raise
save()
