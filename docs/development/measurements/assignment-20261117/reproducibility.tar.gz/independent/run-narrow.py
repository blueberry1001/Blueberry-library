import hashlib,json,os,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');ver='10.0.22621.0';cl=vc/'bin/Hostx64/x64/cl.exe';clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(cl.parent)+os.pathsep+env.get('PATH','');env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/ver/x for x in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/ver/x/'x64' for x in ('ucrt','um'))]))
out={'candidate_sha256':hashlib.sha256((p/'candidate.hpp').read_bytes()).hexdigest(),'cases':[],'status':'running'}
def save():(p/'narrow-results.json').write_text(json.dumps(out,indent=2)+'\n')
try:
 for ndebug in (False,True):
  exe=p/('narrow-release.exe' if ndebug else 'narrow-debug.exe');cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2']+(['-DNDEBUG'] if ndebug else [])+[str(p/'narrow.cpp'),'-o',str(exe)]
  r=subprocess.run(cmd,cwd=p,env=env,text=True,errors='replace',capture_output=True);row={'command':cmd,'compile_exit':r.returncode,'compile_output':r.stdout+r.stderr};out['cases'].append(row);save()
  if r.returncode:raise RuntimeError('compile failed')
  r=subprocess.run([str(exe)],cwd=p,env=env,text=True,errors='replace',capture_output=True,timeout=240);row.update(run_exit=r.returncode,output=r.stdout+r.stderr);save();print(ndebug,r.returncode,r.stdout+r.stderr,flush=True)
  if r.returncode:raise RuntimeError('test failed')
 out['status']='complete'
except BaseException as e:out['status']='failed';out['error']=repr(e);raise
finally:save()
