#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <vector>
#include "candidate.hpp"
using namespace std;
template<class T> void test(){
 for(int n=1;n<=3;++n) for(int m=n;m<=4;++m){
  uint64_t all=1;for(int i=0;i<n*m;++i)all*=3;
  for(uint64_t k=0;k<all;++k){uint64_t t=k;vector<vector<T>> a(n,vector<T>(m));for(auto& row:a)for(auto& x:row){x=static_cast<T>(int(t%3)-1);t/=3;}
   vector<int> p(m);iota(p.begin(),p.end(),0);int best=999;
   do {int sum=0;for(int i=0;i<n;++i)sum+=int(a[i][p[i]]);best=min(best,sum);}while(next_permutation(p.begin(),p.end()));
   auto [value,match]=jv_candidate::assignment(a);if(int(value)!=best){cerr<<"n="<<n<<" m="<<m<<" k="<<k<<'\n';exit(1);}
  }
 }
}
int main(){test<signed char>();test<short>();test<int>();cout<<"signed char, short, int exhaustive OK\n";}
