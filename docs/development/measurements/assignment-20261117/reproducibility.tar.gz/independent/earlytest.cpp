#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <numeric>
#include <vector>
#include "candidate-early.hpp"
using namespace std;
void test(const vector<vector<int>>& a) {
 int n=a.size(),m=n?a[0].size():0;vector<int> p(m);iota(p.begin(),p.end(),0);int best=numeric_limits<int>::max();
 do {int sum=0;for(int i=0;i<n;++i)sum+=a[i][p[i]];best=min(best,sum);}while(next_permutation(p.begin(),p.end()));
 auto [value,match]=early_candidate::assignment(a);vector<int> used(m);int sum=0;
 if((int)match.size()!=n || value!=best)abort();
 for(int i=0;i<n;++i){int j=match[i];if(j<0||j>=m||used[j]++)abort();sum+=a[i][j];}if(sum!=best)abort();
}
void exhaustive(int n,int m,int base){
 int all=1;for(int i=0;i<n*m;++i)all*=base;
 for(int k=0;k<all;++k){int t=k;vector<vector<int>>a(n,vector<int>(m));for(auto& row:a)for(auto& x:row){x=t%base-base/2;t/=base;}test(a);}
}
int main(){test({});test({{42}});test({{0,9,9},{9,0,9},{9,9,0}});exhaustive(3,3,3);exhaustive(4,4,2);cout<<"early n=0/1 and non-Monge case; 3x3 ternary and 4x4 binary OK\n";}
