#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <numeric>
#include <random>
#include <vector>
#include "candidate.hpp"
using namespace std;
using Wide=__int128;
long long cases=0;
void test(const vector<vector<long long>>& a, const char* label, uint64_t serial){
 int n=a.size(),m=n?a[0].size():0;
 vector<int> p(m);iota(p.begin(),p.end(),0);Wide best=Wide(1)<<125;
 do {Wide sum=0;for(int i=0;i<n;++i)sum+=a[i][p[i]];best=min(best,sum);}while(next_permutation(p.begin(),p.end()));
 if(best<numeric_limits<long long>::min()||best>numeric_limits<long long>::max())return;
 auto [actual,match]=jv_candidate::assignment(a);vector<int> used(m);Wide sum=0;
 if((int)match.size()!=n){cerr<<"length fail "<<label<<' '<<serial<<'\n';exit(1);}
 for(int i=0;i<n;++i){int j=match[i];if(j<0||j>=m||used[j]++){cerr<<"match fail "<<label<<' '<<serial<<'\n';exit(1);}sum+=a[i][j];}
 if(actual!=best||sum!=best){cerr<<"cost fail "<<label<<' '<<serial<<" N="<<n<<" M="<<m<<" expected="<<(long long)best<<" got="<<actual<<'\n';for(auto&row:a){for(auto x:row)cerr<<x<<' ';cerr<<'\n';}exit(1);}
 ++cases;
}
void exhaustive(int n,int m,int base){
 uint64_t total=1;for(int i=0;i<n*m;++i)total*=base;
 for(uint64_t x=0;x<total;++x){uint64_t t=x;vector<vector<long long>> a(n,vector<long long>(m));for(auto& row:a)for(auto&v:row){v=int(t%base)-(base/2);t/=base;}test(a,"exhaustive",x);}
 cout<<"exhaustive "<<n<<'x'<<m<<" domain="<<base<<" OK cases="<<cases<<'\n';
}
int main(){
 test({},"empty",0);exhaustive(3,3,3);exhaustive(4,4,2);exhaustive(3,4,3);
 mt19937_64 rng(0x12935af);
 for(int z=0;z<40000;++z){int n=1+rng()%6,m=n+rng()%(8-n);vector<vector<long long>>a(n,vector<long long>(m));
  for(auto&row:a)for(auto&v:row){auto r=rng();switch(z%5){case 0:v=(long long)(r%5)-2;break;case 1:v=(long long)(r%2000000001)-1000000000;break;case 2:v=(r&1)?(1LL<<62):-(1LL<<62);break;case 3:v=(r&1)?numeric_limits<long long>::max()-(long long)(r%100):numeric_limits<long long>::min()+(long long)(r%100);break;default:v=(long long)(r%3);}}
  test(a,"random",z);
 }
 cout<<"random seed=0x12935af OK total="<<cases<<'\n';
}
