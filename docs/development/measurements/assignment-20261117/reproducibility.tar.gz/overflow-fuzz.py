import random,json
class Overflow(Exception):pass
def add(a,b):
 c=a+b
 if c < -128 or c > 127:raise Overflow((a,b,c))
 return c
def sub(a,b):return add(a,-b)
def old(A):
 n=len(A);m=len(A[0]);u=[0]*(n+1);v=[0]*(m+1);match=[0]*(m+1);way=[0]*(m+1)
 for i in range(1,n+1):
  match[0]=i;sl=[127]*(m+1);used=[False]*(m+1);c=0
  while 1:
   used[c]=True;r=match[c];delta=127;next_=0
   for j in range(1,m+1):
    if not used[j]:
     z=sub(sub(A[r-1][j-1],u[r]),v[j])
     if z<sl[j]:sl[j]=z;way[j]=c
     if sl[j]<delta:delta=sl[j];next_=j
   if not next_:raise Overflow('infinite slack')
   for j in range(m+1):
    if used[j]:u[match[j]]=add(u[match[j]],delta);v[j]=sub(v[j],delta)
    else:sl[j]=sub(sl[j],delta)
   c=next_
   if not match[c]:break
  while c:
   prev=way[c];match[c]=match[prev];c=prev
 out=[0]*n
 for j in range(1,m+1):
  if match[j]:out[match[j]-1]=j-1
 total=0
 for i in range(n):total=add(total,A[i][out[i]])
 return total
def new(A):
 n=len(A);m=len(A[0]);pot=[0]*m;match=[-1]*n;rev=[-1]*m
 for i in range(n-1,-1,-1):
  best=0
  for j in range(1,m):
   if A[i][j]<A[i][best] or (A[i][best]>=A[i][j] and rev[best]!=-1 and rev[j]==-1):best=j
  if rev[best]==-1:match[i]=best;rev[best]=i
 for i in range(n-1,-1,-1):
  if match[i]!=-1:continue
  dist=A[i][:];cols=list(range(m));pred=[i]*m;scan=0
  while 1:
   for j in range(scan,m):
    c=cols[j];d=sub(dist[c],pot[c])
    if j==scan or d<delta:delta=d;cols[scan],cols[j]=cols[j],cols[scan]
   c=cols[scan];scan+=1;r=rev[c]
   if r==-1:break
   for j in range(m):
    z=add(sub(A[r][j],A[r][c]),dist[c])
    if z<dist[j]:dist[j]=z;pred[j]=r
  while scan:
   scan-=1;pot[cols[scan]]=sub(dist[cols[scan]],delta)
  while r!=i:
   r=pred[c];rev[c]=r;c,match[r]=match[r],c
 total=0
 for i in range(n):total=add(total,A[i][match[i]])
 return total
r=random.Random(4278)
for case in range(1000000):
 n=r.randrange(2,6);m=r.randrange(n,6);A=[[r.randrange(-100,101) for j in range(m)] for i in range(n)]
 try:x=old(A)
 except Overflow:continue
 try:y=new(A)
 except Overflow as e:
  print(json.dumps({'matrix':A,'old':x,'new_overflow':e.args}));break
 if x!=y:
  print(json.dumps({'matrix':A,'old':x,'new':y,'wrong':True}));break
else:print('none')
