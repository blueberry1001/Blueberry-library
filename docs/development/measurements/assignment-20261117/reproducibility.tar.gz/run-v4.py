import ctypes,hashlib,json,os,pathlib,platform,statistics,subprocess,time,traceback
r=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10'); v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/p for p in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/p/'x64' for p in ('ucrt','um'))]))
base=(r/'baseline.hpp.txt').read_text(encoding='utf-8')
(r/'baseline.hpp').write_text(base.replace('namespace blueberry {','namespace baseline {'),encoding='utf-8')
(r/'byte.hpp').write_text(base.replace('namespace blueberry {','namespace byte_version {').replace('std::vector<bool> used(m + 1);','std::vector<unsigned char> used(m + 1);'),encoding='utf-8')
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p
k.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
proc=k.GetCurrentProcess();old=ctypes.c_size_t();system=ctypes.c_size_t()
assert k.GetProcessAffinityMask(proc,ctypes.byref(old),ctypes.byref(system));mask=old.value&-old.value;assert k.SetProcessAffinityMask(proc,mask)
d={'status':'running','machine':platform.platform(),'processor':platform.processor(),'affinity':hex(mask),'samples':[],'builds':[],'sources':{}}
for p in ('baseline.hpp.txt','baseline.hpp','byte.hpp','WeightedMatching.reference.txt','driver-v4.cpp','run-v4.py','candidate.hpp','monge.hpp','monge2.hpp'):d['sources'][p]=hashlib.sha256((r/p).read_bytes()).hexdigest()
def save(): (r/'results-v4.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
def call(cmd,timeout=300):
 p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,text=True,errors='replace',timeout=timeout)
 return {'cmd':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
save()
try:
 for compiler in ('clang','msvc'):
  exe=r/(compiler+'-v4.exe')
  if compiler=='clang':cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG',str(r/'driver-v4.cpp'),'-o',str(exe)]
  else:cmd=[str(vc/'bin/Hostx64/x64/cl.exe'),'/nologo','/std:c++20','/O2','/DNDEBUG','/EHsc',str(r/'driver-v4.cpp'),'/Fe:'+str(exe)]
  build=call(cmd);d['builds'].append(build);save()
  if build['exit']:raise RuntimeError('compile failed '+compiler)
  check=call([str(exe)]);d['builds'].append(check);save()
  if check['exit']:raise RuntimeError('correctness failed '+compiler)
  for n,m,kind,reps in [(250,250,0,2),(250,250,1,2),(250,250,2,2),(250,250,3,2),(250,250,4,2),(125,500,0,2),(125,500,1,2),(400,400,0,1)]:
   expect=None
   for run in range(-1,5):
    for idx in range(6):
     ver=(idx+run+6)%6
     p=call([str(exe),str(ver),str(n),str(m),str(kind),str(reps)]);p.update(compiler=compiler,n=n,m=m,kind=kind,reps=reps,run=run,variant=ver);d['samples'].append(p);save()
     if p['exit']:raise RuntimeError('run failed')
     a=p['stdout'].split()
     if len(a)!=2:raise RuntimeError('bad output')
     if expect is None:expect=a[1]
     if expect!=a[1]:raise RuntimeError('different cost')
 d['status']='complete';save()
except BaseException:
 d['status']='failed';d['traceback']=traceback.format_exc();save();raise
