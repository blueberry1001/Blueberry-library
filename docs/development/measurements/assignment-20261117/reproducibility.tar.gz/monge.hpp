#pragma once
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <limits>
#include <type_traits>
#include <utility>
#include <vector>

namespace monge_candidate {
template <class T>
std::pair<T, std::vector<int>> assignment(const std::vector<std::vector<T>>& cost) {
  assert(cost.size() < static_cast<std::size_t>(std::numeric_limits<int>::max()));
  const int n = static_cast<int>(cost.size());
  if (!n) return {T{}, {}};
  assert(cost[0].size() < static_cast<std::size_t>(std::numeric_limits<int>::max()));
  const int m = static_cast<int>(cost[0].size());
  assert(n <= m);
  for (const auto& row : cost) { assert(row.size() == cost[0].size()); (void)row; }
#if defined(__SIZEOF_INT128__)
  using Wide = __int128;
#else
  using Wide = std::int64_t;
#endif
  if constexpr (std::is_integral_v<T> && sizeof(T) < sizeof(Wide)) {
    if (n == m) {
      int directions = 3;
      for (int i = 1; i < n && directions; ++i) for (int j = 1; j < m; ++j) {
        Wide a = Wide(cost[i-1][j-1]) + Wide(cost[i][j]);
        Wide b = Wide(cost[i-1][j]) + Wide(cost[i][j-1]);
        if (b < a) directions &= 2;
        if (a < b) directions &= 1;
        if (!directions) break;
      }
      if (directions) {
        T total{}; std::vector<int> match(n);
        for (int i = 0; i < n; ++i) { match[i] = directions & 1 ? i : n - 1 - i; total += cost[i][match[i]]; }
        return {total, std::move(match)};
      }
    }
  }
  std::vector<T> dist(m), potential(m);
  std::vector<int> match(n), reverse(m, -1), columns(m), previous(m);
  for (int i = n - 1; i >= 0; --i) {
    for (int j = 0; j < m; ++j) { dist[j] = cost[i][j]; columns[j] = j; previous[j] = i; }
    int scanned = 0, column, row;
    T distance{};
    while (true) {
      for (int j = scanned; j < m; ++j) {
        int c = columns[j]; T next = dist[c] - potential[c];
        if (j == scanned || next < distance) { distance = next; std::swap(columns[scanned], columns[j]); }
      }
      column = columns[scanned++]; row = reverse[column];
      if (row == -1) break;
      const auto& values = cost[row];
      for (int j = 0; j < m; ++j) {
        T next = values[j] - values[column] + dist[column];
        if (next < dist[j]) { dist[j] = next; previous[j] = row; }
      }
    }
    while (scanned--) potential[columns[scanned]] = dist[columns[scanned]] - distance;
    while (row != i) {
      row = previous[column]; reverse[column] = row;
      std::swap(column, match[row]);
    }
  }
  T total{};
  for (int i = 0; i < n; ++i) total += cost[i][match[i]];
  return {total, std::move(match)};
}
}
