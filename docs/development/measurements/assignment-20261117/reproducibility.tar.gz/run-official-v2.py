import ctypes,hashlib,json,os,pathlib,platform,shutil,statistics,subprocess,time,traceback
r=pathlib.Path(__file__).resolve().parent
origin=pathlib.Path(r'C:\Users\kubar\Documents\GitHub\Blueberry-library\.verification\library-checker-problems')
task=origin/'graph/assignment';tmp=r/'official-work-v2';gen=tmp/'gen';gen.mkdir(parents=True,exist_ok=True)
for f in (task/'gen').iterdir():shutil.copy2(f,gen/f.name)
shutil.copy2(origin/'common/random.h',tmp/'random.h')
(tmp/'params.h').write_text('#pragma once\n#define N_MIN 1\n#define N_MAX 500\n#define A_ABS_MAX 1000000000\n')
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10');ver='10.0.22621.0'
cc=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/ver/p for p in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/ver/p/'x64' for p in ('ucrt','um'))]))
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p
k.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
proc=k.GetCurrentProcess();old=ctypes.c_size_t();system=ctypes.c_size_t()
assert k.GetProcessAffinityMask(proc,ctypes.byref(old),ctypes.byref(system));mask=old.value&-old.value;assert k.SetProcessAffinityMask(proc,mask)
log={'status':'running','machine':platform.platform(),'processor':platform.processor(),'affinity':hex(mask),'compiler':str(cc),'runs':3,'warmups':1,'builds':[],'cases':[],'origin_head':None,'sources':{}}
def save():(r/'official-results-v2.json').write_text(json.dumps(log,indent=2)+'\n',encoding='utf-8')
def sha(b):return hashlib.sha256(b).hexdigest()
def call(cmd,data=None,timeout=120):
 start=time.perf_counter();p=subprocess.run(cmd,cwd=tmp,env=env,input=data,capture_output=True,timeout=timeout)
 return {'cmd':list(map(str,cmd)),'exit':p.returncode,'wall_seconds':time.perf_counter()-start,'stderr':p.stderr.decode(errors='replace')},p.stdout
try:
 p=subprocess.run(['git','-C',str(origin),'rev-parse','HEAD'],capture_output=True,text=True,check=True);log['origin_head']=p.stdout.strip()
 for name in ('official-early.cpp','jv-early.hpp','baseline.hpp.txt','fastest-410724.hpp','run-official-v2.py'):log['sources'][name]=sha((r/name).read_bytes())
 def build(name,src,extra=[]):
  out=tmp/(name+'.exe');cmd=[cc,'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG',*extra,src,'-o',out];res,stdout=call(cmd);res['stdout']=stdout.decode(errors='replace');log['builds'].append(res);save()
  if res['exit']:raise RuntimeError('compile failure '+name)
  return out
 driver=build('driver',r/'official-early.cpp')
 reference=build('correct',task/'sol/correct.cpp')
 generators={name:build(name,gen/(name+'.cpp'),['-I',tmp]) for name in ('random','max_random','hand_plus','hand_minus','multiplication_table')}
 expected=json.loads((task/'hash.json').read_text())
 cases=[('example_00',(gen/'example_00.in').read_bytes().replace(b'\r\n',b'\n'))]
 for name,count in [('random',5),('max_random',5),('hand_plus',1),('hand_minus',1),('multiplication_table',1)]:
  for seed in range(count):
   res,data=call([generators[name],str(seed)]);data=data.replace(b'\r\n',b'\n')
   if res['exit']:raise RuntimeError('generator failure '+name)
   cases.append((name+'_'+str(seed).zfill(2),data))
 for name,data in cases:
  case={'name':name,'input_sha256':sha(data),'expected_input_sha256':expected[name+'.in'],'runs':[]};log['cases'].append(case);save()
  if case['input_sha256']!=case['expected_input_sha256']:raise RuntimeError('official input hash mismatch '+name)
  tok=list(map(int,data.split()));n=tok[0];a=tok[1:]
  res,out=call([reference],data);case['reference']=res;case['reference_output_sha256']=sha(out.replace(b'\r\n',b'\n'))
  if res['exit']:raise RuntimeError('official reference error')
  correct=int(out.split()[0]);case['correct_cost']=correct
  for rep in range(-1,3):
   for i in range(3):
    version=(i+rep+3)%3;res,out=call([driver,str(version)],data);v=list(map(int,out.split()));case['runs'].append({**res,'version':version,'rep':rep,'output_sha256':sha(out),'cost':v[0] if v else None});save()
    if res['exit'] or len(v)!=n+1 or v[0]!=correct or sorted(v[1:])!=list(range(n)) or sum(a[i*n+v[i+1]] for i in range(n))!=correct:
     case['failed_output']=out.decode(errors='replace');save();raise RuntimeError('wrong answer '+name+' '+str(version))
 log['status']='complete';save()
except BaseException:
 log['status']='failed';log['traceback']=traceback.format_exc();save();raise
