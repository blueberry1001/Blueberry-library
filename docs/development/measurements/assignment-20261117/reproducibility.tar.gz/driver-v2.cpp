#include <algorithm>
#include <chrono>
#include <climits>
#include <cstdlib>
#include <iostream>
#include <random>
#include <utility>
#include <vector>
using namespace std;
#include "baseline.hpp"
#include "byte.hpp"
#include "candidate.hpp"
using vi = vector<int>;
#define sz(x) (int)(x).size()
#define rep(i,a,b) for(int i=(a);i<(b);++i)
#include "WeightedMatching.reference.txt"
using ll=long long;
using Mat=vector<vector<ll>>;
pair<ll,vector<int>> solve(int version, Mat& a) {
  if(version==0) return baseline::assignment(a);
  if(version==1) return byte_version::assignment(a);
  if(version==2) return weightedMatching(a);
  return candidate::assignment(a);
}
ll brute(const Mat& a) {
  ll best=LLONG_MAX;
  auto go=[&](auto&& self,int i,int used,ll cost)->void {
    if(i==(int)a.size()){best=min(best,cost);return;}
    for(int j=0;j<(int)a[0].size();++j)if(!(used>>j&1)) self(self,i+1,used|1<<j,cost+a[i][j]);
  };
  if(a.empty())return 0;
  go(go,0,0,0);return best;
}
void check(Mat a, ll expected) {
  for(int v=0;v<4;++v){
    auto [cost,match]=solve(v,a);
    if(cost!=expected||match.size()!=a.size())abort();
    ll total=0;vector<int> seen(a.empty()?0:a[0].size());
    for(int i=0;i<(int)a.size();++i){
      int j=match[i];
      if(j<0||j>=(int)seen.size()||seen[j]++)abort();
      total+=a[i][j];
    }
    if(total!=cost)abort();
  }
}
Mat make_mat(int n,int m,int kind,int seed){
  mt19937 rng(seed);Mat a(n,vector<ll>(m));
  vector<ll> x(n),y(m);
  for(auto& v:x)v=(int)(rng()%20001)-10000;
  for(auto& v:y)v=(int)(rng()%20001)-10000;
  for(int i=0;i<n;++i)for(int j=0;j<m;++j) {
    if(kind==0)a[i][j]=(int)(rng()%20001)-10000;
    if(kind==1)a[i][j]=(int)(rng()%3)-1;
    if(kind==2)a[i][j]=x[i]+y[j];
    if(kind==3)a[i][j]=0;
    if(kind==4)a[i][j]=abs(i-j);
    if(kind==5)a[i][j]=i==j?0:1;
  }
  return a;
}
int main(int argc,char** argv){
  if(argc==1){
    check({},0);
    mt19937 rng(73914);
    for(int n=1;n<=7;++n)for(int m=n;m<=8;++m)for(int t=0;t<80;++t){
      Mat a=make_mat(n,m,t%6,rng());check(a,brute(a));
    }
    for(int n:{10,40,100})for(int m:{n,n+7,2*n})for(int k=0;k<6;++k){
      Mat a=make_mat(n,m,k,n*1000+m*10+k);ll expected=solve(0,a).first;check(a,expected);
    }
    cout<<"correctness ok\n";return 0;
  }
  int ver=atoi(argv[1]),n=atoi(argv[2]),m=atoi(argv[3]),kind=atoi(argv[4]),reps=atoi(argv[5]);
  Mat a=make_mat(n,m,kind,18290+n+m+kind);
  auto begin=chrono::steady_clock::now();ll checksum=0;
  for(int r=0;r<reps;++r)checksum+=solve(ver,a).first;
  auto end=chrono::steady_clock::now();
  cout<<chrono::duration<double,milli>(end-begin).count()<<" "<<checksum<<"\n";
}
