#pragma once
#include <algorithm>
#include <cassert>
#include <limits>
#include <cstdint>
#include <type_traits>
#include <utility>
#include <vector>

namespace safe_candidate { namespace detail {
template <class T>
std::pair<T, std::vector<int>> assignment_old(const std::vector<std::vector<T>>& cost) {
  assert(cost.size() < static_cast<std::size_t>(std::numeric_limits<int>::max()));
  const int n = static_cast<int>(cost.size());
  if (n == 0) return {T{}, {}};
  assert(cost[0].size() < static_cast<std::size_t>(std::numeric_limits<int>::max()));
  const int m = static_cast<int>(cost[0].size());
  assert(n <= m);
  for (const auto& row : cost) { assert(row.size() == cost[0].size()); (void)row; }
  std::vector<T> row_potential(n + 1), col_potential(m + 1), slack(m + 1);
  std::vector<int> matched(m + 1), previous(m + 1);
  std::vector<bool> used(m + 1);
  for (int row = 1; row <= n; ++row) {
    matched[0] = row;
    std::fill(slack.begin(), slack.end(), std::numeric_limits<T>::max());
    std::fill(used.begin(), used.end(), false);
    int col = 0;
    do {
      used[col] = true;
      const int active = matched[col];
      T delta = std::numeric_limits<T>::max();
      int next = 0;
      for (int j = 1; j <= m; ++j) if (!used[j]) {
        const T reduced = cost[active - 1][j - 1] - row_potential[active] - col_potential[j];
        if (reduced < slack[j]) { slack[j] = reduced; previous[j] = col; }
        if (slack[j] < delta) { delta = slack[j]; next = j; }
      }
      assert(next != 0);
      for (int j = 0; j <= m; ++j) {
        if (used[j]) { row_potential[matched[j]] += delta; col_potential[j] -= delta; }
        else slack[j] -= delta;
      }
      col = next;
    } while (matched[col] != 0);
    do {
      const int prev = previous[col];
      matched[col] = matched[prev]; col = prev;
    } while (col != 0);
  }
  std::vector<int> match(n);
  for (int j = 1; j <= m; ++j) if (matched[j]) match[matched[j] - 1] = j - 1;
  T total{};
  for (int i = 0; i < n; ++i) total += cost[i][match[i]];
  return {total, std::move(match)};
}
}}

namespace safe_candidate { namespace detail {
template <class T, class Wide>
std::pair<T, std::vector<int>> assignment_wide(const std::vector<std::vector<T>>& cost) {
  assert(cost.size() < static_cast<std::size_t>(std::numeric_limits<int>::max()));
  const int n = static_cast<int>(cost.size());
  if (!n) return {T{}, {}};
  assert(cost[0].size() < static_cast<std::size_t>(std::numeric_limits<int>::max()));
  const int m = static_cast<int>(cost[0].size());
  assert(n <= m);
  for (const auto& row : cost) { assert(row.size() == cost[0].size()); (void)row; }
  if (n == m) {
    int directions = 3;
    for (int i = 1; i < n && directions; ++i) for (int j = 1; j < m; ++j) {
      Wide a = Wide(cost[i-1][j-1]) + Wide(cost[i][j]);
      Wide b = Wide(cost[i-1][j]) + Wide(cost[i][j-1]);
      if (b < a) directions &= 2;
      if (a < b) directions &= 1;
      if (!directions) break;
    }
    if (directions) {
      Wide total{}; std::vector<int> match(n);
      for (int i = 0; i < n; ++i) { match[i] = directions & 1 ? i : n - 1 - i; total += Wide(cost[i][match[i]]); }
      return {static_cast<T>(total), std::move(match)};
    }
  }
  std::vector<Wide> dist(m), potential(m);
  std::vector<int> match(n, -1), reverse(m, -1), columns(m), previous(m);
  for (int i = n - 1; i >= 0; --i) {
    int best = 0;
    for (int j = 1; j < m; ++j)
      if (cost[i][j] < cost[i][best] || (!(cost[i][best] < cost[i][j]) && reverse[best] != -1 && reverse[j] == -1)) best = j;
    if (reverse[best] == -1) { match[i] = best; reverse[best] = i; }
  }
  for (int i = n - 1; i >= 0; --i) {
    if (match[i] != -1) continue;
    for (int j = 0; j < m; ++j) { dist[j] = cost[i][j]; columns[j] = j; previous[j] = i; }
    int scanned = 0, column, row;
    Wide distance{};
    while (true) {
      for (int j = scanned; j < m; ++j) {
        int c = columns[j]; Wide next = dist[c] - potential[c];
        if (j == scanned || next < distance) { distance = next; std::swap(columns[scanned], columns[j]); }
      }
      column = columns[scanned++]; row = reverse[column];
      if (row == -1) break;
      const auto& values = cost[row];
      for (int j = 0; j < m; ++j) {
        Wide next = Wide(values[j]) - Wide(values[column]) + dist[column];
        if (next < dist[j]) { dist[j] = next; previous[j] = row; }
      }
    }
    while (scanned--) potential[columns[scanned]] = dist[columns[scanned]] - distance;
    while (row != i) {
      row = previous[column]; reverse[column] = row;
      std::swap(column, match[row]);
    }
  }
  Wide total{};
  for (int i = 0; i < n; ++i) total += Wide(cost[i][match[i]]);
  return {static_cast<T>(total), std::move(match)};
}
}}

namespace safe_candidate {
template <class T>
std::pair<T, std::vector<int>> assignment(const std::vector<std::vector<T>>& cost) {
  if constexpr (std::is_integral_v<T> && std::is_signed_v<T> && sizeof(T) <= 4) {
    if (cost.size() <= 4096) return detail::assignment_wide<T, std::int64_t>(cost);
  }
  else if constexpr (std::is_integral_v<T> && std::is_signed_v<T> && sizeof(T) <= 8) {
    if (cost.size() <= 4096) {
      bool small = true;
      for (const auto& row : cost) {
        for (T x : row) if (x < std::numeric_limits<std::int32_t>::min() || std::numeric_limits<std::int32_t>::max() < x) { small = false; break; }
        if (!small) break;
      }
      if (small) return detail::assignment_wide<T, std::int64_t>(cost);
#if defined(__SIZEOF_INT128__)
      return detail::assignment_wide<T, __int128>(cost);
#endif
    }
  }
  return detail::assignment_old(cost);
}
}
