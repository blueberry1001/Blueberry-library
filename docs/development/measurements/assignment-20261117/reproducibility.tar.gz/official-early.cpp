#include <algorithm>
#include <climits>
#include <cstdlib>
#include <iostream>
#include <utility>
#include <vector>
using namespace std;
using ll=long long;
#include "baseline.hpp"
#include "jv-early.hpp"
#include "fastest-410724.hpp"
int main(int argc,char** argv) {
  ios::sync_with_stdio(false);cin.tie(nullptr);
  int n;cin>>n; vector<vector<ll>> cost(n,vector<ll>(n));
  for(auto& row:cost)for(auto& x:row)cin>>x;
  int which=atoi(argv[1]);
  pair<ll,vector<int>> result;
  if(which==0) result=baseline::assignment(cost);
  else if(which==1) result=early_candidate::assignment(cost);
  else {vector<int> flat;flat.reserve(n*n);for(auto& row:cost)for(auto x:row)flat.push_back((int)x);result=hungarian(n,flat);}
  cout<<result.first<<"\n";
  for(int x:result.second)cout<<x<<" ";
  cout<<"\n";
}
