import ctypes,hashlib,json,os,pathlib,platform,statistics,subprocess,time,traceback
r=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10'); v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/p for p in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/p/'x64' for p in ('ucrt','um'))]))

log={'status':'running','builds':[]}
def save(): (r/'validation-safe-results.json').write_text(json.dumps(log,indent=2)+'\n',encoding='utf-8')
def call(cmd):
 p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,text=True,errors='replace',timeout=300)
 return {'cmd':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
try:
 for cc in ('clang','msvc'):
  for std in ('20','23'):
   for release in (False,True):
    exe=r/('validate-safe-'+cc+'-'+std+'-'+str(release)+'.exe')
    if cc=='clang':cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++'+std,'-O2',*(['-DNDEBUG'] if release else []),str(r/'validation-safe.cpp'),'-o',str(exe)]
    else:cmd=[str(vc/'bin/Hostx64/x64/cl.exe'),'/nologo','/std:'+('c++20' if std=='20' else 'c++latest'),'/O2',*(['/DNDEBUG'] if release else []),'/EHsc',str(r/'validation-safe.cpp'),'/Fe:'+str(exe)]
    p=call(cmd);log['builds'].append(p);save()
    if p['exit']:raise RuntimeError('build failure')
    p=call([str(exe)]);log['builds'].append(p);save()
    if p['exit']:raise RuntimeError('validation failure')
 log['status']='complete';save()
except BaseException:
 import traceback;log['status']='failed';log['traceback']=traceback.format_exc();save();raise
