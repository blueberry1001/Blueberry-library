#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <limits>
#include <random>
#include <vector>
#include "baseline.hpp"
#include "monge.hpp"
using namespace std;
template<class T> void run() {
  mt19937_64 rng(4211);
  for(int n=0;n<=9;++n)for(int m=n;m<=n+6;++m)for(int k=0;k<120;++k) {
    vector<vector<T>> a(n,vector<T>(m));
    for(int i=0;i<n;++i)for(int j=0;j<m;++j) {
      if(k%4==0) a[i][j]=T(int(rng()%3)-1);
      else if(k%4==1) a[i][j]=T(i*3-j*2);
      else a[i][j]=T(int(rng()%2000001)-1000000);
    }
    auto [x,p]=baseline::assignment(a);
    auto [y,q]=monge_candidate::assignment(a);
    if(x!=y||q.size()!=a.size())abort();
    T sum{};vector<int> seen(m);
    for(int i=0;i<n;++i){int j=q[i];if(j<0||j>=m||seen[j]++)abort();sum+=a[i][j];}
    if(sum!=y)abort();
  }
}
int main(){run<int>();run<long long>();run<float>();run<double>();run<long double>();}
