/*
Source: https://judge.yosupo.jp/submission/410724
Adapted from gatagat/lap (_lapjv_cpp/lapjv.cpp), with integer arithmetic,
bounded row reduction, reusable buffers, and a Monge shortcut.
https://github.com/gatagat/lap/tree/e29341d9e0ec8c3a1f11f239eb65a31973f4a0ab

BSD 2-Clause License
Copyright (c) 2012-2025, Tomas Kazmar

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

pair<ll, vector<int>> hungarian(int n, const vector<int>& a) {
    if (n == 0) return {0, {}};
    auto c = [&](int i, int j) -> ll {
        return a[size_t(i) * n + j];
    };
    vector<int> x(n, -1), y(n, -1);
    vector<ll> v(n);
    auto result = [&]() {
        ll total = 0;
        for (int i = 0; i < n; ++i) total += c(i, x[i]);
        return pair<ll, vector<int>>{total, move(x)};
    };

    int directions = 3;
    for (int i = 1; i < n && directions; ++i)
        for (int j = 1; j < n; ++j) {
            ll d = c(i - 1, j - 1) + c(i, j)
                 - c(i - 1, j) - c(i, j - 1);
            if (d > 0) directions &= 2;
            if (d < 0) directions &= 1;
            if (!directions) break;
        }
    if (directions) {
        for (int i = 0; i < n; ++i)
            x[i] = directions & 1 ? i : n - 1 - i;
        return result();
    }

    vector<int> minimum(a.begin(), a.begin() + n);
    fill(y.begin(), y.end(), 0);
    for (int i = 1; i < n; ++i) {
        const int* row = a.data() + size_t(i) * n;
        for (int j = 0; j < n; ++j) {
            bool better = row[j] < minimum[j];
            minimum[j] = better ? row[j] : minimum[j];
            y[j] = better ? i : y[j];
        }
    }
    for (int j = 0; j < n; ++j) v[j] = minimum[j];

    vector<char> unique(n, 1);
    for (int j = n - 1; j >= 0; --j) {
        int i = y[j];
        if (x[i] == -1) x[i] = j;
        else unique[i] = 0, y[j] = -1;
    }

    vector<int> free_rows, deferred;
    free_rows.reserve(n);
    deferred.reserve(n);
    for (int i = 0; i < n; ++i) {
        if (x[i] == -1) free_rows.push_back(i);
        else if (unique[i]) {
            ll slack = LLONG_MAX;
            for (int j = 0; j < n; ++j)
                if (j != x[i]) slack = min(slack, c(i, j) - v[j]);
            v[x[i]] -= slack;
        }
    }

    for (int pass = 0; pass < 2 && !free_rows.empty(); ++pass) {
        deferred.clear();
        int head = 0, work = 0;
        while (head < int(free_rows.size()) && work++ < n) {
            int i = free_rows[head++], first = 0;
            ll best = c(i, 0) - v[0], second = LLONG_MAX;
            for (int j = 1; j < n; ++j) {
                ll value = c(i, j) - v[j];
                if (value < best)
                    second = best, best = value, first = j;
                else
                    second = min(second, value);
            }

            bool lower = best < second;
            if (lower) {
                v[first] -= second - best;
            } else if (y[first] != -1) {
                for (int j = 0; j < n; ++j)
                    if (y[j] == -1 && c(i, j) - v[j] == best) {
                        first = j;
                        break;
                    }
            }

            int old = y[first];
            x[i] = first;
            y[first] = i;
            if (old != -1) {
                x[old] = -1;
                if (lower) free_rows[--head] = old;
                else deferred.push_back(old);
            }
        }
        deferred.insert(
            deferred.end(), free_rows.begin() + head, free_rows.end());
        free_rows.swap(deferred);
    }

    vector<int> columns(n), pred(n);
    vector<ll> dist(n);
    for (int root : free_rows) {
        for (int j = 0; j < n; ++j) {
            columns[j] = j;
            pred[j] = root;
            dist[j] = c(root, j) - v[j];
        }
        int scanned = 0, labeled = 0, sink = -1;
        ll level = 0;

        while (sink == -1) {
            if (scanned == labeled) {
                level = dist[columns[scanned]];
                for (int k = scanned; k < n; ++k) {
                    int j = columns[k];
                    if (dist[j] > level) continue;
                    if (dist[j] < level)
                        level = dist[j], labeled = scanned, sink = -1;
                    swap(columns[k], columns[labeled++]);
                    if (y[j] == -1) sink = j;
                }
                if (sink != -1) break;
            }

            while (scanned < labeled && sink == -1) {
                int assigned = columns[scanned++], i = y[assigned];
                ll offset = c(i, assigned) - v[assigned] - level;
                for (int k = labeled; k < n; ++k) {
                    int j = columns[k];
                    ll candidate = c(i, j) - v[j] - offset;
                    if (candidate >= dist[j]) continue;
                    dist[j] = candidate;
                    pred[j] = i;
                    if (candidate == level) {
                        if (y[j] == -1) {
                            sink = j;
                            break;
                        }
                        swap(columns[k], columns[labeled++]);
                    }
                }
            }
        }

        for (int k = 0; k < scanned; ++k) {
            int j = columns[k];
            v[j] += dist[j] - dist[sink];
        }
        while (sink != -1) {
            int i = pred[sink], old = x[i];
            x[i] = sink;
            y[sink] = i;
            sink = old;
        }
    }
    return result();
}
