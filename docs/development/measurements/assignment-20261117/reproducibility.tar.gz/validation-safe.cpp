#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <random>
#include <vector>
#include "baseline.hpp"
#include "safe.hpp"
struct Num {
  long long value=0;
  Num()=default;
  Num(long long v):value(v){}
  Num& operator+=(Num v){value+=v.value;return *this;}
  Num& operator-=(Num v){value-=v.value;return *this;}
  friend Num operator+(Num a,Num b){return a.value+b.value;}
  friend Num operator-(Num a,Num b){return a.value-b.value;}
  friend bool operator<(Num a,Num b){return a.value<b.value;}
};
namespace std {
template<> class numeric_limits<Num> {
 public: static Num max(){return Num(numeric_limits<long long>::max());}
};
}
using namespace std;
template<class T> void integer_tests() {
  mt19937_64 rng(4211);
  for(int n=0;n<=8;++n)for(int m=n;m<=n+5;++m)for(int k=0;k<160;++k) {
    vector<vector<T>> a(n,vector<T>(m));
    for(int i=0;i<n;++i)for(int j=0;j<m;++j) {
      if(k%6==0) a[i][j]=T(int(rng()%3)-1);
      else if(k%6==1) a[i][j]=T(i*3-j*2);
      else if(k%6==2) a[i][j]=T(i*j);
      else if(k%6==3) a[i][j]=T(-i*j);
      else a[i][j]=T(int(rng()%2000001)-1000000);
    }
    auto [x,p]=baseline::assignment(a); auto [y,q]=safe_candidate::assignment(a);
    if(x.value!=y.value||q.size()!=a.size())abort();
    T sum{};vector<int> seen(m);
    for(int i=0;i<n;++i){int j=q[i];if(j<0||j>=m||seen[j]++)abort();sum+=a[i][j];}
    if(sum.value!=y.value)abort();
  }
}
template<class T> void builtin_tests() {
  mt19937_64 rng(91827);
  for(int n=0;n<=8;++n)for(int m=n;m<=n+5;++m)for(int k=0;k<160;++k) {
    vector<vector<T>> a(n,vector<T>(m));
    for(int i=0;i<n;++i)for(int j=0;j<m;++j) {
      if(k%6==0) a[i][j]=T(int(rng()%3)-1);
      else if(k%6==1) a[i][j]=T(i*3-j*2);
      else if(k%6==2) a[i][j]=T(i*j);
      else if(k%6==3) a[i][j]=T(-i*j);
      else a[i][j]=T(int(rng()%2000001)-1000000);
    }
    auto [x,p]=baseline::assignment(a); auto [y,q]=safe_candidate::assignment(a);
    if(x!=y||q.size()!=a.size())abort();
    T sum{};vector<int> seen(m);
    for(int i=0;i<n;++i){int j=q[i];if(j<0||j>=m||seen[j]++)abort();sum+=a[i][j];}
    if(sum!=y)abort();
  }
}
void floating_tests() {
  mt19937_64 rng(3151);
  for(int n=1;n<=7;++n)for(int m=n;m<=7;++m)for(int k=0;k<200;++k) {
    vector<vector<double>> a(n,vector<double>(m));
    for(auto& row:a)for(auto& x:row)x=(int(rng()%200000)-100000)/37.0;
    auto [result,match]=safe_candidate::assignment(a);
    long double best=numeric_limits<long double>::max();
    auto go=[&](auto&& self,int i,int bits,long double sum)->void {
      if(i==n){best=min(best,sum);return;}
      for(int j=0;j<m;++j)if(!(bits&(1<<j)))self(self,i+1,bits|1<<j,sum+a[i][j]);
    };
    go(go,0,0,0);
    long double actual=0;vector<int> seen(m);
    for(int i=0;i<n;++i){int j=match[i];if(j<0||j>=m||seen[j]++)abort();actual+=a[i][j];}
    if(fabsl(actual-best)>1e-8L || fabsl(result-actual)>1e-8L)abort();
  }
}
void wide_tests() {
  mt19937_64 rng(127);
  for(int n=1;n<=8;++n)for(int m=n;m<=n+4;++m)for(int k=0;k<300;++k){
    vector<vector<long long>> a(n,vector<long long>(m));
    for(auto& row:a)for(auto& x:row)x=(long long)(rng()%20000000000000001ULL)-10000000000000000LL;
    auto [x,p]=baseline::assignment(a);auto [y,q]=safe_candidate::assignment(a);
    if(x!=y)abort();
  }
}
void overflow_regression() {
  vector<vector<int>> a{{82,6,28,57,33},{6,-46,14,51,23},{61,-44,-64,1,49}};
  for(auto& row:a)for(auto& x:row)x*=16000000;
  long long brute=numeric_limits<long long>::max();
  for(int i=0;i<5;++i)for(int j=0;j<5;++j)for(int k=0;k<5;++k)if(i!=j&&i!=k&&j!=k)
    brute=min(brute,(long long)a[0][i]+a[1][j]+a[2][k]);
  auto old=baseline::assignment(a);auto fresh=safe_candidate::assignment(a);
  if(brute!=-1232000000LL||old.first!=brute||fresh.first!=brute)abort();
}
int main(){overflow_regression();integer_tests<Num>();builtin_tests<int>();builtin_tests<long long>();builtin_tests<float>();builtin_tests<double>();builtin_tests<long double>();floating_tests();wide_tests();puts("type and range tests passed");}
