#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <numeric>
#include <vector>
#include "candidate.hpp"
using namespace std;
using Wide=__int128;
long long tested=0,skipped=0;
void test(const vector<vector<long long>>&a,int id){
 int n=a.size(),m=n?a[0].size():0;vector<int>p(m);iota(p.begin(),p.end(),0);Wide best=Wide(1)<<125;
 do{Wide sum=0;for(int i=0;i<n;++i)sum+=Wide(a[i][p[i]]);best=min(best,sum);}while(next_permutation(p.begin(),p.end()));
 if(best<numeric_limits<long long>::min()||best>numeric_limits<long long>::max()){++skipped;return;}
 auto [x,match]=blueberry::assignment(a);if((int)match.size()!=n||Wide(x)!=best){cerr<<"FAIL id="<<id<<" n="<<n<<" m="<<m<<'\n';exit(1);}vector<int>used(m);Wide sum=0;for(int i=0;i<n;++i){int j=match[i];if(j<0||j>=m||used[j]++)abort();sum+=a[i][j];}if(sum!=best)abort();++tested;
}
int main(){
 test({},0);
 long long lo=numeric_limits<long long>::min(),hi=numeric_limits<long long>::max();vector<long long>v{lo,lo+1,-(1LL<<62),-1,0,1,(1LL<<62),hi-1,hi};
 for(int m:{1,2,3})for(auto x:v){vector<vector<long long>>a(1,vector<long long>(m,x));test(a,1);}
 test({{hi,lo,0}},2);test({{lo,hi}},3);test({{1,-1}},4);
 for(int m:{2,3}){int cnt=1;for(int i=0;i<2*m;++i)cnt*=int(v.size());for(int k=0;k<cnt;++k){int t=k;vector<vector<long long>>a(2,vector<long long>(m));for(auto& row:a)for(auto&x:row){x=v[t%v.size()];t/=v.size();}test(a,k);}}
 cout<<"OK int64 extreme values: tested="<<tested<<" skipped optimal sum outside int64="<<skipped<<'\n';
}
