import ctypes,hashlib,json,os,pathlib,platform,statistics,subprocess,time,traceback
r=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10'); v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/p for p in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/p/'x64' for p in ('ucrt','um'))]))

import random,sys
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p
k.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
p=k.GetCurrentProcess();old=ctypes.c_size_t();system=ctypes.c_size_t()
assert k.GetProcessAffinityMask(p,ctypes.byref(old),ctypes.byref(system));mask=1<<8;assert old.value&mask;assert k.SetProcessAffinityMask(p,mask)
d={'status':'running','repository':'blueberry1001/Blueberry-library','pr84_head':'9453928201ceae304aad81d77f95ddbf992cd2f3','pr84_git_blob':'d0f89a1c731e3d12db552677024cb3976fb0a3ee','machine':platform.platform(),'processor':platform.processor(),'affinity':hex(mask),'sources':{},'runs':[],'builds':[]}
for f in ('pr84.snapshot.hpp','ours.snapshot.hpp','baseline.hpp','pr84.hpp','ours.hpp','combined.hpp','combined.snapshot.hpp','combined-v3.hpp','combined-v3.snapshot.hpp','combined-v4.hpp','combined-v4.snapshot.hpp','combined-v5.hpp','combined-v5.snapshot.hpp','compare-gate.cpp','run-gate.py'):d['sources'][f]=hashlib.sha256((r/f).read_bytes()).hexdigest()
def save(): (r/'comparison-gate.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
def call(cmd):
 start=time.perf_counter();p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,text=True,errors='replace',timeout=240)
 return {'cmd':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'wall_seconds':time.perf_counter()-start}
save()
try:
 for compiler in ('clang','msvc'):
  exe=r/('compare-gate-'+compiler+'.exe')
  if compiler=='clang':cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG',str(r/'compare-gate.cpp'),'-o',str(exe)]
  else:cmd=[str(vc/'bin/Hostx64/x64/cl.exe'),'/nologo','/std:c++20','/O2','/DNDEBUG','/EHsc',str(r/'compare-gate.cpp'),'/Fe:'+str(exe)]
  result=call(cmd);d['builds'].append(result);save()
  if result['exit']:raise RuntimeError('compile failed '+compiler)
  result=call([str(exe)]);d['builds'].append(result);save()
  if result['exit']:raise RuntimeError('differential test failed '+compiler)
  for n,m,kind,reps in [(8,16384,0,3),(8,16384,1,3),(8,16384,6,3),(32,8192,0,3),(32,8192,1,3),(32,8192,6,3),(64,2048,0,2),(64,2048,1,2),(64,2048,6,2),(65,520,1,3),(65,521,0,3),(65,521,1,3),(65,521,6,3)]:
   expect=None
   for sample in range(-1,7):
    for j in range(7):
     v=(j+sample+7)%7
     result=call([str(exe),str(v),str(n),str(m),str(kind),str(reps)]);result.update(compiler=compiler,n=n,m=m,kind=kind,reps=reps,sample=sample,version=v);d['runs'].append(result);save()
     if result['exit']:raise RuntimeError('execution failed')
     x=result['stdout'].split()
     if len(x)!=2:raise RuntimeError('output invalid')
     if expect is None:expect=x[1]
     if x[1]!=expect:raise RuntimeError('answer mismatch')
 d['status']='complete';save()
except BaseException:
 d['status']='failed';d['traceback']=traceback.format_exc();save();raise
