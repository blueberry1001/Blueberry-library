#include <cstdlib>
#include <iostream>
#include <vector>
#include "baseline.hpp"
#include "pr84.hpp"
#include "combined-v4.hpp"
using namespace std;
int main(int argc,char** argv) {
  ios::sync_with_stdio(false);cin.tie(nullptr);
  int n;cin>>n;vector<vector<long long>> cost(n,vector<long long>(n));
  for(auto& row:cost)for(auto& x:row)cin>>x;
  int which=atoi(argv[1]);
  pair<long long,vector<int>> result;
  if(which==0)result=baseline::assignment(cost);
  else if(which==1)result=pr84::assignment(cost);
  else result=combined4::assignment(cost);
  cout<<result.first<<"\n";
  for(int x:result.second)cout<<x<<" ";
  cout<<"\n";
}
