#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <random>
#include <vector>
#include "baseline.hpp"
#include "pr84.hpp"
#include "combined-v3.hpp"
using namespace std;
struct Number {
  long long value=0;
  Number()=default;
  Number(long long v):value(v){}
  Number& operator+=(Number x){value+=x.value;return *this;}
  Number& operator-=(Number x){value-=x.value;return *this;}
  friend Number operator+(Number a,Number b){return a.value+b.value;}
  friend Number operator-(Number a,Number b){return a.value-b.value;}
  friend bool operator<(Number a,Number b){return a.value<b.value;}
};
namespace std {
template<>class numeric_limits<Number>{
 public:static Number max(){return numeric_limits<long long>::max();}
};
}
template<class T> void compare(const vector<vector<T>>& a) {
  auto old=baseline::assignment(a), p=pr84::assignment(a), c=combined3::assignment(a);
  if(p.first!=old.first || c.first!=old.first)abort();
  int n=a.size(),m=n?a[0].size():0;
  for(const auto* result:{&p,&c}) {
    if(result->second.size()!=a.size())abort();
    vector<int> seen(m);T sum{};
    for(int i=0;i<n;++i){int j=result->second[i];if(j<0||j>=m||seen[j]++)abort();sum+=a[i][j];}
    if(sum!=result->first)abort();
  }
}
int main(){
  compare(vector<vector<long long>>{});
  compare(vector<vector<double>>{{2.5,-0.5},{-1.25,3.5}});
  vector<vector<Number>> a{{4,1,9},{2,8,3}};
  auto p=pr84::assignment(a),c=combined3::assignment(a);
  if(p.first.value!=3||c.first.value!=3||p.second!=c.second)abort();
  compare(vector<vector<unsigned long long>>{{0,0,0},{0,0,0}});
  mt19937_64 rng(7291);
  for(int n:{63,64,65})for(int m:{n,n*8,n*8+1})for(int mode=0;mode<12;++mode) {
    vector<vector<long long>> g(n,vector<long long>(m));
    for(auto& row:g)for(auto& x:row)x=static_cast<long long>(rng()%200001)-100000;
    long long bound=numeric_limits<long long>::max()/(n+1)/16;
    long long edge=mode%3==0?bound-1:mode%3==1?bound:bound+1;
    if(mode&1)edge=-edge;
    if(mode&2)g[0][0]=edge;else g[n-1][m-1]=edge;
    compare(g);
  }
  vector<vector<int>> over{{82,6,28,57,33},{6,-46,14,51,23},{61,-44,-64,1,49}};
  for(auto& row:over)for(int& x:row)x*=16000000;
  compare(over);
  const int n=4097;
  vector<vector<int>> large(n,vector<int>(n,1));
  for(int i=0;i<n;++i)large[i][i]=0;
  auto big=combined3::assignment(large);
  if(big.first!=0 || big.second.size()!=large.size())abort();
  for(int i=0;i<n;++i)if(big.second[i]!=i)abort();
  cout<<"boundary tests passed\n";
}
