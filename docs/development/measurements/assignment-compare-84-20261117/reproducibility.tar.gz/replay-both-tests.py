from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import uuid

source = Path(__file__).resolve().parent
work = Path(tempfile.mkdtemp(prefix="assignment-both-replay-"))
fixtures = {
    "final.hpp": "verify-integrated/blueberry/graph/assignment.hpp",
    "assignment-fast.cpp": "verify-integrated/tests/random/assignment-fast.cpp",
    "assignment-lapjv.cpp": "verify-integrated/tests/random/assignment-lapjv.cpp",
    "baseline.hpp.txt": "verify-integrated/tests/random/baseline.hpp.txt",
}
for original, target in fixtures.items():
    destination = work / target
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source / "fixture" / original, destination)
test = work / "verify-integrated/tests/random/assignment-fast.cpp"
text = test.read_text(encoding="utf-8")
old_include = "../../docs/development/measurements/assignment-shortest-20261117/baseline.hpp.txt"
if old_include not in text:
    raise RuntimeError("unexpected baseline include")
test.write_text(text.replace(old_include, "baseline.hpp.txt"), encoding="utf-8")
shutil.copy2(source / "run-both-tests.py", work / "run-both-tests.py")
print("work directory:", work, flush=True)
result = subprocess.run([sys.executable, str(work / "run-both-tests.py")], cwd=work)
log = work / "both-tests-results.json"
if log.exists():
    output = Path.cwd() / ("both-tests-replay-" + uuid.uuid4().hex + ".json")
    with output.open("xb") as stream:
        stream.write(log.read_bytes())
    print("result log:", output, flush=True)
    if result.returncode:
        print(log.read_text(encoding="utf-8"), flush=True)
raise SystemExit(result.returncode)
