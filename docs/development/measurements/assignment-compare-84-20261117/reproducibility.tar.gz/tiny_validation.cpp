#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <vector>
#include "combined-v4.hpp"
using namespace std;
template<class T>
void check(int m,long long expected){
  vector<vector<T>> a(2,vector<T>(m));
  for(auto& row:a)for(auto& x:row){long long v;cin>>v;x=static_cast<T>(v);}
  auto [cost,p]=combined4::assignment(a);
  if(static_cast<long long>(cost)!=expected||p.size()!=2||p[0]<0||p[1]<0||p[0]>=m||p[1]>=m||p[0]==p[1])abort();
  T sum=static_cast<T>(a[0][p[0]]+a[1][p[1]]);
  if(sum!=cost)abort();
}
int main(){
  ios::sync_with_stdio(false);cin.tie(nullptr);
  int count;cin>>count;
  for(int k=0;k<count;++k){
    int type,m;long long expected;cin>>type>>m>>expected;
    if(type==0)check<long long>(m,expected);
    else if(type==1)check<int>(m,expected);
    else check<signed char>(m,expected);
  }
  cout<<"tiny oracle tests passed: "<<count<<"\n";
}
