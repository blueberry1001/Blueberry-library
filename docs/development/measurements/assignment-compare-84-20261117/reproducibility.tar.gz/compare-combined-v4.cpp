#include <algorithm>
#include <chrono>
#include <climits>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <random>
#include <utility>
#include <vector>
#include "baseline.hpp"
#include "pr84.hpp"
#include "ours.hpp"
#include "combined.hpp"
#include "combined-v3.hpp"
#include "combined-v4.hpp"
using namespace std;
using ll=long long;
using Mat=vector<vector<ll>>;
pair<ll,vector<int>> solve(int version,const Mat& a) {
  if(version==0)return baseline::assignment(a);
  if(version==1)return pr84::assignment(a);
  if(version==2)return ours::assignment(a);
  if(version==3)return combined::assignment(a);
  if(version==4)return combined3::assignment(a);
  return combined4::assignment(a);
}
ll brute(const Mat& a) {
  if(a.empty())return 0;
  ll best=LLONG_MAX;
  auto dfs=[&](auto&& self,int i,int used,ll sum)->void {
    if(i==(int)a.size()){best=min(best,sum);return;}
    for(int j=0;j<(int)a[i].size();++j)if(!(used&(1<<j)))self(self,i+1,used|(1<<j),sum+a[i][j]);
  };
  dfs(dfs,0,0,0);return best;
}
void check(const Mat& a,ll expected) {
  int m=a.empty()?0:(int)a[0].size();
  for(int v=0;v<6;++v) {
    auto [cost,match]=solve(v,a);
    if(cost!=expected||match.size()!=a.size())abort();
    vector<int> seen(m);ll sum=0;
    for(int i=0;i<(int)a.size();++i) {
      int j=match[i];if(j<0||j>=m||seen[j]++)abort();
      sum+=a[i][j];
    }
    if(sum!=cost)abort();
  }
}
Mat make_mat(int n,int m,int kind,int seed) {
  mt19937_64 gen(seed);Mat a(n,vector<ll>(m));vector<ll> x(n),y(m);
  vector<int> p(m);iota(p.begin(),p.end(),0);shuffle(p.begin(),p.end(),gen);
  for(auto& q:x)q=static_cast<ll>(gen()%20001)-10000;
  for(auto& q:y)q=static_cast<ll>(gen()%20001)-10000;
  for(int i=0;i<n;++i)for(int j=0;j<m;++j) {
    if(kind==0)a[i][j]=static_cast<ll>(gen()%2000001)-1000000;
    if(kind==1)a[i][j]=static_cast<int>(gen()%3)-1;
    if(kind==2)a[i][j]=0;
    if(kind==3)a[i][j]=x[i]+y[j];
    if(kind==4)a[i][j]=(i==j?0:1);
    if(kind==5)a[i][j]=static_cast<ll>(gen()%100001)-(p[i]==j?100001:0);
    if(kind==6)a[i][j]=static_cast<ll>(gen()%200001)-100000;
    if(kind==7)a[i][j]=1LL*i*j;
    if(kind==8)a[i][j]=static_cast<ll>(gen()%20000000000001ULL)-10000000000000LL;
    if(kind==9)a[i][j]=static_cast<ll>(gen()%200001)-100000;
  }
  if(kind==6)a[n-1][m-1]=100000000000000000LL;
  if(kind==9)a[0][0]=100000000000000000LL;
  return a;
}
int main(int argc,char** argv) {
  if(argc==1) {
    check({},0);mt19937 gen(9871);
    for(int n=1;n<=6;++n)for(int m=n;m<=7;++m)for(int seed=0;seed<100;++seed) {
      Mat a(n,vector<ll>(m));
      for(auto& row:a)for(auto& x:row)x=static_cast<int>(gen()%7)-3;
      check(a,brute(a));
    }
    for(auto [n,m]:vector<pair<int,int>>{{64,64},{64,512},{64,513},{65,520},{65,521},{125,500},{250,250}})
      for(int k=0;k<10;++k){Mat a=make_mat(n,m,k,987+n+m+k);check(a,solve(0,a).first);}
    cout<<"correctness ok\n";return 0;
  }
  int v=atoi(argv[1]),n=atoi(argv[2]),m=atoi(argv[3]),kind=atoi(argv[4]),reps=atoi(argv[5]);
  Mat a=make_mat(n,m,kind,9821+n+m+kind);
  auto t=chrono::steady_clock::now();ll checksum=0;
  for(int i=0;i<reps;++i)checksum+=solve(v,a).first;
  auto elapsed=chrono::duration<double,milli>(chrono::steady_clock::now()-t).count();
  cout<<elapsed<<" "<<checksum<<"\n";
}
