import ctypes,hashlib,json,os,pathlib,platform,statistics,subprocess,time,traceback
r=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10'); v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/p for p in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/p/'x64' for p in ('ucrt','um'))]))

import random,sys
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p
k.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
p=k.GetCurrentProcess();old=ctypes.c_size_t();system=ctypes.c_size_t()
assert k.GetProcessAffinityMask(p,ctypes.byref(old),ctypes.byref(system));mask=1<<8;assert old.value&mask;assert k.SetProcessAffinityMask(p,mask)

log={'status':'running','affinity':hex(mask),'runs':[]}
def save(): (r/'tiny-validation-results.json').write_text(json.dumps(log,indent=2)+'\n',encoding='utf-8')
def call(cmd, data=None):
 start=time.perf_counter();p=subprocess.run(cmd,cwd=r,env=env,input=data,capture_output=True,text=True,errors='replace',timeout=300)
 return {'cmd':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'wall_seconds':time.perf_counter()-start}
try:
 import random,hashlib
 rng=random.Random(79341);cases=[];generated=[0,0,0]
 for kind,bits in enumerate((64,32,8)):
  lo=-(1<<(bits-1));hi=(1<<(bits-1))-1
  pool=[lo,lo+1,lo//2,-3,-1,0,1,3,hi//2,hi-1,hi]
  for trial in range(20000):
   m=rng.randrange(2,9)
   rows=[[rng.choice(pool) if rng.randrange(3) else rng.randint(lo,hi) for _ in range(m)] for i in range(2)]
   best=min(rows[0][i]+rows[1][j] for i in range(m) for j in range(m) if i!=j)
   if not lo<=best<=hi:continue
   generated[kind]+=1;cases.append(str(kind)+' '+str(m)+' '+str(best)+' '+' '.join(str(x) for row in rows for x in row))
 data=str(len(cases))+'\n'+'\n'.join(cases)+'\n'
 log['generated']=generated;log['input_sha256']=hashlib.sha256(data.encode()).hexdigest();log['candidate_sha256']=hashlib.sha256((r/'combined-v4.snapshot.hpp').read_bytes()).hexdigest();save()
 for cc in ('clang','msvc'):
  for std in ('20','23'):
   for release in (False,True):
    exe=r/('tiny-validation-'+cc+'-'+std+'-'+str(release)+'.exe')
    if cc=='clang':cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++'+std,'-O2','-Wall','-Wextra','-Wshadow','-Werror',*(['-DNDEBUG'] if release else []),str(r/'tiny_validation.cpp'),'-o',str(exe)]
    else:cmd=[str(vc/'bin/Hostx64/x64/cl.exe'),'/nologo','/std:'+('c++20' if std=='20' else 'c++latest'),'/O2',*(['/DNDEBUG'] if release else []),'/EHsc',str(r/'tiny_validation.cpp'),'/Fe:'+str(exe)]
    p=call(cmd);log['runs'].append(p);save()
    if p['exit']:raise RuntimeError('compile failed')
    p=call([str(exe)],data);log['runs'].append(p);save()
    if p['exit']:raise RuntimeError('test failed')
 log['status']='complete';save()
except BaseException:
 import traceback;log['status']='failed';log['traceback']=traceback.format_exc();save();raise
