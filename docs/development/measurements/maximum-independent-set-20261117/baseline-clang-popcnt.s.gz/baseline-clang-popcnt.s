	.text
	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
.set @feat.00, 0
	.intel_syntax noprefix
	.file	"assembly.cpp"
	.def	"?solve_max_independent_set@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@2@@Z";
	.scl	2;
	.type	32;
	.endef
	.globl	"?solve_max_independent_set@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@2@@Z" # -- Begin function ?solve_max_independent_set@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@2@@Z
	.p2align	4, 0x90
"?solve_max_independent_set@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@2@@Z": # @"?solve_max_independent_set@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@2@@Z"
.seh_proc "?solve_max_independent_set@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@2@@Z"
# %bb.0:
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 32
	.seh_stackalloc 32
	.seh_endprologue
	mov	rsi, rcx
	call	"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	mov	rax, rsi
	add	rsp, 32
	pop	rsi
	ret
	.seh_endproc
                                        # -- End function
	.def	"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.globl	"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z" # -- Begin function ?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z
	.p2align	4, 0x90
"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z": # @"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
.Lfunc_begin0:
.seh_proc "?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 200
	.seh_stackalloc 200
	lea	rbp, [rsp + 128]
	.seh_setframe rbp, 128
	.seh_endprologue
	mov	qword ptr [rbp + 64], -2
	mov	rdi, r8
                                        # kill: def $edx killed $edx def $rdx
	mov	qword ptr [rbp + 48], rcx       # 8-byte Spill
	pxor	xmm0, xmm0
	movdqa	xmmword ptr [rbp], xmm0
	mov	qword ptr [rbp + 16], 0
	mov	qword ptr [rbp + 40], rdx       # 8-byte Spill
	test	edx, edx
	je	.LBB1_1
# %bb.2:
	js	.LBB1_89
# %bb.3:
	mov	rax, qword ptr [rbp + 40]       # 8-byte Reload
	movsxd	rsi, eax
	lea	rbx, [8*rsi]
	cmp	eax, 512
	jb	.LBB1_5
# %bb.4:
	lea	rcx, [rbx + 39]
	call	"??2@YAPEAX_K@Z"
	lea	r14, [rax + 39]
	and	r14, -32
	mov	qword ptr [r14 - 8], rax
	jmp	.LBB1_6
.LBB1_1:
	xor	r14d, r14d
	jmp	.LBB1_7
.LBB1_5:
	mov	rcx, rbx
	call	"??2@YAPEAX_K@Z"
	mov	r14, rax
.LBB1_6:
	mov	qword ptr [rbp], r14
	lea	rsi, [r14 + 8*rsi]
	mov	qword ptr [rbp + 16], rsi
	mov	rcx, r14
	xor	edx, edx
	mov	r8, rbx
	call	memset
	mov	qword ptr [rbp + 8], rsi
.LBB1_7:
	mov	rdx, qword ptr [rdi]
	mov	r8, qword ptr [rdi + 8]
	cmp	rdx, r8
	je	.LBB1_9
	.p2align	4, 0x90
.LBB1_90:                               # =>This Inner Loop Header: Depth=1
	mov	rax, qword ptr [rdx]
	mov	rcx, rax
	shr	rcx, 32
	mov	r9d, 1
                                        # kill: def $cl killed $cl killed $rcx
	shl	r9, cl
	movsxd	rcx, eax
	or	qword ptr [r14 + 8*rcx], r9
	mov	r9d, 1
	mov	ecx, eax
	shl	r9, cl
	sar	rax, 32
	or	qword ptr [r14 + 8*rax], r9
	add	rdx, 8
	cmp	rdx, r8
	jne	.LBB1_90
.LBB1_9:
	mov	rax, qword ptr [rbp + 40]       # 8-byte Reload
	mov	edi, eax
	shr	edi, 31
	add	edi, eax
	sar	edi
                                        # kill: def $eax killed $eax killed $rax
	sub	eax, edi
	mov	r13d, 1
	mov	edx, 1
	mov	ecx, edi
	shl	edx, cl
	mov	dword ptr [rbp + 36], edx       # 4-byte Spill
	mov	ecx, eax
	shl	r13d, cl
	lea	r15, [4*r13]
	cmp	eax, 10
	jb	.LBB1_12
# %bb.10:
	lea	rcx, [r15 + 39]
.Ltmp2:
	call	"??2@YAPEAX_K@Z"
.Ltmp3:
# %bb.11:
	mov	rbx, rax
	add	rbx, 39
	and	rbx, -32
	mov	qword ptr [rbx - 8], rax
	jmp	.LBB1_14
.LBB1_12:
.Ltmp0:
	mov	rcx, r15
	call	"??2@YAPEAX_K@Z"
.Ltmp1:
# %bb.13:
	mov	rbx, rax
.LBB1_14:
	mov	qword ptr [rbp - 32], rbx
	lea	rsi, [rbx + 4*r13]
	mov	qword ptr [rbp - 16], rsi
	mov	rcx, rbx
	xor	edx, edx
	mov	r8, r15
	call	memset
	mov	qword ptr [rbp - 8], rsi        # 8-byte Spill
	mov	qword ptr [rbp - 24], rsi
	mov	r12d, edi
	cmp	dword ptr [rbp + 40], edi       # 4-byte Folded Reload
	jne	.LBB1_15
.LBB1_19:
	mov	r14d, dword ptr [rbp + 36]      # 4-byte Reload
	lea	rcx, [4*r14]
	cmp	edi, 10
	mov	qword ptr [rbp + 24], rcx       # 8-byte Spill
	jb	.LBB1_22
# %bb.20:
	add	rcx, 39
.Ltmp6:
	call	"??2@YAPEAX_K@Z"
.Ltmp7:
# %bb.21:
	mov	rsi, rax
	add	rsi, 39
	and	rsi, -32
	mov	qword ptr [rsi - 8], rax
	jmp	.LBB1_24
.LBB1_15:
	cmp	r13d, 3
	mov	eax, 2
	cmovae	eax, r13d
	dec	rax
	xor	edx, edx
	jmp	.LBB1_16
	.p2align	4, 0x90
.LBB1_18:                               #   in Loop: Header=BB1_16 Depth=1
	mov	dword ptr [rbx + 4*rdx + 4], ecx
	mov	rdx, r8
	cmp	rax, r8
	je	.LBB1_19
.LBB1_16:                               # =>This Inner Loop Header: Depth=1
	lea	r8, [rdx + 1]
	rep		bsf	r9d, r8d
	mov	r10d, edx
	and	r10d, r8d
	lea	ecx, [r9 + rdi]
	movsxd	rcx, ecx
	mov	r11, qword ptr [r14 + 8*rcx]
	mov	ecx, r12d
	shr	r11, cl
	not	r11d
	and	r11d, r10d
	mov	ecx, dword ptr [rbx + 4*r11]
	bts	ecx, r9d
	popcnt	r11d, ecx
	mov	r9d, dword ptr [rbx + 4*r10]
	popcnt	r10d, r9d
	cmp	r11d, r10d
	ja	.LBB1_18
# %bb.17:                               #   in Loop: Header=BB1_16 Depth=1
	mov	ecx, r9d
	jmp	.LBB1_18
.LBB1_22:
.Ltmp4:
	call	"??2@YAPEAX_K@Z"
.Ltmp5:
# %bb.23:
	mov	rsi, rax
.LBB1_24:
	mov	qword ptr [rbp - 56], rsi
	lea	r15, [rsi + 4*r14]
	mov	qword ptr [rbp - 40], r15
	dec	r13d
	je	.LBB1_30
# %bb.25:
	mov	rax, r14
	mov	r15, rsi
	cmp	edi, 3
	jb	.LBB1_29
# %bb.26:
	mov	ecx, r14d
	and	ecx, -8
	mov	eax, r14d
	and	eax, 7
	lea	r15, [rsi + 4*rcx]
	movd	xmm0, r13d
	pshufd	xmm0, xmm0, 0                   # xmm0 = xmm0[0,0,0,0]
	xor	edx, edx
	.p2align	4, 0x90
.LBB1_27:                               # =>This Inner Loop Header: Depth=1
	movdqu	xmmword ptr [rsi + 4*rdx], xmm0
	movdqu	xmmword ptr [rsi + 4*rdx + 16], xmm0
	add	rdx, 8
	cmp	rcx, rdx
	jne	.LBB1_27
# %bb.28:
	test	rcx, rcx
	jne	.LBB1_31
	.p2align	4, 0x90
.LBB1_29:                               # =>This Inner Loop Header: Depth=1
	mov	dword ptr [r15], r13d
	add	r15, 4
	dec	rax
	jne	.LBB1_29
	jmp	.LBB1_31
.LBB1_30:
	mov	rcx, rsi
	xor	edx, edx
	mov	r8, qword ptr [rbp + 24]        # 8-byte Reload
	call	memset
.LBB1_31:
	mov	qword ptr [rbp - 48], r15
	mov	byte ptr [rbp + 63], 1
.Ltmp8:
	lea	rcx, [rbp - 88]
	lea	r8, [rbp + 63]
	lea	r9, [rbp + 56]
	mov	rdx, r14
	call	"??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z"
.Ltmp9:
# %bb.32:
	mov	rax, qword ptr [rbp - 8]        # 8-byte Reload
	mov	r14d, dword ptr [rax - 4]
	mov	ecx, edi
	shl	r14, cl
	mov	rax, qword ptr [rbp + 40]       # 8-byte Reload
	inc	eax
	cmp	eax, 3
	jae	.LBB1_33
.LBB1_37:
	pxor	xmm0, xmm0
	mov	rax, qword ptr [rbp + 48]       # 8-byte Reload
	movdqu	xmmword ptr [rax], xmm0
	mov	qword ptr [rax + 16], 0
	mov	dword ptr [rbp + 56], 0
	cmp	dword ptr [rbp + 40], 0         # 4-byte Folded Reload
	jle	.LBB1_49
# %bb.38:
	xor	eax, eax
	lea	r12, [rbp + 56]
	jmp	.LBB1_39
	.p2align	4, 0x90
.LBB1_41:                               #   in Loop: Header=BB1_39 Depth=1
	mov	dword ptr [rdx], eax
	add	rdx, 4
	mov	qword ptr [rcx + 8], rdx
.LBB1_84:                               #   in Loop: Header=BB1_39 Depth=1
	mov	eax, dword ptr [rbp + 56]
	inc	eax
	mov	dword ptr [rbp + 56], eax
	cmp	eax, dword ptr [rbp + 40]       # 4-byte Folded Reload
	jge	.LBB1_49
.LBB1_39:                               # =>This Inner Loop Header: Depth=1
	bt	r14, rax
	jae	.LBB1_84
# %bb.40:                               #   in Loop: Header=BB1_39 Depth=1
	mov	rcx, qword ptr [rbp + 48]       # 8-byte Reload
	mov	rdx, qword ptr [rcx + 8]
	cmp	rdx, qword ptr [rcx + 16]
	jne	.LBB1_41
# %bb.83:                               #   in Loop: Header=BB1_39 Depth=1
.Ltmp10:
	mov	r8, r12
	call	"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
.Ltmp11:
	jmp	.LBB1_84
.LBB1_49:
	mov	rcx, qword ptr [rbp - 88]
	test	rcx, rcx
	je	.LBB1_57
# %bb.50:
	mov	rdx, qword ptr [rbp - 72]
	sub	rdx, rcx
	cmp	rdx, 4096
	jb	.LBB1_56
# %bb.51:
	mov	rax, qword ptr [rcx - 8]
	add	rcx, -8
	sub	rcx, rax
	cmp	rcx, 32
	jae	.LBB1_52
# %bb.55:
	add	rdx, 39
	mov	rcx, rax
.LBB1_56:
	call	"??3@YAXPEAX_K@Z"
.LBB1_57:
	test	rsi, rsi
	je	.LBB1_66
# %bb.58:
	cmp	edi, 10
	jb	.LBB1_59
# %bb.60:
	mov	rax, qword ptr [rsi - 8]
	add	rsi, -8
	sub	rsi, rax
	cmp	rsi, 32
	jae	.LBB1_61
# %bb.64:
	mov	rdx, qword ptr [rbp + 24]       # 8-byte Reload
	add	rdx, 39
	mov	rsi, rax
	jmp	.LBB1_65
.LBB1_33:
	mov	rdx, qword ptr [rbp - 88]
	mov	r8, qword ptr [rbp]
	mov	eax, dword ptr [rbp + 36]       # 4-byte Reload
	cmp	eax, 3
	mov	r9d, 2
	cmovae	r9d, eax
	mov	eax, 1
	jmp	.LBB1_34
	.p2align	4, 0x90
.LBB1_47:                               #   in Loop: Header=BB1_34 Depth=1
	mov	r14, r10
.LBB1_48:                               #   in Loop: Header=BB1_34 Depth=1
	inc	rax
	cmp	r9, rax
	je	.LBB1_37
.LBB1_34:                               # =>This Inner Loop Header: Depth=1
	rep		bsf	r11d, eax
	lea	r10d, [rax - 1]
	and	r10d, eax
	mov	ecx, r10d
	shr	ecx, 5
	mov	ecx, dword ptr [rdx + 4*rcx]
	mov	r15d, r10d
	and	r15d, 30
	bt	ecx, r15d
	jae	.LBB1_35
# %bb.42:                               #   in Loop: Header=BB1_34 Depth=1
	mov	ecx, r11d
	mov	r11, qword ptr [r8 + 8*rcx]
	mov	r15d, 1
	mov	ecx, eax
	shl	r15d, cl
	mov	rcx, rax
	shr	rcx, 5
	lea	r13, [rdx + 4*rcx]
	test	r11d, r10d
	jne	.LBB1_36
# %bb.43:                               #   in Loop: Header=BB1_34 Depth=1
	or	dword ptr [r13], r15d
	jmp	.LBB1_44
	.p2align	4, 0x90
.LBB1_35:                               #   in Loop: Header=BB1_34 Depth=1
	mov	r13, rax
	mov	r15d, 1
	mov	ecx, eax
	shl	r15d, cl
	shr	r13, 5
	lea	r13, [rdx + 4*r13]
	mov	ecx, r11d
	mov	r11, qword ptr [r8 + 8*rcx]
.LBB1_36:                               #   in Loop: Header=BB1_34 Depth=1
	mov	ecx, r15d
	not	ecx
	and	dword ptr [r13], ecx
.LBB1_44:                               #   in Loop: Header=BB1_34 Depth=1
	mov	ecx, r12d
	shr	r11, cl
	not	r11d
	and	r11d, dword ptr [rsi + 4*r10]
	mov	dword ptr [rsi + 4*rax], r11d
	test	dword ptr [r13], r15d
	je	.LBB1_48
# %bb.45:                               #   in Loop: Header=BB1_34 Depth=1
	mov	r10d, dword ptr [rbx + 4*r11]
	mov	ecx, r12d
	shl	r10, cl
	or	r10, rax
	popcnt	rcx, r10
	popcnt	r11, r14
	cmp	rcx, r11
	ja	.LBB1_47
# %bb.46:                               #   in Loop: Header=BB1_34 Depth=1
	mov	r10, r14
	jmp	.LBB1_47
.LBB1_59:
	mov	rdx, qword ptr [rbp + 24]       # 8-byte Reload
.LBB1_65:
	mov	rcx, rsi
	call	"??3@YAXPEAX_K@Z"
	mov	rbx, qword ptr [rbp - 32]
.LBB1_66:
	test	rbx, rbx
	mov	rax, qword ptr [rbp + 48]       # 8-byte Reload
	je	.LBB1_74
# %bb.67:
	mov	rdx, qword ptr [rbp - 16]
	sub	rdx, rbx
	cmp	rdx, 4096
	jb	.LBB1_73
# %bb.68:
	mov	rax, qword ptr [rbx - 8]
	add	rbx, -8
	sub	rbx, rax
	cmp	rbx, 32
	jae	.LBB1_69
# %bb.72:
	add	rdx, 39
	mov	rbx, rax
.LBB1_73:
	mov	rcx, rbx
	call	"??3@YAXPEAX_K@Z"
	mov	rax, qword ptr [rbp + 48]       # 8-byte Reload
.LBB1_74:
	mov	rcx, qword ptr [rbp]
	test	rcx, rcx
	je	.LBB1_82
# %bb.75:
	mov	rdx, qword ptr [rbp + 16]
	sub	rdx, rcx
	cmp	rdx, 4096
	jb	.LBB1_81
# %bb.76:
	mov	rax, qword ptr [rcx - 8]
	add	rcx, -8
	sub	rcx, rax
	cmp	rcx, 32
	jae	.LBB1_77
# %bb.80:
	add	rdx, 39
	mov	rcx, rax
.LBB1_81:
	call	"??3@YAXPEAX_K@Z"
	mov	rax, qword ptr [rbp + 48]       # 8-byte Reload
.LBB1_82:
	add	rsp, 200
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret
.LBB1_89:
	call	"?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ"
.LBB1_52:
.Ltmp12:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp13:
# %bb.53:
.LBB1_61:
.Ltmp14:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp15:
# %bb.62:
.LBB1_69:
.Ltmp16:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp17:
# %bb.70:
.LBB1_77:
.Ltmp18:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp19:
# %bb.78:
	int3
	.seh_handlerdata
	.long	("$cppxdata$?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z")@IMGREL
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$54@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$54@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$54@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_54:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	call	__std_terminate
	int3
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$63@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$63@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$63@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_63:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	call	__std_terminate
	int3
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$71@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$71@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$71@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_71:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	call	__std_terminate
	int3
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$79@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$79@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$79@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_79:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	call	__std_terminate
	int3
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$85@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$85@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$85@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_85:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	mov	rcx, qword ptr [rbp + 48]       # 8-byte Reload
	call	"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	lea	rcx, [rbp - 88]
	call	"??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ"
	nop
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret                                     # CLEANUPRET
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$86@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$86@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$86@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_86:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	lea	rcx, [rbp - 56]
	call	"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	nop
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret                                     # CLEANUPRET
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$87@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$87@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$87@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_87:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	lea	rcx, [rbp - 32]
	call	"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	nop
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret                                     # CLEANUPRET
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$88@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$88@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$88@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_88:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	mov	rcx, rbp
	call	"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
	nop
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret                                     # CLEANUPRET
.Lfunc_end0:
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.p2align	2, 0x0
"$cppxdata$?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z":
	.long	429065506                       # MagicNumber
	.long	8                               # MaxState
	.long	("$stateUnwindMap$?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	13                              # IPMapEntries
	.long	("$ip2state$?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z")@IMGREL # IPToStateXData
	.long	192                             # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z":
	.long	-1                              # ToState
	.long	"?dtor$54@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	-1                              # ToState
	.long	"?dtor$63@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	-1                              # ToState
	.long	"?dtor$71@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	-1                              # ToState
	.long	"?dtor$79@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	-1                              # ToState
	.long	"?dtor$88@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	4                               # ToState
	.long	"?dtor$87@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	5                               # ToState
	.long	"?dtor$86@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	6                               # ToState
	.long	"?dtor$85@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
"$ip2state$?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z":
	.long	.Lfunc_begin0@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp2@IMGREL+1                 # IP
	.long	4                               # ToState
	.long	.Ltmp1@IMGREL+1                 # IP
	.long	-1                              # ToState
	.long	.Ltmp6@IMGREL+1                 # IP
	.long	5                               # ToState
	.long	.Ltmp5@IMGREL+1                 # IP
	.long	-1                              # ToState
	.long	.Ltmp8@IMGREL+1                 # IP
	.long	6                               # ToState
	.long	.Ltmp10@IMGREL+1                # IP
	.long	7                               # ToState
	.long	.Ltmp11@IMGREL+1                # IP
	.long	-1                              # ToState
	.long	.Ltmp12@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp14@IMGREL+1                # IP
	.long	1                               # ToState
	.long	.Ltmp16@IMGREL+1                # IP
	.long	2                               # ToState
	.long	.Ltmp18@IMGREL+1                # IP
	.long	3                               # ToState
	.long	.Ltmp19@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
                                        # -- End function
	.def	"??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z"
	.globl	"??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z" # -- Begin function ??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z
	.p2align	4, 0x90
"??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z": # @"??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z"
.Lfunc_begin1:
.seh_proc "??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 56
	.seh_stackalloc 56
	lea	rbp, [rsp + 48]
	.seh_setframe rbp, 48
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rdx
	mov	r13, rcx
	movsx	r14d, byte ptr [r8]
	lea	r12, [rdx + 31]
	mov	rbx, r12
	shr	rbx, 5
	pxor	xmm0, xmm0
	movdqu	xmmword ptr [rcx], xmm0
	mov	qword ptr [rcx + 16], 0
	cmp	r12, 32
	jae	.LBB2_2
# %bb.1:
	xor	r15d, r15d
	jmp	.LBB2_13
.LBB2_2:
	lea	rdi, [4*rbx]
	cmp	r12, 32768
	jb	.LBB2_4
# %bb.3:
	lea	rcx, [rdi + 39]
	call	"??2@YAPEAX_K@Z"
	mov	rcx, rax
	add	rax, 39
	and	rax, -32
	mov	qword ptr [rax - 8], rcx
	jmp	.LBB2_5
.LBB2_4:
	mov	rcx, rdi
	call	"??2@YAPEAX_K@Z"
.LBB2_5:
	mov	qword ptr [r13], rax
	lea	r15, [rax + 4*rbx]
	mov	qword ptr [r13 + 16], r15
	test	r14b, r14b
	je	.LBB2_23
# %bb.6:
	neg	r14d
	cmp	r12, 256
	jae	.LBB2_8
# %bb.7:
	mov	rcx, rbx
	mov	r15, rax
	jmp	.LBB2_11
.LBB2_23:
	mov	rcx, rax
	xor	edx, edx
	mov	r8, rdi
	call	memset
	jmp	.LBB2_12
.LBB2_8:
	mov	rdx, rbx
	and	rdx, -8
	mov	ecx, ebx
	and	ecx, 7
	lea	r8, [4*rdx]
	lea	r15, [rax + 4*rdx]
	movd	xmm0, r14d
	pshufd	xmm0, xmm0, 0                   # xmm0 = xmm0[0,0,0,0]
	xor	r9d, r9d
	.p2align	4, 0x90
.LBB2_9:                                # =>This Inner Loop Header: Depth=1
	movdqu	xmmword ptr [rax + r9], xmm0
	movdqu	xmmword ptr [rax + r9 + 16], xmm0
	add	r9, 32
	cmp	r8, r9
	jne	.LBB2_9
# %bb.10:
	cmp	rbx, rdx
	je	.LBB2_12
	.p2align	4, 0x90
.LBB2_11:                               # =>This Inner Loop Header: Depth=1
	mov	dword ptr [r15], r14d
	add	r15, 4
	dec	rcx
	jne	.LBB2_11
.LBB2_12:
	mov	qword ptr [r13 + 8], r15
.LBB2_13:
	mov	qword ptr [r13 + 24], 0
	test	rsi, rsi
	js	.LBB2_14
# %bb.16:
	mov	rax, qword ptr [r13]
	mov	rcx, r15
	sub	rcx, rax
	sar	rcx, 2
	cmp	rbx, rcx
	jae	.LBB2_19
# %bb.17:
	lea	rcx, [rax + 4*rbx]
	cmp	rcx, r15
	je	.LBB2_19
# %bb.18:
	mov	qword ptr [r13 + 8], rcx
.LBB2_19:
	mov	qword ptr [r13 + 24], rsi
	and	rsi, 31
	je	.LBB2_21
# %bb.20:
	mov	edx, -1
	mov	ecx, esi
	shl	edx, cl
	not	edx
	and	dword ptr [rax + 4*rbx - 4], edx
.LBB2_21:
	mov	rax, r13
	add	rsp, 56
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret
.LBB2_14:
.Ltmp20:
	mov	qword ptr [rbp - 8], r13        # 8-byte Spill
	call	"?_Xlen@?$vector@_NV?$allocator@_N@std@@@std@@SAXXZ"
.Ltmp21:
# %bb.15:
	int3
	.seh_handlerdata
	.long	("$cppxdata$??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z")@IMGREL
	.section	.text,"xr",discard,"??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z"
	.seh_endproc
	.def	"?dtor$22@?0???0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$22@?0???0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z@4HA":
.seh_proc "?dtor$22@?0???0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z@4HA"
.LBB2_22:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 48]
	.seh_endprologue
	mov	rcx, qword ptr [rbp - 8]        # 8-byte Reload
	call	"??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ"
	nop
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret                                     # CLEANUPRET
.Lfunc_end1:
	.seh_handlerdata
	.section	.text,"xr",discard,"??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z"
	.p2align	2, 0x0
"$cppxdata$??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z")@IMGREL # IPToStateXData
	.long	48                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z":
	.long	-1                              # ToState
	.long	"?dtor$22@?0???0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z@4HA"@IMGREL # Action
"$ip2state$??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z":
	.long	.Lfunc_begin1@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp20@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp21@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??0?$vector@_NV?$allocator@_N@std@@@std@@QEAA@_KAEB_NAEBV?$allocator@_N@1@@Z"
                                        # -- End function
	.def	"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	.globl	"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ" # -- Begin function ??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ
	.p2align	4, 0x90
"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ": # @"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
.Lfunc_begin2:
.seh_proc "??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	mov	rcx, qword ptr [rcx]
	test	rcx, rcx
	je	.LBB3_8
# %bb.1:
	mov	rdx, qword ptr [rsi + 16]
	sub	rdx, rcx
	cmp	rdx, 4096
	jb	.LBB3_7
# %bb.2:
	mov	rax, qword ptr [rcx - 8]
	add	rcx, -8
	sub	rcx, rax
	cmp	rcx, 32
	jae	.LBB3_3
# %bb.6:
	add	rdx, 39
	mov	rcx, rax
.LBB3_7:
	call	"??3@YAXPEAX_K@Z"
	xorps	xmm0, xmm0
	movups	xmmword ptr [rsi], xmm0
	mov	qword ptr [rsi + 16], 0
.LBB3_8:
	add	rsp, 40
	pop	rsi
	pop	rbp
	ret
.LBB3_3:
.Ltmp22:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp23:
# %bb.4:
	int3
	.seh_handlerdata
	.long	("$cppxdata$??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ")@IMGREL
	.section	.text,"xr",discard,"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	.seh_endproc
	.def	"?dtor$5@?0???1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$5@?0???1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ@4HA":
.seh_proc "?dtor$5@?0???1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ@4HA"
.LBB3_5:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end2:
	.seh_handlerdata
	.section	.text,"xr",discard,"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	.seh_endproc
	.section	.xdata,"dr",associative,"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	.p2align	2, 0x0
"$cppxdata$??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ":
	.long	-1                              # ToState
	.long	"?dtor$5@?0???1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ@4HA"@IMGREL # Action
"$ip2state$??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ":
	.long	.Lfunc_begin2@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp22@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp23@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
                                        # -- End function
	.def	"??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ"
	.globl	"??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ" # -- Begin function ??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ
	.p2align	4, 0x90
"??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ": # @"??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ"
.Lfunc_begin3:
.seh_proc "??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	mov	rcx, qword ptr [rcx]
	test	rcx, rcx
	je	.LBB4_8
# %bb.1:
	mov	rdx, qword ptr [rsi + 16]
	sub	rdx, rcx
	cmp	rdx, 4096
	jb	.LBB4_7
# %bb.2:
	mov	rax, qword ptr [rcx - 8]
	add	rcx, -8
	sub	rcx, rax
	cmp	rcx, 32
	jae	.LBB4_3
# %bb.6:
	add	rdx, 39
	mov	rcx, rax
.LBB4_7:
	call	"??3@YAXPEAX_K@Z"
	xorps	xmm0, xmm0
	movups	xmmword ptr [rsi], xmm0
	mov	qword ptr [rsi + 16], 0
.LBB4_8:
	add	rsp, 40
	pop	rsi
	pop	rbp
	ret
.LBB4_3:
.Ltmp24:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp25:
# %bb.4:
	int3
	.seh_handlerdata
	.long	("$cppxdata$??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ")@IMGREL
	.section	.text,"xr",discard,"??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ"
	.seh_endproc
	.def	"?dtor$5@?0???1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$5@?0???1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ@4HA":
.seh_proc "?dtor$5@?0???1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ@4HA"
.LBB4_5:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end3:
	.seh_handlerdata
	.section	.text,"xr",discard,"??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ"
	.seh_endproc
	.section	.xdata,"dr",associative,"??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ"
	.p2align	2, 0x0
"$cppxdata$??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ":
	.long	-1                              # ToState
	.long	"?dtor$5@?0???1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ@4HA"@IMGREL # Action
"$ip2state$??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ":
	.long	.Lfunc_begin3@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp24@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp25@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??1?$_Vb_val@V?$allocator@_N@std@@@std@@QEAA@XZ"
                                        # -- End function
	.def	"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	.globl	"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ" # -- Begin function ??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ
	.p2align	4, 0x90
"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ": # @"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
.Lfunc_begin4:
.seh_proc "??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	mov	rcx, qword ptr [rcx]
	test	rcx, rcx
	je	.LBB5_8
# %bb.1:
	mov	rdx, qword ptr [rsi + 16]
	sub	rdx, rcx
	cmp	rdx, 4096
	jb	.LBB5_7
# %bb.2:
	mov	rax, qword ptr [rcx - 8]
	add	rcx, -8
	sub	rcx, rax
	cmp	rcx, 32
	jae	.LBB5_3
# %bb.6:
	add	rdx, 39
	mov	rcx, rax
.LBB5_7:
	call	"??3@YAXPEAX_K@Z"
	xorps	xmm0, xmm0
	movups	xmmword ptr [rsi], xmm0
	mov	qword ptr [rsi + 16], 0
.LBB5_8:
	add	rsp, 40
	pop	rsi
	pop	rbp
	ret
.LBB5_3:
.Ltmp26:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp27:
# %bb.4:
	int3
	.seh_handlerdata
	.long	("$cppxdata$??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ")@IMGREL
	.section	.text,"xr",discard,"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	.seh_endproc
	.def	"?dtor$5@?0???1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$5@?0???1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ@4HA":
.seh_proc "?dtor$5@?0???1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ@4HA"
.LBB5_5:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end4:
	.seh_handlerdata
	.section	.text,"xr",discard,"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	.seh_endproc
	.section	.xdata,"dr",associative,"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	.p2align	2, 0x0
"$cppxdata$??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ":
	.long	-1                              # ToState
	.long	"?dtor$5@?0???1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ@4HA"@IMGREL # Action
"$ip2state$??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ":
	.long	.Lfunc_begin4@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp26@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp27@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
                                        # -- End function
	.def	"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
	.globl	"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ" # -- Begin function ??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ
	.p2align	4, 0x90
"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ": # @"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
.Lfunc_begin5:
.seh_proc "??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	mov	rcx, qword ptr [rcx]
	test	rcx, rcx
	je	.LBB6_8
# %bb.1:
	mov	rdx, qword ptr [rsi + 16]
	sub	rdx, rcx
	cmp	rdx, 4096
	jb	.LBB6_7
# %bb.2:
	mov	rax, qword ptr [rcx - 8]
	add	rcx, -8
	sub	rcx, rax
	cmp	rcx, 32
	jae	.LBB6_3
# %bb.6:
	add	rdx, 39
	mov	rcx, rax
.LBB6_7:
	call	"??3@YAXPEAX_K@Z"
	xorps	xmm0, xmm0
	movups	xmmword ptr [rsi], xmm0
	mov	qword ptr [rsi + 16], 0
.LBB6_8:
	add	rsp, 40
	pop	rsi
	pop	rbp
	ret
.LBB6_3:
.Ltmp28:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp29:
# %bb.4:
	int3
	.seh_handlerdata
	.long	("$cppxdata$??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ")@IMGREL
	.section	.text,"xr",discard,"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
	.seh_endproc
	.def	"?dtor$5@?0???1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$5@?0???1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ@4HA":
.seh_proc "?dtor$5@?0???1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ@4HA"
.LBB6_5:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end5:
	.seh_handlerdata
	.section	.text,"xr",discard,"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
	.seh_endproc
	.section	.xdata,"dr",associative,"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
	.p2align	2, 0x0
"$cppxdata$??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ":
	.long	-1                              # ToState
	.long	"?dtor$5@?0???1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ@4HA"@IMGREL # Action
"$ip2state$??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ":
	.long	.Lfunc_begin5@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp28@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp29@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
                                        # -- End function
	.def	"?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ"
	.globl	"?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ" # -- Begin function ?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ
	.p2align	4, 0x90
"?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ": # @"?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ"
.seh_proc "?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ"
# %bb.0:
	sub	rsp, 40
	.seh_stackalloc 40
	.seh_endprologue
	lea	rcx, [rip + "??_C@_0BA@FOIKENOD@vector?5too?5long?$AA@"]
	call	"?_Xlength_error@std@@YAXPEBD@Z"
	int3
	.seh_endproc
                                        # -- End function
	.def	"?_Throw_bad_array_new_length@std@@YAXXZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"?_Throw_bad_array_new_length@std@@YAXXZ"
	.globl	"?_Throw_bad_array_new_length@std@@YAXXZ" # -- Begin function ?_Throw_bad_array_new_length@std@@YAXXZ
	.p2align	4, 0x90
"?_Throw_bad_array_new_length@std@@YAXXZ": # @"?_Throw_bad_array_new_length@std@@YAXXZ"
.seh_proc "?_Throw_bad_array_new_length@std@@YAXXZ"
# %bb.0:
	sub	rsp, 56
	.seh_stackalloc 56
	.seh_endprologue
	mov	qword ptr [rsp + 48], 0
	lea	rax, [rip + "??_C@_0BF@KINCDENJ@bad?5array?5new?5length?$AA@"]
	mov	qword ptr [rsp + 40], rax
	lea	rax, [rip + "??_7bad_array_new_length@std@@6B@"]
	mov	qword ptr [rsp + 32], rax
	lea	rdx, [rip + "_TI3?AVbad_array_new_length@std@@"]
	lea	rcx, [rsp + 32]
	call	_CxxThrowException
	int3
	.seh_endproc
                                        # -- End function
	.def	"??0bad_array_new_length@std@@QEAA@AEBV01@@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
	.globl	"??0bad_array_new_length@std@@QEAA@AEBV01@@Z" # -- Begin function ??0bad_array_new_length@std@@QEAA@AEBV01@@Z
	.p2align	4, 0x90
"??0bad_array_new_length@std@@QEAA@AEBV01@@Z": # @"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
.Lfunc_begin6:
.seh_proc "??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	lea	rax, [rcx + 8]
	xorps	xmm0, xmm0
	movups	xmmword ptr [rcx + 8], xmm0
	lea	rcx, [rdx + 8]
.Ltmp30:
	mov	rdx, rax
	call	__std_exception_copy
.Ltmp31:
# %bb.1:
	lea	rax, [rip + "??_7bad_array_new_length@std@@6B@"]
	mov	qword ptr [rsi], rax
	mov	rax, rsi
	add	rsp, 40
	pop	rsi
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??0bad_array_new_length@std@@QEAA@AEBV01@@Z")@IMGREL
	.section	.text,"xr",discard,"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
	.seh_endproc
	.def	"?dtor$2@?0???0bad_array_new_length@std@@QEAA@AEBV01@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$2@?0???0bad_array_new_length@std@@QEAA@AEBV01@@Z@4HA":
.seh_proc "?dtor$2@?0???0bad_array_new_length@std@@QEAA@AEBV01@@Z@4HA"
.LBB9_2:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end6:
	.seh_handlerdata
	.section	.text,"xr",discard,"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
	.p2align	2, 0x0
"$cppxdata$??0bad_array_new_length@std@@QEAA@AEBV01@@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??0bad_array_new_length@std@@QEAA@AEBV01@@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??0bad_array_new_length@std@@QEAA@AEBV01@@Z")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??0bad_array_new_length@std@@QEAA@AEBV01@@Z":
	.long	-1                              # ToState
	.long	"?dtor$2@?0???0bad_array_new_length@std@@QEAA@AEBV01@@Z@4HA"@IMGREL # Action
"$ip2state$??0bad_array_new_length@std@@QEAA@AEBV01@@Z":
	.long	.Lfunc_begin6@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp30@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp31@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
                                        # -- End function
	.def	"??0bad_alloc@std@@QEAA@AEBV01@@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??0bad_alloc@std@@QEAA@AEBV01@@Z"
	.globl	"??0bad_alloc@std@@QEAA@AEBV01@@Z" # -- Begin function ??0bad_alloc@std@@QEAA@AEBV01@@Z
	.p2align	4, 0x90
"??0bad_alloc@std@@QEAA@AEBV01@@Z":     # @"??0bad_alloc@std@@QEAA@AEBV01@@Z"
.Lfunc_begin7:
.seh_proc "??0bad_alloc@std@@QEAA@AEBV01@@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	lea	rax, [rcx + 8]
	xorps	xmm0, xmm0
	movups	xmmword ptr [rcx + 8], xmm0
	lea	rcx, [rdx + 8]
.Ltmp32:
	mov	rdx, rax
	call	__std_exception_copy
.Ltmp33:
# %bb.1:
	lea	rax, [rip + "??_7bad_alloc@std@@6B@"]
	mov	qword ptr [rsi], rax
	mov	rax, rsi
	add	rsp, 40
	pop	rsi
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??0bad_alloc@std@@QEAA@AEBV01@@Z")@IMGREL
	.section	.text,"xr",discard,"??0bad_alloc@std@@QEAA@AEBV01@@Z"
	.seh_endproc
	.def	"?dtor$2@?0???0bad_alloc@std@@QEAA@AEBV01@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$2@?0???0bad_alloc@std@@QEAA@AEBV01@@Z@4HA":
.seh_proc "?dtor$2@?0???0bad_alloc@std@@QEAA@AEBV01@@Z@4HA"
.LBB10_2:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end7:
	.seh_handlerdata
	.section	.text,"xr",discard,"??0bad_alloc@std@@QEAA@AEBV01@@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??0bad_alloc@std@@QEAA@AEBV01@@Z"
	.p2align	2, 0x0
"$cppxdata$??0bad_alloc@std@@QEAA@AEBV01@@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??0bad_alloc@std@@QEAA@AEBV01@@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??0bad_alloc@std@@QEAA@AEBV01@@Z")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??0bad_alloc@std@@QEAA@AEBV01@@Z":
	.long	-1                              # ToState
	.long	"?dtor$2@?0???0bad_alloc@std@@QEAA@AEBV01@@Z@4HA"@IMGREL # Action
"$ip2state$??0bad_alloc@std@@QEAA@AEBV01@@Z":
	.long	.Lfunc_begin7@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp32@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp33@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??0bad_alloc@std@@QEAA@AEBV01@@Z"
                                        # -- End function
	.def	"??0exception@std@@QEAA@AEBV01@@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??0exception@std@@QEAA@AEBV01@@Z"
	.globl	"??0exception@std@@QEAA@AEBV01@@Z" # -- Begin function ??0exception@std@@QEAA@AEBV01@@Z
	.p2align	4, 0x90
"??0exception@std@@QEAA@AEBV01@@Z":     # @"??0exception@std@@QEAA@AEBV01@@Z"
.Lfunc_begin8:
.seh_proc "??0exception@std@@QEAA@AEBV01@@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	lea	rax, [rcx + 8]
	xorps	xmm0, xmm0
	movups	xmmword ptr [rcx + 8], xmm0
	lea	rcx, [rdx + 8]
.Ltmp34:
	mov	rdx, rax
	call	__std_exception_copy
.Ltmp35:
# %bb.1:
	mov	rax, rsi
	add	rsp, 40
	pop	rsi
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??0exception@std@@QEAA@AEBV01@@Z")@IMGREL
	.section	.text,"xr",discard,"??0exception@std@@QEAA@AEBV01@@Z"
	.seh_endproc
	.def	"?dtor$2@?0???0exception@std@@QEAA@AEBV01@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$2@?0???0exception@std@@QEAA@AEBV01@@Z@4HA":
.seh_proc "?dtor$2@?0???0exception@std@@QEAA@AEBV01@@Z@4HA"
.LBB11_2:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end8:
	.seh_handlerdata
	.section	.text,"xr",discard,"??0exception@std@@QEAA@AEBV01@@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??0exception@std@@QEAA@AEBV01@@Z"
	.p2align	2, 0x0
"$cppxdata$??0exception@std@@QEAA@AEBV01@@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??0exception@std@@QEAA@AEBV01@@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??0exception@std@@QEAA@AEBV01@@Z")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??0exception@std@@QEAA@AEBV01@@Z":
	.long	-1                              # ToState
	.long	"?dtor$2@?0???0exception@std@@QEAA@AEBV01@@Z@4HA"@IMGREL # Action
"$ip2state$??0exception@std@@QEAA@AEBV01@@Z":
	.long	.Lfunc_begin8@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp34@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp35@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??0exception@std@@QEAA@AEBV01@@Z"
                                        # -- End function
	.def	"??1exception@std@@UEAA@XZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??1exception@std@@UEAA@XZ"
	.globl	"??1exception@std@@UEAA@XZ"     # -- Begin function ??1exception@std@@UEAA@XZ
	.p2align	4, 0x90
"??1exception@std@@UEAA@XZ":            # @"??1exception@std@@UEAA@XZ"
.Lfunc_begin9:
.seh_proc "??1exception@std@@UEAA@XZ"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	sub	rsp, 48
	.seh_stackalloc 48
	lea	rbp, [rsp + 48]
	.seh_setframe rbp, 48
	.seh_endprologue
	mov	qword ptr [rbp - 8], -2
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	add	rcx, 8
.Ltmp36:
	call	__std_exception_destroy
.Ltmp37:
# %bb.1:
	nop
	add	rsp, 48
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??1exception@std@@UEAA@XZ")@IMGREL
	.section	.text,"xr",discard,"??1exception@std@@UEAA@XZ"
	.seh_endproc
	.def	"?dtor$2@?0???1exception@std@@UEAA@XZ@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$2@?0???1exception@std@@UEAA@XZ@4HA":
.seh_proc "?dtor$2@?0???1exception@std@@UEAA@XZ@4HA"
.LBB12_2:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	sub	rsp, 32
	.seh_stackalloc 32
	lea	rbp, [rdx + 48]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end9:
	.seh_handlerdata
	.section	.text,"xr",discard,"??1exception@std@@UEAA@XZ"
	.seh_endproc
	.section	.xdata,"dr",associative,"??1exception@std@@UEAA@XZ"
	.p2align	2, 0x0
"$cppxdata$??1exception@std@@UEAA@XZ":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??1exception@std@@UEAA@XZ")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??1exception@std@@UEAA@XZ")@IMGREL # IPToStateXData
	.long	40                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??1exception@std@@UEAA@XZ":
	.long	-1                              # ToState
	.long	"?dtor$2@?0???1exception@std@@UEAA@XZ@4HA"@IMGREL # Action
"$ip2state$??1exception@std@@UEAA@XZ":
	.long	.Lfunc_begin9@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp36@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp37@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??1exception@std@@UEAA@XZ"
                                        # -- End function
	.def	"??_Gbad_array_new_length@std@@UEAAPEAXI@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
	.globl	"??_Gbad_array_new_length@std@@UEAAPEAXI@Z" # -- Begin function ??_Gbad_array_new_length@std@@UEAAPEAXI@Z
	.p2align	4, 0x90
"??_Gbad_array_new_length@std@@UEAAPEAXI@Z": # @"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
.Lfunc_begin10:
.seh_proc "??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	sub	rsp, 48
	.seh_stackalloc 48
	lea	rbp, [rsp + 48]
	.seh_setframe rbp, 48
	.seh_endprologue
	mov	qword ptr [rbp - 8], -2
	mov	edi, edx
	mov	rsi, rcx
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	add	rcx, 8
.Ltmp38:
	call	__std_exception_destroy
.Ltmp39:
# %bb.1:
	test	edi, edi
	je	.LBB13_3
# %bb.2:
	mov	rcx, rsi
	call	"??3@YAXPEAX@Z"
.LBB13_3:
	mov	rax, rsi
	add	rsp, 48
	pop	rdi
	pop	rsi
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??_Gbad_array_new_length@std@@UEAAPEAXI@Z")@IMGREL
	.section	.text,"xr",discard,"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
	.seh_endproc
	.def	"?dtor$4@?0???_Gbad_array_new_length@std@@UEAAPEAXI@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$4@?0???_Gbad_array_new_length@std@@UEAAPEAXI@Z@4HA":
.seh_proc "?dtor$4@?0???_Gbad_array_new_length@std@@UEAAPEAXI@Z@4HA"
.LBB13_4:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	sub	rsp, 32
	.seh_stackalloc 32
	lea	rbp, [rdx + 48]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end10:
	.seh_handlerdata
	.section	.text,"xr",discard,"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
	.p2align	2, 0x0
"$cppxdata$??_Gbad_array_new_length@std@@UEAAPEAXI@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??_Gbad_array_new_length@std@@UEAAPEAXI@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??_Gbad_array_new_length@std@@UEAAPEAXI@Z")@IMGREL # IPToStateXData
	.long	40                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??_Gbad_array_new_length@std@@UEAAPEAXI@Z":
	.long	-1                              # ToState
	.long	"?dtor$4@?0???_Gbad_array_new_length@std@@UEAAPEAXI@Z@4HA"@IMGREL # Action
"$ip2state$??_Gbad_array_new_length@std@@UEAAPEAXI@Z":
	.long	.Lfunc_begin10@IMGREL           # IP
	.long	-1                              # ToState
	.long	.Ltmp38@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp39@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
                                        # -- End function
	.def	"?what@exception@std@@UEBAPEBDXZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"?what@exception@std@@UEBAPEBDXZ"
	.globl	"?what@exception@std@@UEBAPEBDXZ" # -- Begin function ?what@exception@std@@UEBAPEBDXZ
	.p2align	4, 0x90
"?what@exception@std@@UEBAPEBDXZ":      # @"?what@exception@std@@UEBAPEBDXZ"
# %bb.0:
	mov	rcx, qword ptr [rcx + 8]
	test	rcx, rcx
	lea	rax, [rip + "??_C@_0BC@EOODALEL@Unknown?5exception?$AA@"]
	cmovne	rax, rcx
	ret
                                        # -- End function
	.def	"??_Gbad_alloc@std@@UEAAPEAXI@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??_Gbad_alloc@std@@UEAAPEAXI@Z"
	.globl	"??_Gbad_alloc@std@@UEAAPEAXI@Z" # -- Begin function ??_Gbad_alloc@std@@UEAAPEAXI@Z
	.p2align	4, 0x90
"??_Gbad_alloc@std@@UEAAPEAXI@Z":       # @"??_Gbad_alloc@std@@UEAAPEAXI@Z"
.Lfunc_begin11:
.seh_proc "??_Gbad_alloc@std@@UEAAPEAXI@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	sub	rsp, 48
	.seh_stackalloc 48
	lea	rbp, [rsp + 48]
	.seh_setframe rbp, 48
	.seh_endprologue
	mov	qword ptr [rbp - 8], -2
	mov	edi, edx
	mov	rsi, rcx
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	add	rcx, 8
.Ltmp40:
	call	__std_exception_destroy
.Ltmp41:
# %bb.1:
	test	edi, edi
	je	.LBB15_3
# %bb.2:
	mov	rcx, rsi
	call	"??3@YAXPEAX@Z"
.LBB15_3:
	mov	rax, rsi
	add	rsp, 48
	pop	rdi
	pop	rsi
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??_Gbad_alloc@std@@UEAAPEAXI@Z")@IMGREL
	.section	.text,"xr",discard,"??_Gbad_alloc@std@@UEAAPEAXI@Z"
	.seh_endproc
	.def	"?dtor$4@?0???_Gbad_alloc@std@@UEAAPEAXI@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$4@?0???_Gbad_alloc@std@@UEAAPEAXI@Z@4HA":
.seh_proc "?dtor$4@?0???_Gbad_alloc@std@@UEAAPEAXI@Z@4HA"
.LBB15_4:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	sub	rsp, 32
	.seh_stackalloc 32
	lea	rbp, [rdx + 48]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end11:
	.seh_handlerdata
	.section	.text,"xr",discard,"??_Gbad_alloc@std@@UEAAPEAXI@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??_Gbad_alloc@std@@UEAAPEAXI@Z"
	.p2align	2, 0x0
"$cppxdata$??_Gbad_alloc@std@@UEAAPEAXI@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??_Gbad_alloc@std@@UEAAPEAXI@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??_Gbad_alloc@std@@UEAAPEAXI@Z")@IMGREL # IPToStateXData
	.long	40                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??_Gbad_alloc@std@@UEAAPEAXI@Z":
	.long	-1                              # ToState
	.long	"?dtor$4@?0???_Gbad_alloc@std@@UEAAPEAXI@Z@4HA"@IMGREL # Action
"$ip2state$??_Gbad_alloc@std@@UEAAPEAXI@Z":
	.long	.Lfunc_begin11@IMGREL           # IP
	.long	-1                              # ToState
	.long	.Ltmp40@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp41@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??_Gbad_alloc@std@@UEAAPEAXI@Z"
                                        # -- End function
	.def	"??_Gexception@std@@UEAAPEAXI@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??_Gexception@std@@UEAAPEAXI@Z"
	.globl	"??_Gexception@std@@UEAAPEAXI@Z" # -- Begin function ??_Gexception@std@@UEAAPEAXI@Z
	.p2align	4, 0x90
"??_Gexception@std@@UEAAPEAXI@Z":       # @"??_Gexception@std@@UEAAPEAXI@Z"
.Lfunc_begin12:
.seh_proc "??_Gexception@std@@UEAAPEAXI@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	sub	rsp, 48
	.seh_stackalloc 48
	lea	rbp, [rsp + 48]
	.seh_setframe rbp, 48
	.seh_endprologue
	mov	qword ptr [rbp - 8], -2
	mov	edi, edx
	mov	rsi, rcx
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	add	rcx, 8
.Ltmp42:
	call	__std_exception_destroy
.Ltmp43:
# %bb.1:
	test	edi, edi
	je	.LBB16_3
# %bb.2:
	mov	rcx, rsi
	call	"??3@YAXPEAX@Z"
.LBB16_3:
	mov	rax, rsi
	add	rsp, 48
	pop	rdi
	pop	rsi
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??_Gexception@std@@UEAAPEAXI@Z")@IMGREL
	.section	.text,"xr",discard,"??_Gexception@std@@UEAAPEAXI@Z"
	.seh_endproc
	.def	"?dtor$4@?0???_Gexception@std@@UEAAPEAXI@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$4@?0???_Gexception@std@@UEAAPEAXI@Z@4HA":
.seh_proc "?dtor$4@?0???_Gexception@std@@UEAAPEAXI@Z@4HA"
.LBB16_4:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	sub	rsp, 32
	.seh_stackalloc 32
	lea	rbp, [rdx + 48]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end12:
	.seh_handlerdata
	.section	.text,"xr",discard,"??_Gexception@std@@UEAAPEAXI@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??_Gexception@std@@UEAAPEAXI@Z"
	.p2align	2, 0x0
"$cppxdata$??_Gexception@std@@UEAAPEAXI@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??_Gexception@std@@UEAAPEAXI@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??_Gexception@std@@UEAAPEAXI@Z")@IMGREL # IPToStateXData
	.long	40                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??_Gexception@std@@UEAAPEAXI@Z":
	.long	-1                              # ToState
	.long	"?dtor$4@?0???_Gexception@std@@UEAAPEAXI@Z@4HA"@IMGREL # Action
"$ip2state$??_Gexception@std@@UEAAPEAXI@Z":
	.long	.Lfunc_begin12@IMGREL           # IP
	.long	-1                              # ToState
	.long	.Ltmp42@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp43@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??_Gexception@std@@UEAAPEAXI@Z"
                                        # -- End function
	.def	"?_Xlen@?$vector@_NV?$allocator@_N@std@@@std@@SAXXZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"?_Xlen@?$vector@_NV?$allocator@_N@std@@@std@@SAXXZ"
	.globl	"?_Xlen@?$vector@_NV?$allocator@_N@std@@@std@@SAXXZ" # -- Begin function ?_Xlen@?$vector@_NV?$allocator@_N@std@@@std@@SAXXZ
	.p2align	4, 0x90
"?_Xlen@?$vector@_NV?$allocator@_N@std@@@std@@SAXXZ": # @"?_Xlen@?$vector@_NV?$allocator@_N@std@@@std@@SAXXZ"
.seh_proc "?_Xlen@?$vector@_NV?$allocator@_N@std@@@std@@SAXXZ"
# %bb.0:
	sub	rsp, 40
	.seh_stackalloc 40
	.seh_endprologue
	lea	rcx, [rip + "??_C@_0BG@EOMJEIFA@vector?$DMbool?$DO?5too?5long?$AA@"]
	call	"?_Xlength_error@std@@YAXPEBD@Z"
	int3
	.seh_endproc
                                        # -- End function
	.def	"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
	.globl	"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z" # -- Begin function ??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z
	.p2align	4, 0x90
"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z": # @"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
.Lfunc_begin13:
.seh_proc "??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	mov	rbx, qword ptr [rcx]
	mov	r12, qword ptr [rcx + 8]
	sub	r12, rbx
	sar	r12, 2
	inc	r12
	mov	rax, qword ptr [rcx + 16]
	sub	rax, rbx
	sar	rax, 2
	mov	r13, rax
	shr	r13
	movabs	rcx, 4611686018427387903
	mov	r9, rcx
	sub	r9, r13
	add	r13, rax
	cmp	r13, r12
	cmovbe	r13, r12
	cmp	rax, r9
	cmova	r13, rcx
	mov	rax, r13
	shr	rax, 62
	jne	.LBB18_19
# %bb.1:
	mov	r15, r8
	mov	r14, rdx
	test	r13, r13
	je	.LBB18_2
# %bb.3:
	lea	rcx, [4*r13]
	cmp	r13, 1024
	jb	.LBB18_6
# %bb.4:
	movabs	rax, 4611686018427387895
	cmp	r13, rax
	jae	.LBB18_19
# %bb.5:
	add	rcx, 39
	call	"??2@YAPEAX_K@Z"
	lea	rdi, [rax + 39]
	and	rdi, -32
	mov	qword ptr [rdi - 8], rax
	jmp	.LBB18_7
.LBB18_2:
	xor	edi, edi
	jmp	.LBB18_7
.LBB18_6:
	call	"??2@YAPEAX_K@Z"
	mov	rdi, rax
.LBB18_7:
	mov	rax, r14
	sub	rax, rbx
	lea	rbx, [rdi + rax]
	mov	ecx, dword ptr [r15]
	mov	dword ptr [rdi + rax], ecx
	cmp	qword ptr [rsi + 8], r14
	je	.LBB18_8
# %bb.9:
	lea	r15, [rbx + 4]
	mov	rdx, qword ptr [rsi]
	mov	r8, r14
	sub	r8, rdx
	mov	rcx, rdi
	call	memmove
	mov	r8, qword ptr [rsi + 8]
	sub	r8, r14
	mov	rcx, r15
	mov	rdx, r14
	jmp	.LBB18_10
.LBB18_8:
	mov	rdx, qword ptr [rsi]
	sub	r14, rdx
	mov	rcx, rdi
	mov	r8, r14
.LBB18_10:
	call	memmove
	mov	rcx, qword ptr [rsi]
	test	rcx, rcx
	je	.LBB18_18
# %bb.11:
	mov	rdx, qword ptr [rsi + 16]
	sub	rdx, rcx
	cmp	rdx, 4096
	jb	.LBB18_17
# %bb.12:
	mov	rax, qword ptr [rcx - 8]
	add	rcx, -8
	sub	rcx, rax
	cmp	rcx, 32
	jae	.LBB18_13
# %bb.16:
	add	rdx, 39
	mov	rcx, rax
.LBB18_17:
	call	"??3@YAXPEAX_K@Z"
.LBB18_18:
	mov	qword ptr [rsi], rdi
	lea	rax, [rdi + 4*r12]
	mov	qword ptr [rsi + 8], rax
	lea	rax, [rdi + 4*r13]
	mov	qword ptr [rsi + 16], rax
	mov	rax, rbx
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret
.LBB18_19:
	call	"?_Throw_bad_array_new_length@std@@YAXXZ"
.LBB18_13:
.Ltmp44:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp45:
# %bb.14:
	int3
	.seh_handlerdata
	.long	("$cppxdata$??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z")@IMGREL
	.section	.text,"xr",discard,"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
	.seh_endproc
	.def	"?dtor$15@?0???$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$15@?0???$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z@4HA":
.seh_proc "?dtor$15@?0???$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z@4HA"
.LBB18_15:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end13:
	.seh_handlerdata
	.section	.text,"xr",discard,"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
	.p2align	2, 0x0
"$cppxdata$??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z":
	.long	-1                              # ToState
	.long	"?dtor$15@?0???$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z@4HA"@IMGREL # Action
"$ip2state$??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z":
	.long	.Lfunc_begin13@IMGREL           # IP
	.long	-1                              # ToState
	.long	.Ltmp44@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp45@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
                                        # -- End function
	.section	.rdata,"dr",discard,"??_C@_0BA@FOIKENOD@vector?5too?5long?$AA@"
	.globl	"??_C@_0BA@FOIKENOD@vector?5too?5long?$AA@" # @"??_C@_0BA@FOIKENOD@vector?5too?5long?$AA@"
"??_C@_0BA@FOIKENOD@vector?5too?5long?$AA@":
	.asciz	"vector too long"

	.section	.data,"dw",discard,"??_R0?AVbad_array_new_length@std@@@8"
	.globl	"??_R0?AVbad_array_new_length@std@@@8" # @"??_R0?AVbad_array_new_length@std@@@8"
	.p2align	4, 0x0
"??_R0?AVbad_array_new_length@std@@@8":
	.quad	"??_7type_info@@6B@"
	.quad	0
	.asciz	".?AVbad_array_new_length@std@@"
	.zero	1

	.section	.xdata,"dr",discard,"_CT??_R0?AVbad_array_new_length@std@@@8??0bad_array_new_length@std@@QEAA@AEBV01@@Z24"
	.globl	"_CT??_R0?AVbad_array_new_length@std@@@8??0bad_array_new_length@std@@QEAA@AEBV01@@Z24" # @"_CT??_R0?AVbad_array_new_length@std@@@8??0bad_array_new_length@std@@QEAA@AEBV01@@Z24"
	.p2align	4, 0x0
"_CT??_R0?AVbad_array_new_length@std@@@8??0bad_array_new_length@std@@QEAA@AEBV01@@Z24":
	.long	0                               # 0x0
	.long	"??_R0?AVbad_array_new_length@std@@@8"@IMGREL
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	24                              # 0x18
	.long	"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"@IMGREL

	.section	.data,"dw",discard,"??_R0?AVbad_alloc@std@@@8"
	.globl	"??_R0?AVbad_alloc@std@@@8"     # @"??_R0?AVbad_alloc@std@@@8"
	.p2align	4, 0x0
"??_R0?AVbad_alloc@std@@@8":
	.quad	"??_7type_info@@6B@"
	.quad	0
	.asciz	".?AVbad_alloc@std@@"
	.zero	4

	.section	.xdata,"dr",discard,"_CT??_R0?AVbad_alloc@std@@@8??0bad_alloc@std@@QEAA@AEBV01@@Z24"
	.globl	"_CT??_R0?AVbad_alloc@std@@@8??0bad_alloc@std@@QEAA@AEBV01@@Z24" # @"_CT??_R0?AVbad_alloc@std@@@8??0bad_alloc@std@@QEAA@AEBV01@@Z24"
	.p2align	4, 0x0
"_CT??_R0?AVbad_alloc@std@@@8??0bad_alloc@std@@QEAA@AEBV01@@Z24":
	.long	16                              # 0x10
	.long	"??_R0?AVbad_alloc@std@@@8"@IMGREL
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	24                              # 0x18
	.long	"??0bad_alloc@std@@QEAA@AEBV01@@Z"@IMGREL

	.section	.data,"dw",discard,"??_R0?AVexception@std@@@8"
	.globl	"??_R0?AVexception@std@@@8"     # @"??_R0?AVexception@std@@@8"
	.p2align	4, 0x0
"??_R0?AVexception@std@@@8":
	.quad	"??_7type_info@@6B@"
	.quad	0
	.asciz	".?AVexception@std@@"
	.zero	4

	.section	.xdata,"dr",discard,"_CT??_R0?AVexception@std@@@8??0exception@std@@QEAA@AEBV01@@Z24"
	.globl	"_CT??_R0?AVexception@std@@@8??0exception@std@@QEAA@AEBV01@@Z24" # @"_CT??_R0?AVexception@std@@@8??0exception@std@@QEAA@AEBV01@@Z24"
	.p2align	4, 0x0
"_CT??_R0?AVexception@std@@@8??0exception@std@@QEAA@AEBV01@@Z24":
	.long	0                               # 0x0
	.long	"??_R0?AVexception@std@@@8"@IMGREL
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	24                              # 0x18
	.long	"??0exception@std@@QEAA@AEBV01@@Z"@IMGREL

	.section	.xdata,"dr",discard,"_CTA3?AVbad_array_new_length@std@@"
	.globl	"_CTA3?AVbad_array_new_length@std@@" # @"_CTA3?AVbad_array_new_length@std@@"
	.p2align	3, 0x0
"_CTA3?AVbad_array_new_length@std@@":
	.long	3                               # 0x3
	.long	"_CT??_R0?AVbad_array_new_length@std@@@8??0bad_array_new_length@std@@QEAA@AEBV01@@Z24"@IMGREL
	.long	"_CT??_R0?AVbad_alloc@std@@@8??0bad_alloc@std@@QEAA@AEBV01@@Z24"@IMGREL
	.long	"_CT??_R0?AVexception@std@@@8??0exception@std@@QEAA@AEBV01@@Z24"@IMGREL

	.section	.xdata,"dr",discard,"_TI3?AVbad_array_new_length@std@@"
	.globl	"_TI3?AVbad_array_new_length@std@@" # @"_TI3?AVbad_array_new_length@std@@"
	.p2align	3, 0x0
"_TI3?AVbad_array_new_length@std@@":
	.long	0                               # 0x0
	.long	"??1exception@std@@UEAA@XZ"@IMGREL
	.long	0                               # 0x0
	.long	"_CTA3?AVbad_array_new_length@std@@"@IMGREL

	.section	.rdata,"dr",discard,"??_C@_0BF@KINCDENJ@bad?5array?5new?5length?$AA@"
	.globl	"??_C@_0BF@KINCDENJ@bad?5array?5new?5length?$AA@" # @"??_C@_0BF@KINCDENJ@bad?5array?5new?5length?$AA@"
"??_C@_0BF@KINCDENJ@bad?5array?5new?5length?$AA@":
	.asciz	"bad array new length"

	.section	.rdata,"dr",largest,"??_7bad_array_new_length@std@@6B@"
	.p2align	4, 0x0                          # @0
.L__unnamed_1:
	.quad	"??_R4bad_array_new_length@std@@6B@"
	.quad	"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
	.quad	"?what@exception@std@@UEBAPEBDXZ"

	.section	.rdata,"dr",discard,"??_R4bad_array_new_length@std@@6B@"
	.globl	"??_R4bad_array_new_length@std@@6B@" # @"??_R4bad_array_new_length@std@@6B@"
	.p2align	4, 0x0
"??_R4bad_array_new_length@std@@6B@":
	.long	1                               # 0x1
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	"??_R0?AVbad_array_new_length@std@@@8"@IMGREL
	.long	"??_R3bad_array_new_length@std@@8"@IMGREL
	.long	"??_R4bad_array_new_length@std@@6B@"@IMGREL

	.section	.rdata,"dr",discard,"??_R3bad_array_new_length@std@@8"
	.globl	"??_R3bad_array_new_length@std@@8" # @"??_R3bad_array_new_length@std@@8"
	.p2align	3, 0x0
"??_R3bad_array_new_length@std@@8":
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	3                               # 0x3
	.long	"??_R2bad_array_new_length@std@@8"@IMGREL

	.section	.rdata,"dr",discard,"??_R2bad_array_new_length@std@@8"
	.globl	"??_R2bad_array_new_length@std@@8" # @"??_R2bad_array_new_length@std@@8"
	.p2align	2, 0x0
"??_R2bad_array_new_length@std@@8":
	.long	"??_R1A@?0A@EA@bad_array_new_length@std@@8"@IMGREL
	.long	"??_R1A@?0A@EA@bad_alloc@std@@8"@IMGREL
	.long	"??_R1A@?0A@EA@exception@std@@8"@IMGREL
	.long	0                               # 0x0

	.section	.rdata,"dr",discard,"??_R1A@?0A@EA@bad_array_new_length@std@@8"
	.globl	"??_R1A@?0A@EA@bad_array_new_length@std@@8" # @"??_R1A@?0A@EA@bad_array_new_length@std@@8"
	.p2align	4, 0x0
"??_R1A@?0A@EA@bad_array_new_length@std@@8":
	.long	"??_R0?AVbad_array_new_length@std@@@8"@IMGREL
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	64                              # 0x40
	.long	"??_R3bad_array_new_length@std@@8"@IMGREL

	.section	.rdata,"dr",discard,"??_R1A@?0A@EA@bad_alloc@std@@8"
	.globl	"??_R1A@?0A@EA@bad_alloc@std@@8" # @"??_R1A@?0A@EA@bad_alloc@std@@8"
	.p2align	4, 0x0
"??_R1A@?0A@EA@bad_alloc@std@@8":
	.long	"??_R0?AVbad_alloc@std@@@8"@IMGREL
	.long	1                               # 0x1
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	64                              # 0x40
	.long	"??_R3bad_alloc@std@@8"@IMGREL

	.section	.rdata,"dr",discard,"??_R3bad_alloc@std@@8"
	.globl	"??_R3bad_alloc@std@@8"         # @"??_R3bad_alloc@std@@8"
	.p2align	3, 0x0
"??_R3bad_alloc@std@@8":
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	2                               # 0x2
	.long	"??_R2bad_alloc@std@@8"@IMGREL

	.section	.rdata,"dr",discard,"??_R2bad_alloc@std@@8"
	.globl	"??_R2bad_alloc@std@@8"         # @"??_R2bad_alloc@std@@8"
	.p2align	2, 0x0
"??_R2bad_alloc@std@@8":
	.long	"??_R1A@?0A@EA@bad_alloc@std@@8"@IMGREL
	.long	"??_R1A@?0A@EA@exception@std@@8"@IMGREL
	.long	0                               # 0x0

	.section	.rdata,"dr",discard,"??_R1A@?0A@EA@exception@std@@8"
	.globl	"??_R1A@?0A@EA@exception@std@@8" # @"??_R1A@?0A@EA@exception@std@@8"
	.p2align	4, 0x0
"??_R1A@?0A@EA@exception@std@@8":
	.long	"??_R0?AVexception@std@@@8"@IMGREL
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	64                              # 0x40
	.long	"??_R3exception@std@@8"@IMGREL

	.section	.rdata,"dr",discard,"??_R3exception@std@@8"
	.globl	"??_R3exception@std@@8"         # @"??_R3exception@std@@8"
	.p2align	3, 0x0
"??_R3exception@std@@8":
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	"??_R2exception@std@@8"@IMGREL

	.section	.rdata,"dr",discard,"??_R2exception@std@@8"
	.globl	"??_R2exception@std@@8"         # @"??_R2exception@std@@8"
	.p2align	2, 0x0
"??_R2exception@std@@8":
	.long	"??_R1A@?0A@EA@exception@std@@8"@IMGREL
	.long	0                               # 0x0

	.section	.rdata,"dr",largest,"??_7bad_alloc@std@@6B@"
	.p2align	4, 0x0                          # @1
.L__unnamed_2:
	.quad	"??_R4bad_alloc@std@@6B@"
	.quad	"??_Gbad_alloc@std@@UEAAPEAXI@Z"
	.quad	"?what@exception@std@@UEBAPEBDXZ"

	.section	.rdata,"dr",discard,"??_R4bad_alloc@std@@6B@"
	.globl	"??_R4bad_alloc@std@@6B@"       # @"??_R4bad_alloc@std@@6B@"
	.p2align	4, 0x0
"??_R4bad_alloc@std@@6B@":
	.long	1                               # 0x1
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	"??_R0?AVbad_alloc@std@@@8"@IMGREL
	.long	"??_R3bad_alloc@std@@8"@IMGREL
	.long	"??_R4bad_alloc@std@@6B@"@IMGREL

	.section	.rdata,"dr",largest,"??_7exception@std@@6B@"
	.p2align	4, 0x0                          # @2
.L__unnamed_3:
	.quad	"??_R4exception@std@@6B@"
	.quad	"??_Gexception@std@@UEAAPEAXI@Z"
	.quad	"?what@exception@std@@UEBAPEBDXZ"

	.section	.rdata,"dr",discard,"??_R4exception@std@@6B@"
	.globl	"??_R4exception@std@@6B@"       # @"??_R4exception@std@@6B@"
	.p2align	4, 0x0
"??_R4exception@std@@6B@":
	.long	1                               # 0x1
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	"??_R0?AVexception@std@@@8"@IMGREL
	.long	"??_R3exception@std@@8"@IMGREL
	.long	"??_R4exception@std@@6B@"@IMGREL

	.section	.rdata,"dr",discard,"??_C@_0BC@EOODALEL@Unknown?5exception?$AA@"
	.globl	"??_C@_0BC@EOODALEL@Unknown?5exception?$AA@" # @"??_C@_0BC@EOODALEL@Unknown?5exception?$AA@"
"??_C@_0BC@EOODALEL@Unknown?5exception?$AA@":
	.asciz	"Unknown exception"

	.section	.rdata,"dr",discard,"??_C@_0BG@EOMJEIFA@vector?$DMbool?$DO?5too?5long?$AA@"
	.globl	"??_C@_0BG@EOMJEIFA@vector?$DMbool?$DO?5too?5long?$AA@" # @"??_C@_0BG@EOMJEIFA@vector?$DMbool?$DO?5too?5long?$AA@"
"??_C@_0BG@EOMJEIFA@vector?$DMbool?$DO?5too?5long?$AA@":
	.asciz	"vector<bool> too long"

	.section	.drectve,"yni"
	.ascii	" /FAILIFMISMATCH:\"annotate_string=0\""
	.ascii	" /FAILIFMISMATCH:\"annotate_vector=0\""
	.ascii	" /FAILIFMISMATCH:\"_CRT_STDIO_ISO_WIDE_SPECIFIERS=0\""
	.ascii	" /FAILIFMISMATCH:\"_MSC_VER=1900\""
	.ascii	" /FAILIFMISMATCH:\"_ITERATOR_DEBUG_LEVEL=0\""
	.ascii	" /FAILIFMISMATCH:\"RuntimeLibrary=MT_StaticRelease\""
	.ascii	" /DEFAULTLIB:libcpmt.lib"
	.globl	"??_7bad_array_new_length@std@@6B@"
.set "??_7bad_array_new_length@std@@6B@", .L__unnamed_1+8
	.globl	"??_7bad_alloc@std@@6B@"
.set "??_7bad_alloc@std@@6B@", .L__unnamed_2+8
	.globl	"??_7exception@std@@6B@"
.set "??_7exception@std@@6B@", .L__unnamed_3+8
	.addrsig
	.addrsig_sym __CxxFrameHandler3
	.addrsig_sym "??_7type_info@@6B@"
	.addrsig_sym "??_R0?AVbad_array_new_length@std@@@8"
	.addrsig_sym __ImageBase
	.addrsig_sym "??_R0?AVbad_alloc@std@@@8"
	.addrsig_sym "??_R0?AVexception@std@@@8"
	.addrsig_sym "??_R4bad_array_new_length@std@@6B@"
	.addrsig_sym "??_R3bad_array_new_length@std@@8"
	.addrsig_sym "??_R2bad_array_new_length@std@@8"
	.addrsig_sym "??_R1A@?0A@EA@bad_array_new_length@std@@8"
	.addrsig_sym "??_R1A@?0A@EA@bad_alloc@std@@8"
	.addrsig_sym "??_R3bad_alloc@std@@8"
	.addrsig_sym "??_R2bad_alloc@std@@8"
	.addrsig_sym "??_R1A@?0A@EA@exception@std@@8"
	.addrsig_sym "??_R3exception@std@@8"
	.addrsig_sym "??_R2exception@std@@8"
	.addrsig_sym "??_R4bad_alloc@std@@6B@"
	.addrsig_sym "??_R4exception@std@@6B@"
