	.text
	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
.set @feat.00, 0
	.intel_syntax noprefix
	.file	"assembly.cpp"
	.def	"?solve_max_independent_set@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@2@@Z";
	.scl	2;
	.type	32;
	.endef
	.globl	"?solve_max_independent_set@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@2@@Z" # -- Begin function ?solve_max_independent_set@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@2@@Z
	.p2align	4, 0x90
"?solve_max_independent_set@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@2@@Z": # @"?solve_max_independent_set@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@2@@Z"
.seh_proc "?solve_max_independent_set@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@2@@Z"
# %bb.0:
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 32
	.seh_stackalloc 32
	.seh_endprologue
	mov	rsi, rcx
	call	"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	mov	rax, rsi
	add	rsp, 32
	pop	rsi
	ret
	.seh_endproc
                                        # -- End function
	.def	"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.globl	"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z" # -- Begin function ?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z
	.p2align	4, 0x90
"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z": # @"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
.Lfunc_begin0:
.seh_proc "?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 264
	.seh_stackalloc 264
	lea	rbp, [rsp + 128]
	.seh_setframe rbp, 128
	.seh_endprologue
	mov	qword ptr [rbp + 128], -2
	mov	esi, edx
	mov	r12, rcx
	mov	eax, dword ptr [rip + "?$TSS0@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"]
	mov	ecx, dword ptr [rip + _tls_index]
	mov	rdx, qword ptr gs:[88]
	mov	rcx, qword ptr [rdx + 8*rcx]
	cmp	eax, dword ptr [rcx + _Init_thread_epoch@SECREL32]
	jg	.LBB1_1
.LBB1_3:
	cmp	byte ptr [rip + "?has_popcnt@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@4_NB"], 0
	je	.LBB1_5
# %bb.4:
	mov	rcx, r12
	mov	edx, esi
	call	"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	mov	rax, r12
	jmp	.LBB1_96
.LBB1_5:
	pxor	xmm0, xmm0
	movdqa	xmmword ptr [rbp + 32], xmm0
	mov	qword ptr [rbp + 48], 0
	test	esi, esi
	je	.LBB1_6
# %bb.7:
	js	.LBB1_97
# %bb.8:
	mov	r14, r8
	movsxd	r15, esi
	lea	rbx, [8*r15]
	cmp	esi, 512
	jb	.LBB1_10
# %bb.9:
	lea	rcx, [rbx + 39]
	call	"??2@YAPEAX_K@Z"
	lea	rdi, [rax + 39]
	and	rdi, -32
	mov	qword ptr [rdi - 8], rax
	jmp	.LBB1_11
.LBB1_6:
	xor	edi, edi
	jmp	.LBB1_12
.LBB1_10:
	mov	rcx, rbx
	call	"??2@YAPEAX_K@Z"
	mov	rdi, rax
.LBB1_11:
	mov	qword ptr [rbp + 32], rdi
	lea	r15, [rdi + 8*r15]
	mov	qword ptr [rbp + 48], r15
	mov	rcx, rdi
	xor	edx, edx
	mov	r8, rbx
	call	memset
	mov	qword ptr [rbp + 40], r15
	mov	r8, r14
.LBB1_12:
	mov	rdx, qword ptr [r8]
	mov	r8, qword ptr [r8 + 8]
	cmp	rdx, r8
	je	.LBB1_14
	.p2align	4, 0x90
.LBB1_98:                               # =>This Inner Loop Header: Depth=1
	mov	rax, qword ptr [rdx]
	mov	rcx, rax
	shr	rcx, 32
	mov	r9d, 1
                                        # kill: def $cl killed $cl killed $rcx
	shl	r9, cl
	movsxd	rcx, eax
	or	qword ptr [rdi + 8*rcx], r9
	mov	r9d, 1
	mov	ecx, eax
	shl	r9, cl
	sar	rax, 32
	or	qword ptr [rdi + 8*rax], r9
	add	rdx, 8
	cmp	rdx, r8
	jne	.LBB1_98
.LBB1_14:
	mov	qword ptr [rbp], 0
	mov	dword ptr [rbp + 88], 0
	lea	r15d, [rsi + 1]
	mov	eax, r15d
	shr	eax, 31
	lea	ecx, [rsi + rax]
	inc	ecx
	shr	ecx
	mov	eax, 1
                                        # kill: def $cl killed $cl killed $ecx
	shl	eax, cl
	cmp	eax, 65536
	mov	ecx, 65536
	cmovb	ecx, eax
	mov	dword ptr [rbp - 8], ecx
	lea	rax, [rbp - 8]
	mov	qword ptr [rbp - 80], rax
	lea	rax, [rbp + 88]
	mov	qword ptr [rbp - 72], rax
	lea	rax, [rbp + 32]
	mov	qword ptr [rbp - 64], rax
	mov	rax, rbp
	mov	r14, -1
	mov	ecx, esi
	shl	r14, cl
	mov	qword ptr [rbp - 56], rax
	not	r14
	xor	ebx, ebx
	lea	rdi, [rbp - 80]
	mov	qword ptr [rbp + 112], r12      # 8-byte Spill
	.p2align	4, 0x90
.LBB1_15:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB1_19 Depth 2
	test	r14, r14
	je	.LBB1_25
# %bb.16:                               #   in Loop: Header=BB1_15 Depth=1
	mov	rax, r14
	neg	rax
	and	rax, r14
	je	.LBB1_17
# %bb.18:                               #   in Loop: Header=BB1_15 Depth=1
	mov	rcx, qword ptr [rbp + 32]
	xor	r8d, r8d
	.p2align	4, 0x90
.LBB1_19:                               #   Parent Loop BB1_15 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	rep		bsf	rdx, rax
	btr	rax, rdx
	btr	r14, rdx
	bts	r8, rdx
	mov	rdx, qword ptr [rcx + 8*rdx]
	and	rdx, r14
	or	rax, rdx
	jne	.LBB1_19
	jmp	.LBB1_20
	.p2align	4, 0x90
.LBB1_17:                               #   in Loop: Header=BB1_15 Depth=1
	xor	r8d, r8d
.LBB1_20:                               #   in Loop: Header=BB1_15 Depth=1
	mov	qword ptr [rbp], 0
	mov	dword ptr [rbp + 88], 0
.Ltmp0:
	mov	dword ptr [rsp + 32], 0
	mov	rcx, rdi
	mov	rdx, rdi
	xor	r9d, r9d
	call	"??$?RAEAV<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@@<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@QEBA@AEAV0?0??12@YA?AV34@H0@Z@_K2H@Z"
.Ltmp1:
# %bb.21:                               #   in Loop: Header=BB1_15 Depth=1
	or	rbx, qword ptr [rbp]
	test	al, al
	jne	.LBB1_15
# %bb.22:
	mov	r13d, esi
	shr	r13d, 31
	add	r13d, esi
	sar	r13d
	mov	r14d, esi
	sub	r14d, r13d
	mov	eax, 1
	mov	edx, 1
	mov	ecx, r13d
	shl	edx, cl
	mov	dword ptr [rbp + 92], edx       # 4-byte Spill
	mov	ecx, r14d
	shl	eax, cl
	pxor	xmm0, xmm0
	movdqa	xmmword ptr [rbp + 64], xmm0
	mov	qword ptr [rbp + 80], 0
	mov	qword ptr [rbp + 96], rax       # 8-byte Spill
	lea	r12, [4*rax]
	cmp	r14d, 10
	mov	dword ptr [rbp + 124], r15d     # 4-byte Spill
	jb	.LBB1_33
# %bb.23:
	lea	rcx, [r12 + 39]
.Ltmp4:
	call	"??2@YAPEAX_K@Z"
.Ltmp5:
# %bb.24:
	mov	rbx, rax
	add	rbx, 39
	and	rbx, -32
	mov	qword ptr [rbx - 8], rax
	jmp	.LBB1_35
.LBB1_25:
	pxor	xmm0, xmm0
	movdqu	xmmword ptr [r12], xmm0
	mov	qword ptr [r12 + 16], 0
	mov	dword ptr [rbp + 64], 0
	test	esi, esi
	jle	.LBB1_82
# %bb.26:
	xor	eax, eax
	lea	rdi, [rbp + 64]
	jmp	.LBB1_27
	.p2align	4, 0x90
.LBB1_29:                               #   in Loop: Header=BB1_27 Depth=1
	mov	dword ptr [rdx], eax
	add	rdx, 4
	mov	qword ptr [rcx + 8], rdx
.LBB1_31:                               #   in Loop: Header=BB1_27 Depth=1
	mov	eax, dword ptr [rbp + 64]
	inc	eax
	mov	dword ptr [rbp + 64], eax
	cmp	eax, esi
	jge	.LBB1_82
.LBB1_27:                               # =>This Inner Loop Header: Depth=1
	bt	rbx, rax
	jae	.LBB1_31
# %bb.28:                               #   in Loop: Header=BB1_27 Depth=1
	mov	rcx, qword ptr [rbp + 112]      # 8-byte Reload
	mov	rdx, qword ptr [rcx + 8]
	cmp	rdx, qword ptr [rcx + 16]
	jne	.LBB1_29
# %bb.30:                               #   in Loop: Header=BB1_27 Depth=1
.Ltmp16:
	mov	r8, rdi
	call	"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
.Ltmp17:
	jmp	.LBB1_31
.LBB1_33:
.Ltmp2:
	mov	rcx, r12
	call	"??2@YAPEAX_K@Z"
.Ltmp3:
# %bb.34:
	mov	rbx, rax
.LBB1_35:
	mov	qword ptr [rbp + 64], rbx
	mov	rax, qword ptr [rbp + 96]       # 8-byte Reload
	lea	rdi, [rbx + 4*rax]
	mov	qword ptr [rbp + 80], rdi
	mov	rcx, rbx
	xor	edx, edx
	mov	r8, r12
	call	memset
	mov	qword ptr [rbp + 8], rdi        # 8-byte Spill
	mov	qword ptr [rbp + 72], rdi
	mov	eax, r13d
	mov	qword ptr [rbp - 16], rax       # 8-byte Spill
	cmp	esi, r13d
	jne	.LBB1_36
.LBB1_40:
	mov	r15d, dword ptr [rbp + 92]      # 4-byte Reload
	lea	rdi, [4*r15]
	cmp	r13d, 10
	mov	qword ptr [rbp + 16], r13       # 8-byte Spill
	mov	qword ptr [rbp + 24], rdi       # 8-byte Spill
	jb	.LBB1_43
# %bb.41:
	lea	rcx, [rdi + 39]
.Ltmp8:
	call	"??2@YAPEAX_K@Z"
.Ltmp9:
# %bb.42:
	mov	r12, rax
	add	r12, 39
	and	r12, -32
	mov	qword ptr [r12 - 8], rax
	jmp	.LBB1_45
.LBB1_36:
	mov	rdx, qword ptr [rbp + 32]
	mov	rax, qword ptr [rbp + 96]       # 8-byte Reload
	cmp	eax, 3
	mov	r8d, 2
	cmovae	r8d, eax
	dec	r8
	xor	r9d, r9d
	jmp	.LBB1_37
	.p2align	4, 0x90
.LBB1_39:                               #   in Loop: Header=BB1_37 Depth=1
	mov	dword ptr [rbx + 4*r9 + 4], edi
	mov	r9, r10
	cmp	r8, r10
	je	.LBB1_40
.LBB1_37:                               # =>This Inner Loop Header: Depth=1
	lea	r10, [r9 + 1]
	rep		bsf	eax, r10d
	mov	r11d, r9d
	lea	ecx, [rax + r13]
	movsxd	rcx, ecx
	mov	r15, qword ptr [rdx + 8*rcx]
	mov	rcx, qword ptr [rbp - 16]       # 8-byte Reload
                                        # kill: def $cl killed $cl killed $rcx
	shr	r15, cl
	and	r11d, r10d
	not	r15d
	and	r15d, r11d
	mov	edi, 1
	mov	ecx, eax
	shl	edi, cl
	add	edi, dword ptr [rbp + 96]       # 4-byte Folded Reload
	add	edi, dword ptr [rbx + 4*r15]
	mov	r15d, edi
	mov	ecx, r14d
	shr	r15d, cl
	mov	eax, dword ptr [rbx + 4*r11]
	mov	r11d, eax
	shr	r11d, cl
	cmp	r15d, r11d
	ja	.LBB1_39
# %bb.38:                               #   in Loop: Header=BB1_37 Depth=1
	mov	edi, eax
	jmp	.LBB1_39
.LBB1_43:
.Ltmp6:
	mov	rcx, rdi
	call	"??2@YAPEAX_K@Z"
.Ltmp7:
# %bb.44:
	mov	r12, rax
.LBB1_45:
	mov	rax, qword ptr [rbp + 96]       # 8-byte Reload
	mov	edx, eax
	mov	qword ptr [rbp - 48], r12
	lea	r13, [r12 + 4*r15]
	mov	qword ptr [rbp - 32], r13
	dec	edx
	je	.LBB1_52
# %bb.46:
	cmp	dword ptr [rbp + 16], 3         # 4-byte Folded Reload
	jae	.LBB1_48
# %bb.47:
	mov	r13, r12
	jmp	.LBB1_51
.LBB1_52:
	mov	rcx, r12
	mov	edi, edx
	xor	edx, edx
	mov	r8, qword ptr [rbp + 24]        # 8-byte Reload
	call	memset
	mov	edx, edi
	jmp	.LBB1_53
.LBB1_48:
	mov	eax, r15d
	and	eax, -8
	and	r15d, 7
	lea	r13, [r12 + 4*rax]
	movd	xmm0, edx
	pshufd	xmm0, xmm0, 0                   # xmm0 = xmm0[0,0,0,0]
	xor	ecx, ecx
	.p2align	4, 0x90
.LBB1_49:                               # =>This Inner Loop Header: Depth=1
	movdqu	xmmword ptr [r12 + 4*rcx], xmm0
	movdqu	xmmword ptr [r12 + 4*rcx + 16], xmm0
	add	rcx, 8
	cmp	rax, rcx
	jne	.LBB1_49
# %bb.50:
	test	rax, rax
	jne	.LBB1_53
	.p2align	4, 0x90
.LBB1_51:                               # =>This Inner Loop Header: Depth=1
	mov	dword ptr [r13], edx
	add	r13, 4
	dec	r15
	jne	.LBB1_51
.LBB1_53:
	mov	qword ptr [rbp - 40], r13
	mov	rax, qword ptr [rbp + 8]        # 8-byte Reload
	mov	eax, dword ptr [rax - 4]
	mov	r15d, eax
	and	r15d, edx
	mov	rcx, qword ptr [rbp + 16]       # 8-byte Reload
                                        # kill: def $cl killed $cl killed $rcx
	shl	r15, cl
	cmp	dword ptr [rbp + 124], 3        # 4-byte Folded Reload
	jae	.LBB1_54
.LBB1_58:
	pxor	xmm0, xmm0
	mov	rax, qword ptr [rbp + 112]      # 8-byte Reload
	movdqu	xmmword ptr [rax], xmm0
	mov	qword ptr [rax + 16], 0
	mov	dword ptr [rbp + 108], 0
	test	esi, esi
	mov	rdi, qword ptr [rbp + 16]       # 8-byte Reload
	jle	.LBB1_65
# %bb.59:
	xor	eax, eax
	lea	r14, [rbp + 108]
	jmp	.LBB1_60
	.p2align	4, 0x90
.LBB1_62:                               #   in Loop: Header=BB1_60 Depth=1
	mov	dword ptr [rdx], eax
	add	rdx, 4
	mov	qword ptr [rcx + 8], rdx
.LBB1_88:                               #   in Loop: Header=BB1_60 Depth=1
	mov	eax, dword ptr [rbp + 108]
	inc	eax
	mov	dword ptr [rbp + 108], eax
	cmp	eax, esi
	jge	.LBB1_65
.LBB1_60:                               # =>This Inner Loop Header: Depth=1
	bt	r15, rax
	jae	.LBB1_88
# %bb.61:                               #   in Loop: Header=BB1_60 Depth=1
	mov	rcx, qword ptr [rbp + 112]      # 8-byte Reload
	mov	rdx, qword ptr [rcx + 8]
	cmp	rdx, qword ptr [rcx + 16]
	jne	.LBB1_62
# %bb.87:                               #   in Loop: Header=BB1_60 Depth=1
.Ltmp10:
	mov	r8, r14
	call	"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
.Ltmp11:
	jmp	.LBB1_88
.LBB1_65:
	test	r12, r12
	je	.LBB1_74
# %bb.66:
	cmp	edi, 10
	jb	.LBB1_67
# %bb.68:
	mov	rax, qword ptr [r12 - 8]
	add	r12, -8
	sub	r12, rax
	cmp	r12, 32
	mov	rdx, qword ptr [rbp + 24]       # 8-byte Reload
	jae	.LBB1_69
# %bb.72:
	add	rdx, 39
	mov	r12, rax
	jmp	.LBB1_73
.LBB1_54:
	mov	dword ptr [rbp + 8], edx        # 4-byte Spill
	mov	ecx, r14d
	shr	eax, cl
	mov	dword ptr [rbp + 124], eax      # 4-byte Spill
	mov	rdi, qword ptr [rbp + 32]
	mov	rcx, qword ptr [rbp + 96]       # 8-byte Reload
	mov	eax, ecx
	neg	eax
	mov	dword ptr [rbp - 4], eax        # 4-byte Spill
	mov	eax, dword ptr [rbp + 92]       # 4-byte Reload
	cmp	eax, 3
	mov	r9d, 2
	cmovae	r9d, eax
	mov	r10d, 1
	movabs	r11, 4294967296
	mov	qword ptr [rbp - 24], rsi       # 8-byte Spill
	jmp	.LBB1_55
	.p2align	4, 0x90
.LBB1_57:                               #   in Loop: Header=BB1_55 Depth=1
	mov	dword ptr [r12 + 4*r10], -2147483648
.LBB1_64:                               #   in Loop: Header=BB1_55 Depth=1
	inc	r10
	inc	r11
	cmp	r9, r10
	je	.LBB1_58
.LBB1_55:                               # =>This Inner Loop Header: Depth=1
	mov	ecx, r11d
	and	ecx, r10d
	and	ecx, -2
	mov	r13d, dword ptr [r12 + 4*rcx]
	test	r13d, r13d
	js	.LBB1_57
# %bb.56:                               #   in Loop: Header=BB1_55 Depth=1
	rep		bsf	r8d, r10d
	mov	r8, qword ptr [rdi + 8*r8]
	test	r8d, ecx
	jne	.LBB1_57
# %bb.63:                               #   in Loop: Header=BB1_55 Depth=1
	mov	rsi, qword ptr [rbp - 16]       # 8-byte Reload
	mov	ecx, esi
	shr	r8, cl
	not	r8d
	mov	eax, dword ptr [rbp + 8]        # 4-byte Reload
	mov	ecx, eax
	and	ecx, r13d
	and	ecx, r8d
	and	r13d, dword ptr [rbp - 4]       # 4-byte Folded Reload
	add	r13d, dword ptr [rbp + 96]      # 4-byte Folded Reload
	or	r13d, ecx
	mov	dword ptr [r12 + 4*r10], r13d
	mov	ecx, r13d
	and	ecx, eax
	mov	r8d, dword ptr [rbx + 4*rcx]
	mov	ecx, r14d
	shr	r13d, cl
	mov	edx, r8d
	shr	edx, cl
	add	edx, r13d
	and	r8d, eax
	mov	ecx, esi
	mov	rsi, qword ptr [rbp - 24]       # 8-byte Reload
	shl	r8, cl
	or	r8, r10
	mov	eax, dword ptr [rbp + 124]      # 4-byte Reload
	cmp	edx, eax
	cmova	r15, r8
	cmova	eax, edx
	mov	dword ptr [rbp + 124], eax      # 4-byte Spill
	jmp	.LBB1_64
.LBB1_67:
	mov	rdx, qword ptr [rbp + 24]       # 8-byte Reload
.LBB1_73:
	mov	rcx, r12
	call	"??3@YAXPEAX_K@Z"
	mov	rbx, qword ptr [rbp + 64]
.LBB1_74:
	test	rbx, rbx
	je	.LBB1_82
# %bb.75:
	mov	rdx, qword ptr [rbp + 80]
	sub	rdx, rbx
	cmp	rdx, 4096
	jb	.LBB1_81
# %bb.76:
	mov	rax, qword ptr [rbx - 8]
	add	rbx, -8
	sub	rbx, rax
	cmp	rbx, 32
	jae	.LBB1_77
# %bb.80:
	add	rdx, 39
	mov	rbx, rax
.LBB1_81:
	mov	rcx, rbx
	call	"??3@YAXPEAX_K@Z"
.LBB1_82:
	mov	rsi, qword ptr [rbp + 112]      # 8-byte Reload
	mov	rcx, qword ptr [rbp + 32]
	test	rcx, rcx
	je	.LBB1_95
# %bb.83:
	mov	rdx, qword ptr [rbp + 48]
	sub	rdx, rcx
	cmp	rdx, 4096
	jb	.LBB1_94
# %bb.84:
	mov	rax, qword ptr [rcx - 8]
	add	rcx, -8
	sub	rcx, rax
	cmp	rcx, 32
	jae	.LBB1_85
# %bb.93:
	add	rdx, 39
	mov	rcx, rax
.LBB1_94:
	call	"??3@YAXPEAX_K@Z"
.LBB1_95:
	mov	rax, rsi
.LBB1_96:
	add	rsp, 264
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret
.LBB1_1:
	lea	rcx, [rip + "?$TSS0@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"]
	mov	rdi, r8
	call	_Init_thread_header
	mov	r8, rdi
	cmp	dword ptr [rip + "?$TSS0@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"], -1
	jne	.LBB1_3
# %bb.2:
	mov	eax, 1
	xor	ecx, ecx
	#APP
	xchg	r8, rbx
	cpuid
	xchg	r8, rbx
	#NO_APP
	shr	ecx, 23
	and	cl, 1
	mov	byte ptr [rip + "?has_popcnt@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@4_NB"], cl
	lea	rcx, [rip + "?$TSS0@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"]
	call	_Init_thread_footer
	mov	r8, rdi
	jmp	.LBB1_3
.LBB1_97:
	call	"?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ"
.LBB1_85:
.Ltmp18:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp19:
# %bb.86:
.LBB1_69:
.Ltmp12:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp13:
# %bb.70:
.LBB1_77:
.Ltmp14:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp15:
# %bb.78:
	int3
	.seh_handlerdata
	.long	("$cppxdata$?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z")@IMGREL
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$32@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$32@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$32@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_32:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	mov	rcx, qword ptr [rbp + 112]      # 8-byte Reload
	call	"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	nop
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret                                     # CLEANUPRET
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$71@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$71@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$71@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_71:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	call	__std_terminate
	int3
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$79@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$79@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$79@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_79:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	call	__std_terminate
	int3
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$89@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$89@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$89@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_89:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	mov	rcx, qword ptr [rbp + 112]      # 8-byte Reload
	call	"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	lea	rcx, [rbp - 48]
	call	"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	nop
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret                                     # CLEANUPRET
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$90@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$90@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$90@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_90:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	lea	rcx, [rbp + 64]
	call	"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	nop
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret                                     # CLEANUPRET
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$91@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$91@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$91@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_91:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	lea	rcx, [rbp + 32]
	call	"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
	nop
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret                                     # CLEANUPRET
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$92@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$92@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$92@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB1_92:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end0:
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.p2align	2, 0x0
"$cppxdata$?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z":
	.long	429065506                       # MagicNumber
	.long	7                               # MaxState
	.long	("$stateUnwindMap$?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	13                              # IPMapEntries
	.long	("$ip2state$?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z")@IMGREL # IPToStateXData
	.long	256                             # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z":
	.long	-1                              # ToState
	.long	"?dtor$71@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	-1                              # ToState
	.long	"?dtor$79@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	-1                              # ToState
	.long	"?dtor$91@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	2                               # ToState
	.long	"?dtor$90@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	3                               # ToState
	.long	"?dtor$89@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	2                               # ToState
	.long	"?dtor$32@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	-1                              # ToState
	.long	"?dtor$92@?0??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
"$ip2state$?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z":
	.long	.Lfunc_begin0@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp0@IMGREL+1                 # IP
	.long	2                               # ToState
	.long	.Ltmp16@IMGREL+1                # IP
	.long	5                               # ToState
	.long	.Ltmp2@IMGREL+1                 # IP
	.long	2                               # ToState
	.long	.Ltmp3@IMGREL+1                 # IP
	.long	-1                              # ToState
	.long	.Ltmp8@IMGREL+1                 # IP
	.long	3                               # ToState
	.long	.Ltmp7@IMGREL+1                 # IP
	.long	-1                              # ToState
	.long	.Ltmp10@IMGREL+1                # IP
	.long	4                               # ToState
	.long	.Ltmp11@IMGREL+1                # IP
	.long	-1                              # ToState
	.long	.Ltmp18@IMGREL+1                # IP
	.long	6                               # ToState
	.long	.Ltmp12@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp14@IMGREL+1                # IP
	.long	1                               # ToState
	.long	.Ltmp15@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"?maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
                                        # -- End function
	.def	"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.globl	"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z" # -- Begin function ?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z
	.p2align	4, 0x90
"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z": # @"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
.Lfunc_begin1:
.seh_proc "?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 264
	.seh_stackalloc 264
	lea	rbp, [rsp + 128]
	.seh_setframe rbp, 128
	.seh_endprologue
	mov	qword ptr [rbp + 128], -2
	mov	rbx, r8
	mov	esi, edx
	mov	r12, rcx
	pxor	xmm0, xmm0
	movdqa	xmmword ptr [rbp + 32], xmm0
	mov	qword ptr [rbp + 48], 0
	test	edx, edx
	je	.LBB2_1
# %bb.2:
	js	.LBB2_91
# %bb.3:
	movsxd	r15, esi
	lea	r14, [8*r15]
	cmp	esi, 512
	jb	.LBB2_5
# %bb.4:
	lea	rcx, [r14 + 39]
	call	"??2@YAPEAX_K@Z"
	lea	rdi, [rax + 39]
	and	rdi, -32
	mov	qword ptr [rdi - 8], rax
	jmp	.LBB2_6
.LBB2_1:
	xor	edi, edi
	jmp	.LBB2_7
.LBB2_5:
	mov	rcx, r14
	call	"??2@YAPEAX_K@Z"
	mov	rdi, rax
.LBB2_6:
	mov	qword ptr [rbp + 32], rdi
	lea	r15, [rdi + 8*r15]
	mov	qword ptr [rbp + 48], r15
	mov	rcx, rdi
	xor	edx, edx
	mov	r8, r14
	call	memset
	mov	qword ptr [rbp + 40], r15
.LBB2_7:
	mov	rdx, qword ptr [rbx]
	mov	r8, qword ptr [rbx + 8]
	cmp	rdx, r8
	je	.LBB2_9
	.p2align	4, 0x90
.LBB2_92:                               # =>This Inner Loop Header: Depth=1
	mov	rax, qword ptr [rdx]
	mov	rcx, rax
	shr	rcx, 32
	mov	r9d, 1
                                        # kill: def $cl killed $cl killed $rcx
	shl	r9, cl
	movsxd	rcx, eax
	or	qword ptr [rdi + 8*rcx], r9
	mov	r9d, 1
	mov	ecx, eax
	shl	r9, cl
	sar	rax, 32
	or	qword ptr [rdi + 8*rax], r9
	add	rdx, 8
	cmp	rdx, r8
	jne	.LBB2_92
.LBB2_9:
	mov	qword ptr [rbp], 0
	mov	dword ptr [rbp + 88], 0
	lea	r15d, [rsi + 1]
	mov	eax, r15d
	shr	eax, 31
	lea	ecx, [rsi + rax]
	inc	ecx
	shr	ecx
	mov	eax, 1
                                        # kill: def $cl killed $cl killed $ecx
	shl	eax, cl
	cmp	eax, 65536
	mov	ecx, 65536
	cmovb	ecx, eax
	mov	dword ptr [rbp - 8], ecx
	lea	rax, [rbp - 8]
	mov	qword ptr [rbp - 80], rax
	lea	rax, [rbp + 88]
	mov	qword ptr [rbp - 72], rax
	lea	rax, [rbp + 32]
	mov	qword ptr [rbp - 64], rax
	mov	rax, rbp
	mov	r14, -1
	mov	ecx, esi
	shl	r14, cl
	mov	qword ptr [rbp - 56], rax
	not	r14
	xor	ebx, ebx
	lea	rdi, [rbp - 80]
	mov	qword ptr [rbp + 112], r12      # 8-byte Spill
	.p2align	4, 0x90
.LBB2_10:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB2_14 Depth 2
	test	r14, r14
	je	.LBB2_20
# %bb.11:                               #   in Loop: Header=BB2_10 Depth=1
	mov	rax, r14
	neg	rax
	and	rax, r14
	je	.LBB2_12
# %bb.13:                               #   in Loop: Header=BB2_10 Depth=1
	mov	rcx, qword ptr [rbp + 32]
	xor	r8d, r8d
	.p2align	4, 0x90
.LBB2_14:                               #   Parent Loop BB2_10 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	rep		bsf	rdx, rax
	btr	rax, rdx
	btr	r14, rdx
	bts	r8, rdx
	mov	rdx, qword ptr [rcx + 8*rdx]
	and	rdx, r14
	or	rax, rdx
	jne	.LBB2_14
	jmp	.LBB2_15
	.p2align	4, 0x90
.LBB2_12:                               #   in Loop: Header=BB2_10 Depth=1
	xor	r8d, r8d
.LBB2_15:                               #   in Loop: Header=BB2_10 Depth=1
	mov	qword ptr [rbp], 0
	mov	dword ptr [rbp + 88], 0
.Ltmp20:
	mov	dword ptr [rsp + 32], 0
	mov	rcx, rdi
	mov	rdx, rdi
	xor	r9d, r9d
	call	"??$?RAEAV<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@@<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@QEBA@AEAV0?0??12@YA?AV34@H0@Z@_K2H@Z"
.Ltmp21:
# %bb.16:                               #   in Loop: Header=BB2_10 Depth=1
	or	rbx, qword ptr [rbp]
	test	al, al
	jne	.LBB2_10
# %bb.17:
	mov	r13d, esi
	shr	r13d, 31
	add	r13d, esi
	sar	r13d
	mov	r14d, esi
	sub	r14d, r13d
	mov	eax, 1
	mov	edx, 1
	mov	ecx, r13d
	shl	edx, cl
	mov	dword ptr [rbp + 92], edx       # 4-byte Spill
	mov	ecx, r14d
	shl	eax, cl
	pxor	xmm0, xmm0
	movdqa	xmmword ptr [rbp + 64], xmm0
	mov	qword ptr [rbp + 80], 0
	mov	qword ptr [rbp + 96], rax       # 8-byte Spill
	lea	r12, [4*rax]
	cmp	r14d, 10
	mov	dword ptr [rbp + 124], r15d     # 4-byte Spill
	jb	.LBB2_28
# %bb.18:
	lea	rcx, [r12 + 39]
.Ltmp24:
	call	"??2@YAPEAX_K@Z"
.Ltmp25:
# %bb.19:
	mov	rbx, rax
	add	rbx, 39
	and	rbx, -32
	mov	qword ptr [rbx - 8], rax
	jmp	.LBB2_30
.LBB2_20:
	pxor	xmm0, xmm0
	movdqu	xmmword ptr [r12], xmm0
	mov	qword ptr [r12 + 16], 0
	mov	dword ptr [rbp + 64], 0
	test	esi, esi
	jle	.LBB2_77
# %bb.21:
	xor	eax, eax
	lea	rdi, [rbp + 64]
	jmp	.LBB2_22
	.p2align	4, 0x90
.LBB2_24:                               #   in Loop: Header=BB2_22 Depth=1
	mov	dword ptr [rdx], eax
	add	rdx, 4
	mov	qword ptr [rcx + 8], rdx
.LBB2_26:                               #   in Loop: Header=BB2_22 Depth=1
	mov	eax, dword ptr [rbp + 64]
	inc	eax
	mov	dword ptr [rbp + 64], eax
	cmp	eax, esi
	jge	.LBB2_77
.LBB2_22:                               # =>This Inner Loop Header: Depth=1
	bt	rbx, rax
	jae	.LBB2_26
# %bb.23:                               #   in Loop: Header=BB2_22 Depth=1
	mov	rcx, qword ptr [rbp + 112]      # 8-byte Reload
	mov	rdx, qword ptr [rcx + 8]
	cmp	rdx, qword ptr [rcx + 16]
	jne	.LBB2_24
# %bb.25:                               #   in Loop: Header=BB2_22 Depth=1
.Ltmp36:
	mov	r8, rdi
	call	"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
.Ltmp37:
	jmp	.LBB2_26
.LBB2_28:
.Ltmp22:
	mov	rcx, r12
	call	"??2@YAPEAX_K@Z"
.Ltmp23:
# %bb.29:
	mov	rbx, rax
.LBB2_30:
	mov	qword ptr [rbp + 64], rbx
	mov	rax, qword ptr [rbp + 96]       # 8-byte Reload
	lea	rdi, [rbx + 4*rax]
	mov	qword ptr [rbp + 80], rdi
	mov	rcx, rbx
	xor	edx, edx
	mov	r8, r12
	call	memset
	mov	qword ptr [rbp + 8], rdi        # 8-byte Spill
	mov	qword ptr [rbp + 72], rdi
	mov	eax, r13d
	mov	qword ptr [rbp - 16], rax       # 8-byte Spill
	cmp	esi, r13d
	jne	.LBB2_31
.LBB2_35:
	mov	r15d, dword ptr [rbp + 92]      # 4-byte Reload
	lea	rdi, [4*r15]
	cmp	r13d, 10
	mov	qword ptr [rbp + 16], r13       # 8-byte Spill
	mov	qword ptr [rbp + 24], rdi       # 8-byte Spill
	jb	.LBB2_38
# %bb.36:
	lea	rcx, [rdi + 39]
.Ltmp28:
	call	"??2@YAPEAX_K@Z"
.Ltmp29:
# %bb.37:
	mov	r12, rax
	add	r12, 39
	and	r12, -32
	mov	qword ptr [r12 - 8], rax
	jmp	.LBB2_40
.LBB2_31:
	mov	rdx, qword ptr [rbp + 32]
	mov	rax, qword ptr [rbp + 96]       # 8-byte Reload
	cmp	eax, 3
	mov	r8d, 2
	cmovae	r8d, eax
	dec	r8
	xor	r9d, r9d
	jmp	.LBB2_32
	.p2align	4, 0x90
.LBB2_34:                               #   in Loop: Header=BB2_32 Depth=1
	mov	dword ptr [rbx + 4*r9 + 4], edi
	mov	r9, r10
	cmp	r8, r10
	je	.LBB2_35
.LBB2_32:                               # =>This Inner Loop Header: Depth=1
	lea	r10, [r9 + 1]
	rep		bsf	eax, r10d
	mov	r11d, r9d
	lea	ecx, [rax + r13]
	movsxd	rcx, ecx
	mov	r15, qword ptr [rdx + 8*rcx]
	mov	rcx, qword ptr [rbp - 16]       # 8-byte Reload
                                        # kill: def $cl killed $cl killed $rcx
	shr	r15, cl
	and	r11d, r10d
	not	r15d
	and	r15d, r11d
	mov	edi, 1
	mov	ecx, eax
	shl	edi, cl
	add	edi, dword ptr [rbp + 96]       # 4-byte Folded Reload
	add	edi, dword ptr [rbx + 4*r15]
	mov	r15d, edi
	mov	ecx, r14d
	shr	r15d, cl
	mov	eax, dword ptr [rbx + 4*r11]
	mov	r11d, eax
	shr	r11d, cl
	cmp	r15d, r11d
	ja	.LBB2_34
# %bb.33:                               #   in Loop: Header=BB2_32 Depth=1
	mov	edi, eax
	jmp	.LBB2_34
.LBB2_38:
.Ltmp26:
	mov	rcx, rdi
	call	"??2@YAPEAX_K@Z"
.Ltmp27:
# %bb.39:
	mov	r12, rax
.LBB2_40:
	mov	rax, qword ptr [rbp + 96]       # 8-byte Reload
	mov	edx, eax
	mov	qword ptr [rbp - 48], r12
	lea	r13, [r12 + 4*r15]
	mov	qword ptr [rbp - 32], r13
	dec	edx
	je	.LBB2_47
# %bb.41:
	cmp	dword ptr [rbp + 16], 3         # 4-byte Folded Reload
	jae	.LBB2_43
# %bb.42:
	mov	r13, r12
	jmp	.LBB2_46
.LBB2_47:
	mov	rcx, r12
	mov	edi, edx
	xor	edx, edx
	mov	r8, qword ptr [rbp + 24]        # 8-byte Reload
	call	memset
	mov	edx, edi
	jmp	.LBB2_48
.LBB2_43:
	mov	eax, r15d
	and	eax, -8
	and	r15d, 7
	lea	r13, [r12 + 4*rax]
	movd	xmm0, edx
	pshufd	xmm0, xmm0, 0                   # xmm0 = xmm0[0,0,0,0]
	xor	ecx, ecx
	.p2align	4, 0x90
.LBB2_44:                               # =>This Inner Loop Header: Depth=1
	movdqu	xmmword ptr [r12 + 4*rcx], xmm0
	movdqu	xmmword ptr [r12 + 4*rcx + 16], xmm0
	add	rcx, 8
	cmp	rax, rcx
	jne	.LBB2_44
# %bb.45:
	test	rax, rax
	jne	.LBB2_48
	.p2align	4, 0x90
.LBB2_46:                               # =>This Inner Loop Header: Depth=1
	mov	dword ptr [r13], edx
	add	r13, 4
	dec	r15
	jne	.LBB2_46
.LBB2_48:
	mov	qword ptr [rbp - 40], r13
	mov	rax, qword ptr [rbp + 8]        # 8-byte Reload
	mov	eax, dword ptr [rax - 4]
	mov	r15d, eax
	and	r15d, edx
	mov	rcx, qword ptr [rbp + 16]       # 8-byte Reload
                                        # kill: def $cl killed $cl killed $rcx
	shl	r15, cl
	cmp	dword ptr [rbp + 124], 3        # 4-byte Folded Reload
	jae	.LBB2_49
.LBB2_53:
	pxor	xmm0, xmm0
	mov	rax, qword ptr [rbp + 112]      # 8-byte Reload
	movdqu	xmmword ptr [rax], xmm0
	mov	qword ptr [rax + 16], 0
	mov	dword ptr [rbp + 108], 0
	test	esi, esi
	mov	rdi, qword ptr [rbp + 16]       # 8-byte Reload
	jle	.LBB2_60
# %bb.54:
	xor	eax, eax
	lea	r14, [rbp + 108]
	jmp	.LBB2_55
	.p2align	4, 0x90
.LBB2_57:                               #   in Loop: Header=BB2_55 Depth=1
	mov	dword ptr [rdx], eax
	add	rdx, 4
	mov	qword ptr [rcx + 8], rdx
.LBB2_83:                               #   in Loop: Header=BB2_55 Depth=1
	mov	eax, dword ptr [rbp + 108]
	inc	eax
	mov	dword ptr [rbp + 108], eax
	cmp	eax, esi
	jge	.LBB2_60
.LBB2_55:                               # =>This Inner Loop Header: Depth=1
	bt	r15, rax
	jae	.LBB2_83
# %bb.56:                               #   in Loop: Header=BB2_55 Depth=1
	mov	rcx, qword ptr [rbp + 112]      # 8-byte Reload
	mov	rdx, qword ptr [rcx + 8]
	cmp	rdx, qword ptr [rcx + 16]
	jne	.LBB2_57
# %bb.82:                               #   in Loop: Header=BB2_55 Depth=1
.Ltmp30:
	mov	r8, r14
	call	"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
.Ltmp31:
	jmp	.LBB2_83
.LBB2_60:
	test	r12, r12
	je	.LBB2_69
# %bb.61:
	cmp	edi, 10
	jb	.LBB2_62
# %bb.63:
	mov	rax, qword ptr [r12 - 8]
	add	r12, -8
	sub	r12, rax
	cmp	r12, 32
	mov	rdx, qword ptr [rbp + 24]       # 8-byte Reload
	jae	.LBB2_64
# %bb.67:
	add	rdx, 39
	mov	r12, rax
	jmp	.LBB2_68
.LBB2_49:
	mov	dword ptr [rbp + 8], edx        # 4-byte Spill
	mov	ecx, r14d
	shr	eax, cl
	mov	dword ptr [rbp + 124], eax      # 4-byte Spill
	mov	rdi, qword ptr [rbp + 32]
	mov	rcx, qword ptr [rbp + 96]       # 8-byte Reload
	mov	eax, ecx
	neg	eax
	mov	dword ptr [rbp - 4], eax        # 4-byte Spill
	mov	eax, dword ptr [rbp + 92]       # 4-byte Reload
	cmp	eax, 3
	mov	r9d, 2
	cmovae	r9d, eax
	mov	r10d, 1
	movabs	r11, 4294967296
	mov	qword ptr [rbp - 24], rsi       # 8-byte Spill
	jmp	.LBB2_50
	.p2align	4, 0x90
.LBB2_52:                               #   in Loop: Header=BB2_50 Depth=1
	mov	dword ptr [r12 + 4*r10], -2147483648
.LBB2_59:                               #   in Loop: Header=BB2_50 Depth=1
	inc	r10
	inc	r11
	cmp	r9, r10
	je	.LBB2_53
.LBB2_50:                               # =>This Inner Loop Header: Depth=1
	mov	ecx, r11d
	and	ecx, r10d
	and	ecx, -2
	mov	r13d, dword ptr [r12 + 4*rcx]
	test	r13d, r13d
	js	.LBB2_52
# %bb.51:                               #   in Loop: Header=BB2_50 Depth=1
	rep		bsf	r8d, r10d
	mov	r8, qword ptr [rdi + 8*r8]
	test	r8d, ecx
	jne	.LBB2_52
# %bb.58:                               #   in Loop: Header=BB2_50 Depth=1
	mov	rsi, qword ptr [rbp - 16]       # 8-byte Reload
	mov	ecx, esi
	shr	r8, cl
	not	r8d
	mov	eax, dword ptr [rbp + 8]        # 4-byte Reload
	mov	ecx, eax
	and	ecx, r13d
	and	ecx, r8d
	and	r13d, dword ptr [rbp - 4]       # 4-byte Folded Reload
	add	r13d, dword ptr [rbp + 96]      # 4-byte Folded Reload
	or	r13d, ecx
	mov	dword ptr [r12 + 4*r10], r13d
	mov	ecx, r13d
	and	ecx, eax
	mov	r8d, dword ptr [rbx + 4*rcx]
	mov	ecx, r14d
	shr	r13d, cl
	mov	edx, r8d
	shr	edx, cl
	add	edx, r13d
	and	r8d, eax
	mov	ecx, esi
	mov	rsi, qword ptr [rbp - 24]       # 8-byte Reload
	shl	r8, cl
	or	r8, r10
	mov	eax, dword ptr [rbp + 124]      # 4-byte Reload
	cmp	edx, eax
	cmova	r15, r8
	cmova	eax, edx
	mov	dword ptr [rbp + 124], eax      # 4-byte Spill
	jmp	.LBB2_59
.LBB2_62:
	mov	rdx, qword ptr [rbp + 24]       # 8-byte Reload
.LBB2_68:
	mov	rcx, r12
	call	"??3@YAXPEAX_K@Z"
	mov	rbx, qword ptr [rbp + 64]
.LBB2_69:
	test	rbx, rbx
	je	.LBB2_77
# %bb.70:
	mov	rdx, qword ptr [rbp + 80]
	sub	rdx, rbx
	cmp	rdx, 4096
	jb	.LBB2_76
# %bb.71:
	mov	rax, qword ptr [rbx - 8]
	add	rbx, -8
	sub	rbx, rax
	cmp	rbx, 32
	jae	.LBB2_72
# %bb.75:
	add	rdx, 39
	mov	rbx, rax
.LBB2_76:
	mov	rcx, rbx
	call	"??3@YAXPEAX_K@Z"
.LBB2_77:
	mov	rsi, qword ptr [rbp + 112]      # 8-byte Reload
	mov	rcx, qword ptr [rbp + 32]
	test	rcx, rcx
	je	.LBB2_90
# %bb.78:
	mov	rdx, qword ptr [rbp + 48]
	sub	rdx, rcx
	cmp	rdx, 4096
	jb	.LBB2_89
# %bb.79:
	mov	rax, qword ptr [rcx - 8]
	add	rcx, -8
	sub	rcx, rax
	cmp	rcx, 32
	jae	.LBB2_80
# %bb.88:
	add	rdx, 39
	mov	rcx, rax
.LBB2_89:
	call	"??3@YAXPEAX_K@Z"
.LBB2_90:
	mov	rax, rsi
	add	rsp, 264
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret
.LBB2_91:
	call	"?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ"
.LBB2_80:
.Ltmp38:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp39:
# %bb.81:
.LBB2_64:
.Ltmp32:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp33:
# %bb.65:
.LBB2_72:
.Ltmp34:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp35:
# %bb.73:
	int3
	.seh_handlerdata
	.long	("$cppxdata$?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z")@IMGREL
	.section	.text,"xr",discard,"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$27@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$27@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$27@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB2_27:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	mov	rcx, qword ptr [rbp + 112]      # 8-byte Reload
	call	"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	nop
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret                                     # CLEANUPRET
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$66@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$66@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$66@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB2_66:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	call	__std_terminate
	int3
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$74@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$74@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$74@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB2_74:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	call	__std_terminate
	int3
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$84@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$84@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$84@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB2_84:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	mov	rcx, qword ptr [rbp + 112]      # 8-byte Reload
	call	"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	lea	rcx, [rbp - 48]
	call	"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	nop
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret                                     # CLEANUPRET
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$85@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$85@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$85@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB2_85:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	lea	rcx, [rbp + 64]
	call	"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	nop
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret                                     # CLEANUPRET
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$86@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$86@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$86@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB2_86:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	lea	rcx, [rbp + 32]
	call	"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
	nop
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret                                     # CLEANUPRET
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.def	"?dtor$87@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$87@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
.seh_proc "?dtor$87@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
.LBB2_87:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 128]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end1:
	.seh_handlerdata
	.section	.text,"xr",discard,"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
	.p2align	2, 0x0
"$cppxdata$?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z":
	.long	429065506                       # MagicNumber
	.long	7                               # MaxState
	.long	("$stateUnwindMap$?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	13                              # IPMapEntries
	.long	("$ip2state$?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z")@IMGREL # IPToStateXData
	.long	256                             # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z":
	.long	-1                              # ToState
	.long	"?dtor$66@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	-1                              # ToState
	.long	"?dtor$74@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	-1                              # ToState
	.long	"?dtor$86@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	2                               # ToState
	.long	"?dtor$85@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	3                               # ToState
	.long	"?dtor$84@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	2                               # ToState
	.long	"?dtor$27@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
	.long	-1                              # ToState
	.long	"?dtor$87@?0??maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"@IMGREL # Action
"$ip2state$?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z":
	.long	.Lfunc_begin1@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp20@IMGREL+1                # IP
	.long	2                               # ToState
	.long	.Ltmp36@IMGREL+1                # IP
	.long	5                               # ToState
	.long	.Ltmp22@IMGREL+1                # IP
	.long	2                               # ToState
	.long	.Ltmp23@IMGREL+1                # IP
	.long	-1                              # ToState
	.long	.Ltmp28@IMGREL+1                # IP
	.long	3                               # ToState
	.long	.Ltmp27@IMGREL+1                # IP
	.long	-1                              # ToState
	.long	.Ltmp30@IMGREL+1                # IP
	.long	4                               # ToState
	.long	.Ltmp31@IMGREL+1                # IP
	.long	-1                              # ToState
	.long	.Ltmp38@IMGREL+1                # IP
	.long	6                               # ToState
	.long	.Ltmp32@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp34@IMGREL+1                # IP
	.long	1                               # ToState
	.long	.Ltmp35@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"?maximum_independent_set_popcnt@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z"
                                        # -- End function
	.def	"??$?RAEAV<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@@<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@QEBA@AEAV0?0??12@YA?AV34@H0@Z@_K2H@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??$?RAEAV<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@@<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@QEBA@AEAV0?0??12@YA?AV34@H0@Z@_K2H@Z"
	.globl	"??$?RAEAV<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@@<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@QEBA@AEAV0?0??12@YA?AV34@H0@Z@_K2H@Z" # -- Begin function ??$?RAEAV<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@@<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@QEBA@AEAV0?0??12@YA?AV34@H0@Z@_K2H@Z
	.p2align	4, 0x90
"??$?RAEAV<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@@<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@QEBA@AEAV0?0??12@YA?AV34@H0@Z@_K2H@Z": # @"??$?RAEAV<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@@<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@QEBA@AEAV0?0??12@YA?AV34@H0@Z@_K2H@Z"
.seh_proc "??$?RAEAV<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@@<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@QEBA@AEAV0?0??12@YA?AV34@H0@Z@_K2H@Z"
# %bb.0:
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbp
	.seh_pushreg rbp
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 88
	.seh_stackalloc 88
	.seh_endprologue
	mov	rdi, r8
	mov	rbp, qword ptr [rcx]
	mov	r8d, dword ptr [rbp]
	test	r8d, r8d
	je	.LBB3_11
# %bb.1:
	mov	r12, rcx
	mov	r14d, dword ptr [rsp + 192]
	lea	ecx, [r14 + 1]
	mov	dword ptr [rsp + 68], ecx       # 4-byte Spill
	movabs	r10, 6148914691236517205
	movabs	r13, 3689348814741910323
	movabs	rsi, 1085102592571150095
	movabs	r15, 72340172838076673
	mov	qword ptr [rsp + 56], r9        # 8-byte Spill
	mov	qword ptr [rsp + 80], rdx       # 8-byte Spill
.LBB3_2:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_5 Depth 2
	dec	r8d
	mov	dword ptr [rbp], r8d
	mov	rcx, rdi
	shr	rcx
	and	rcx, r10
	mov	r10, rdi
	sub	r10, rcx
	mov	rcx, r10
	and	rcx, r13
	shr	r10, 2
	and	r10, r13
	add	r10, rcx
	mov	rcx, r10
	shr	rcx, 4
	add	rcx, r10
	and	rcx, rsi
	imul	rcx, r15
	shr	rcx, 56
	add	ecx, r14d
	mov	rbx, qword ptr [r12 + 8]
	cmp	ecx, dword ptr [rbx]
	setle	al
	jle	.LBB3_13
# %bb.3:                                #   in Loop: Header=BB3_2 Depth=1
	test	rdi, rdi
	je	.LBB3_25
# %bb.4:                                #   in Loop: Header=BB3_2 Depth=1
	mov	dword ptr [rsp + 52], eax       # 4-byte Spill
	mov	qword ptr [rsp + 72], rbx       # 8-byte Spill
	mov	r10d, -1
	mov	r11, rdi
	mov	ecx, -1
	movabs	rax, 6148914691236517205
	.p2align	4, 0x90
.LBB3_5:                                #   Parent Loop BB3_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	sub	r8d, 1
	jb	.LBB3_11
# %bb.6:                                #   in Loop: Header=BB3_5 Depth=2
	mov	dword ptr [rbp], r8d
	rep		bsf	r14, r11
	mov	rbx, qword ptr [r12 + 16]
	mov	rbx, qword ptr [rbx]
	mov	r9, qword ptr [rbx + 8*r14]
	and	r9, rdi
	mov	rbx, r9
	shr	rbx
	and	rbx, rax
	sub	r9, rbx
	mov	rbx, r9
	and	rbx, r13
	shr	r9, 2
	and	r9, r13
	add	r9, rbx
	mov	rbx, r9
	shr	rbx, 4
	add	rbx, r9
	and	rbx, rsi
	imul	rbx, r15
	shr	rbx, 56
	cmp	r10d, ebx
	cmovl	ecx, r14d
	cmovle	r10d, ebx
	lea	r9, [r11 - 1]
	and	r11, r9
	jne	.LBB3_5
# %bb.7:                                #   in Loop: Header=BB3_2 Depth=1
	cmp	r10d, 2
	jbe	.LBB3_14
# %bb.8:                                #   in Loop: Header=BB3_2 Depth=1
	mov	r14d, 1
	shl	r14, cl
	mov	r9, qword ptr [rsp + 56]        # 8-byte Reload
	bts	r9, rcx
	mov	rax, qword ptr [r12 + 16]
	movsxd	rdx, ecx
	mov	rax, qword ptr [rax]
	mov	r8, qword ptr [rax + 8*rdx]
	bts	r8, rcx
	not	r8
	and	r8, rdi
	mov	eax, dword ptr [rsp + 68]       # 4-byte Reload
	mov	dword ptr [rsp + 32], eax
	mov	rbx, qword ptr [rsp + 80]       # 8-byte Reload
	mov	rcx, rbx
	mov	rdx, rbx
	call	"??$?RAEAV<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@@<lambda_1>@?0??maximum_independent_set_impl@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@QEBA@AEAV0?0??12@YA?AV34@H0@Z@_K2H@Z"
	test	al, al
	je	.LBB3_22
# %bb.9:                                #   in Loop: Header=BB3_2 Depth=1
	not	r14
	and	rdi, r14
	mov	rbp, qword ptr [rbx]
	mov	r8d, dword ptr [rbp]
	mov	r12, rbx
	test	r8d, r8d
	mov	r14d, dword ptr [rsp + 192]
	mov	r9, qword ptr [rsp + 56]        # 8-byte Reload
	mov	eax, dword ptr [rsp + 52]       # 4-byte Reload
	movabs	r10, 6148914691236517205
	jne	.LBB3_2
	jmp	.LBB3_12
.LBB3_14:
	test	rdi, rdi
	mov	r9, qword ptr [rsp + 56]        # 8-byte Reload
	mov	r14d, dword ptr [rsp + 192]
	je	.LBB3_24
# %bb.15:
	mov	rbx, qword ptr [rsp + 72]       # 8-byte Reload
.LBB3_16:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_17 Depth 2
	dec	r8d
	mov	r11d, r8d
	mov	rcx, rdi
	.p2align	4, 0x90
.LBB3_17:                               #   Parent Loop BB3_16 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	cmp	r11d, -1
	je	.LBB3_11
# %bb.18:                               #   in Loop: Header=BB3_17 Depth=2
	mov	r8d, r11d
	mov	dword ptr [rbp], r11d
	rep		bsf	r11, rcx
	mov	rdx, qword ptr [r12 + 16]
	mov	r10, qword ptr [rdx]
	mov	rdx, qword ptr [r10 + 8*r11]
	and	rdx, rdi
	lea	rsi, [rdx - 1]
	test	rdx, rsi
	je	.LBB3_21
# %bb.19:                               #   in Loop: Header=BB3_17 Depth=2
	lea	rdx, [rcx - 1]
	lea	r11d, [r8 - 1]
	and	rcx, rdx
	jne	.LBB3_17
# %bb.20:                               #   in Loop: Header=BB3_16 Depth=1
	rep		bsf	r11, rdi
.LBB3_21:                               #   in Loop: Header=BB3_16 Depth=1
	bts	r9, r11
	mov	rcx, qword ptr [r10 + 8*r11]
	bts	rcx, r11
	not	rcx
	inc	r14d
	and	rdi, rcx
	jne	.LBB3_16
	jmp	.LBB3_25
.LBB3_11:
	xor	eax, eax
.LBB3_12:
                                        # kill: def $al killed $al killed $eax
	add	rsp, 88
	pop	rbx
	pop	rbp
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	ret
.LBB3_22:
	mov	eax, dword ptr [rsp + 52]       # 4-byte Reload
	jmp	.LBB3_12
.LBB3_24:
	mov	rbx, qword ptr [rsp + 72]       # 8-byte Reload
.LBB3_25:
	cmp	r14d, dword ptr [rbx]
	jle	.LBB3_13
# %bb.26:
	mov	dword ptr [rbx], r14d
	mov	rax, qword ptr [r12 + 24]
	mov	qword ptr [rax], r9
.LBB3_13:
	mov	al, 1
	jmp	.LBB3_12
	.seh_endproc
                                        # -- End function
	.def	"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	.globl	"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ" # -- Begin function ??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ
	.p2align	4, 0x90
"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ": # @"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
.Lfunc_begin2:
.seh_proc "??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	mov	rcx, qword ptr [rcx]
	test	rcx, rcx
	je	.LBB4_8
# %bb.1:
	mov	rdx, qword ptr [rsi + 16]
	sub	rdx, rcx
	cmp	rdx, 4096
	jb	.LBB4_7
# %bb.2:
	mov	rax, qword ptr [rcx - 8]
	add	rcx, -8
	sub	rcx, rax
	cmp	rcx, 32
	jae	.LBB4_3
# %bb.6:
	add	rdx, 39
	mov	rcx, rax
.LBB4_7:
	call	"??3@YAXPEAX_K@Z"
	xorps	xmm0, xmm0
	movups	xmmword ptr [rsi], xmm0
	mov	qword ptr [rsi + 16], 0
.LBB4_8:
	add	rsp, 40
	pop	rsi
	pop	rbp
	ret
.LBB4_3:
.Ltmp40:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp41:
# %bb.4:
	int3
	.seh_handlerdata
	.long	("$cppxdata$??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ")@IMGREL
	.section	.text,"xr",discard,"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	.seh_endproc
	.def	"?dtor$5@?0???1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$5@?0???1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ@4HA":
.seh_proc "?dtor$5@?0???1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ@4HA"
.LBB4_5:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end2:
	.seh_handlerdata
	.section	.text,"xr",discard,"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	.seh_endproc
	.section	.xdata,"dr",associative,"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
	.p2align	2, 0x0
"$cppxdata$??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ":
	.long	-1                              # ToState
	.long	"?dtor$5@?0???1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ@4HA"@IMGREL # Action
"$ip2state$??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ":
	.long	.Lfunc_begin2@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp40@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp41@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??1?$vector@HV?$allocator@H@std@@@std@@QEAA@XZ"
                                        # -- End function
	.def	"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	.globl	"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ" # -- Begin function ??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ
	.p2align	4, 0x90
"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ": # @"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
.Lfunc_begin3:
.seh_proc "??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	mov	rcx, qword ptr [rcx]
	test	rcx, rcx
	je	.LBB5_8
# %bb.1:
	mov	rdx, qword ptr [rsi + 16]
	sub	rdx, rcx
	cmp	rdx, 4096
	jb	.LBB5_7
# %bb.2:
	mov	rax, qword ptr [rcx - 8]
	add	rcx, -8
	sub	rcx, rax
	cmp	rcx, 32
	jae	.LBB5_3
# %bb.6:
	add	rdx, 39
	mov	rcx, rax
.LBB5_7:
	call	"??3@YAXPEAX_K@Z"
	xorps	xmm0, xmm0
	movups	xmmword ptr [rsi], xmm0
	mov	qword ptr [rsi + 16], 0
.LBB5_8:
	add	rsp, 40
	pop	rsi
	pop	rbp
	ret
.LBB5_3:
.Ltmp42:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp43:
# %bb.4:
	int3
	.seh_handlerdata
	.long	("$cppxdata$??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ")@IMGREL
	.section	.text,"xr",discard,"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	.seh_endproc
	.def	"?dtor$5@?0???1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$5@?0???1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ@4HA":
.seh_proc "?dtor$5@?0???1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ@4HA"
.LBB5_5:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end3:
	.seh_handlerdata
	.section	.text,"xr",discard,"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	.seh_endproc
	.section	.xdata,"dr",associative,"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
	.p2align	2, 0x0
"$cppxdata$??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ":
	.long	-1                              # ToState
	.long	"?dtor$5@?0???1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ@4HA"@IMGREL # Action
"$ip2state$??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ":
	.long	.Lfunc_begin3@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp42@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp43@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??1?$vector@IV?$allocator@I@std@@@std@@QEAA@XZ"
                                        # -- End function
	.def	"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
	.globl	"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ" # -- Begin function ??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ
	.p2align	4, 0x90
"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ": # @"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
.Lfunc_begin4:
.seh_proc "??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	mov	rcx, qword ptr [rcx]
	test	rcx, rcx
	je	.LBB6_8
# %bb.1:
	mov	rdx, qword ptr [rsi + 16]
	sub	rdx, rcx
	cmp	rdx, 4096
	jb	.LBB6_7
# %bb.2:
	mov	rax, qword ptr [rcx - 8]
	add	rcx, -8
	sub	rcx, rax
	cmp	rcx, 32
	jae	.LBB6_3
# %bb.6:
	add	rdx, 39
	mov	rcx, rax
.LBB6_7:
	call	"??3@YAXPEAX_K@Z"
	xorps	xmm0, xmm0
	movups	xmmword ptr [rsi], xmm0
	mov	qword ptr [rsi + 16], 0
.LBB6_8:
	add	rsp, 40
	pop	rsi
	pop	rbp
	ret
.LBB6_3:
.Ltmp44:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp45:
# %bb.4:
	int3
	.seh_handlerdata
	.long	("$cppxdata$??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ")@IMGREL
	.section	.text,"xr",discard,"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
	.seh_endproc
	.def	"?dtor$5@?0???1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$5@?0???1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ@4HA":
.seh_proc "?dtor$5@?0???1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ@4HA"
.LBB6_5:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end4:
	.seh_handlerdata
	.section	.text,"xr",discard,"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
	.seh_endproc
	.section	.xdata,"dr",associative,"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
	.p2align	2, 0x0
"$cppxdata$??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ":
	.long	-1                              # ToState
	.long	"?dtor$5@?0???1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ@4HA"@IMGREL # Action
"$ip2state$??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ":
	.long	.Lfunc_begin4@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp44@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp45@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??1?$vector@_KV?$allocator@_K@std@@@std@@QEAA@XZ"
                                        # -- End function
	.def	"?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ"
	.globl	"?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ" # -- Begin function ?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ
	.p2align	4, 0x90
"?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ": # @"?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ"
.seh_proc "?_Xlength@?$vector@_KV?$allocator@_K@std@@@std@@CAXXZ"
# %bb.0:
	sub	rsp, 40
	.seh_stackalloc 40
	.seh_endprologue
	lea	rcx, [rip + "??_C@_0BA@FOIKENOD@vector?5too?5long?$AA@"]
	call	"?_Xlength_error@std@@YAXPEBD@Z"
	int3
	.seh_endproc
                                        # -- End function
	.def	"?_Throw_bad_array_new_length@std@@YAXXZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"?_Throw_bad_array_new_length@std@@YAXXZ"
	.globl	"?_Throw_bad_array_new_length@std@@YAXXZ" # -- Begin function ?_Throw_bad_array_new_length@std@@YAXXZ
	.p2align	4, 0x90
"?_Throw_bad_array_new_length@std@@YAXXZ": # @"?_Throw_bad_array_new_length@std@@YAXXZ"
.seh_proc "?_Throw_bad_array_new_length@std@@YAXXZ"
# %bb.0:
	sub	rsp, 56
	.seh_stackalloc 56
	.seh_endprologue
	mov	qword ptr [rsp + 48], 0
	lea	rax, [rip + "??_C@_0BF@KINCDENJ@bad?5array?5new?5length?$AA@"]
	mov	qword ptr [rsp + 40], rax
	lea	rax, [rip + "??_7bad_array_new_length@std@@6B@"]
	mov	qword ptr [rsp + 32], rax
	lea	rdx, [rip + "_TI3?AVbad_array_new_length@std@@"]
	lea	rcx, [rsp + 32]
	call	_CxxThrowException
	int3
	.seh_endproc
                                        # -- End function
	.def	"??0bad_array_new_length@std@@QEAA@AEBV01@@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
	.globl	"??0bad_array_new_length@std@@QEAA@AEBV01@@Z" # -- Begin function ??0bad_array_new_length@std@@QEAA@AEBV01@@Z
	.p2align	4, 0x90
"??0bad_array_new_length@std@@QEAA@AEBV01@@Z": # @"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
.Lfunc_begin5:
.seh_proc "??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	lea	rax, [rcx + 8]
	xorps	xmm0, xmm0
	movups	xmmword ptr [rcx + 8], xmm0
	lea	rcx, [rdx + 8]
.Ltmp46:
	mov	rdx, rax
	call	__std_exception_copy
.Ltmp47:
# %bb.1:
	lea	rax, [rip + "??_7bad_array_new_length@std@@6B@"]
	mov	qword ptr [rsi], rax
	mov	rax, rsi
	add	rsp, 40
	pop	rsi
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??0bad_array_new_length@std@@QEAA@AEBV01@@Z")@IMGREL
	.section	.text,"xr",discard,"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
	.seh_endproc
	.def	"?dtor$2@?0???0bad_array_new_length@std@@QEAA@AEBV01@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$2@?0???0bad_array_new_length@std@@QEAA@AEBV01@@Z@4HA":
.seh_proc "?dtor$2@?0???0bad_array_new_length@std@@QEAA@AEBV01@@Z@4HA"
.LBB9_2:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end5:
	.seh_handlerdata
	.section	.text,"xr",discard,"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
	.p2align	2, 0x0
"$cppxdata$??0bad_array_new_length@std@@QEAA@AEBV01@@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??0bad_array_new_length@std@@QEAA@AEBV01@@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??0bad_array_new_length@std@@QEAA@AEBV01@@Z")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??0bad_array_new_length@std@@QEAA@AEBV01@@Z":
	.long	-1                              # ToState
	.long	"?dtor$2@?0???0bad_array_new_length@std@@QEAA@AEBV01@@Z@4HA"@IMGREL # Action
"$ip2state$??0bad_array_new_length@std@@QEAA@AEBV01@@Z":
	.long	.Lfunc_begin5@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp46@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp47@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"
                                        # -- End function
	.def	"??0bad_alloc@std@@QEAA@AEBV01@@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??0bad_alloc@std@@QEAA@AEBV01@@Z"
	.globl	"??0bad_alloc@std@@QEAA@AEBV01@@Z" # -- Begin function ??0bad_alloc@std@@QEAA@AEBV01@@Z
	.p2align	4, 0x90
"??0bad_alloc@std@@QEAA@AEBV01@@Z":     # @"??0bad_alloc@std@@QEAA@AEBV01@@Z"
.Lfunc_begin6:
.seh_proc "??0bad_alloc@std@@QEAA@AEBV01@@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	lea	rax, [rcx + 8]
	xorps	xmm0, xmm0
	movups	xmmword ptr [rcx + 8], xmm0
	lea	rcx, [rdx + 8]
.Ltmp48:
	mov	rdx, rax
	call	__std_exception_copy
.Ltmp49:
# %bb.1:
	lea	rax, [rip + "??_7bad_alloc@std@@6B@"]
	mov	qword ptr [rsi], rax
	mov	rax, rsi
	add	rsp, 40
	pop	rsi
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??0bad_alloc@std@@QEAA@AEBV01@@Z")@IMGREL
	.section	.text,"xr",discard,"??0bad_alloc@std@@QEAA@AEBV01@@Z"
	.seh_endproc
	.def	"?dtor$2@?0???0bad_alloc@std@@QEAA@AEBV01@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$2@?0???0bad_alloc@std@@QEAA@AEBV01@@Z@4HA":
.seh_proc "?dtor$2@?0???0bad_alloc@std@@QEAA@AEBV01@@Z@4HA"
.LBB10_2:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end6:
	.seh_handlerdata
	.section	.text,"xr",discard,"??0bad_alloc@std@@QEAA@AEBV01@@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??0bad_alloc@std@@QEAA@AEBV01@@Z"
	.p2align	2, 0x0
"$cppxdata$??0bad_alloc@std@@QEAA@AEBV01@@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??0bad_alloc@std@@QEAA@AEBV01@@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??0bad_alloc@std@@QEAA@AEBV01@@Z")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??0bad_alloc@std@@QEAA@AEBV01@@Z":
	.long	-1                              # ToState
	.long	"?dtor$2@?0???0bad_alloc@std@@QEAA@AEBV01@@Z@4HA"@IMGREL # Action
"$ip2state$??0bad_alloc@std@@QEAA@AEBV01@@Z":
	.long	.Lfunc_begin6@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp48@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp49@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??0bad_alloc@std@@QEAA@AEBV01@@Z"
                                        # -- End function
	.def	"??0exception@std@@QEAA@AEBV01@@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??0exception@std@@QEAA@AEBV01@@Z"
	.globl	"??0exception@std@@QEAA@AEBV01@@Z" # -- Begin function ??0exception@std@@QEAA@AEBV01@@Z
	.p2align	4, 0x90
"??0exception@std@@QEAA@AEBV01@@Z":     # @"??0exception@std@@QEAA@AEBV01@@Z"
.Lfunc_begin7:
.seh_proc "??0exception@std@@QEAA@AEBV01@@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	lea	rax, [rcx + 8]
	xorps	xmm0, xmm0
	movups	xmmword ptr [rcx + 8], xmm0
	lea	rcx, [rdx + 8]
.Ltmp50:
	mov	rdx, rax
	call	__std_exception_copy
.Ltmp51:
# %bb.1:
	mov	rax, rsi
	add	rsp, 40
	pop	rsi
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??0exception@std@@QEAA@AEBV01@@Z")@IMGREL
	.section	.text,"xr",discard,"??0exception@std@@QEAA@AEBV01@@Z"
	.seh_endproc
	.def	"?dtor$2@?0???0exception@std@@QEAA@AEBV01@@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$2@?0???0exception@std@@QEAA@AEBV01@@Z@4HA":
.seh_proc "?dtor$2@?0???0exception@std@@QEAA@AEBV01@@Z@4HA"
.LBB11_2:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end7:
	.seh_handlerdata
	.section	.text,"xr",discard,"??0exception@std@@QEAA@AEBV01@@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??0exception@std@@QEAA@AEBV01@@Z"
	.p2align	2, 0x0
"$cppxdata$??0exception@std@@QEAA@AEBV01@@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??0exception@std@@QEAA@AEBV01@@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??0exception@std@@QEAA@AEBV01@@Z")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??0exception@std@@QEAA@AEBV01@@Z":
	.long	-1                              # ToState
	.long	"?dtor$2@?0???0exception@std@@QEAA@AEBV01@@Z@4HA"@IMGREL # Action
"$ip2state$??0exception@std@@QEAA@AEBV01@@Z":
	.long	.Lfunc_begin7@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp50@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp51@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??0exception@std@@QEAA@AEBV01@@Z"
                                        # -- End function
	.def	"??1exception@std@@UEAA@XZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??1exception@std@@UEAA@XZ"
	.globl	"??1exception@std@@UEAA@XZ"     # -- Begin function ??1exception@std@@UEAA@XZ
	.p2align	4, 0x90
"??1exception@std@@UEAA@XZ":            # @"??1exception@std@@UEAA@XZ"
.Lfunc_begin8:
.seh_proc "??1exception@std@@UEAA@XZ"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	sub	rsp, 48
	.seh_stackalloc 48
	lea	rbp, [rsp + 48]
	.seh_setframe rbp, 48
	.seh_endprologue
	mov	qword ptr [rbp - 8], -2
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	add	rcx, 8
.Ltmp52:
	call	__std_exception_destroy
.Ltmp53:
# %bb.1:
	nop
	add	rsp, 48
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??1exception@std@@UEAA@XZ")@IMGREL
	.section	.text,"xr",discard,"??1exception@std@@UEAA@XZ"
	.seh_endproc
	.def	"?dtor$2@?0???1exception@std@@UEAA@XZ@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$2@?0???1exception@std@@UEAA@XZ@4HA":
.seh_proc "?dtor$2@?0???1exception@std@@UEAA@XZ@4HA"
.LBB12_2:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	sub	rsp, 32
	.seh_stackalloc 32
	lea	rbp, [rdx + 48]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end8:
	.seh_handlerdata
	.section	.text,"xr",discard,"??1exception@std@@UEAA@XZ"
	.seh_endproc
	.section	.xdata,"dr",associative,"??1exception@std@@UEAA@XZ"
	.p2align	2, 0x0
"$cppxdata$??1exception@std@@UEAA@XZ":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??1exception@std@@UEAA@XZ")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??1exception@std@@UEAA@XZ")@IMGREL # IPToStateXData
	.long	40                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??1exception@std@@UEAA@XZ":
	.long	-1                              # ToState
	.long	"?dtor$2@?0???1exception@std@@UEAA@XZ@4HA"@IMGREL # Action
"$ip2state$??1exception@std@@UEAA@XZ":
	.long	.Lfunc_begin8@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp52@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp53@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??1exception@std@@UEAA@XZ"
                                        # -- End function
	.def	"??_Gbad_array_new_length@std@@UEAAPEAXI@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
	.globl	"??_Gbad_array_new_length@std@@UEAAPEAXI@Z" # -- Begin function ??_Gbad_array_new_length@std@@UEAAPEAXI@Z
	.p2align	4, 0x90
"??_Gbad_array_new_length@std@@UEAAPEAXI@Z": # @"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
.Lfunc_begin9:
.seh_proc "??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	sub	rsp, 48
	.seh_stackalloc 48
	lea	rbp, [rsp + 48]
	.seh_setframe rbp, 48
	.seh_endprologue
	mov	qword ptr [rbp - 8], -2
	mov	edi, edx
	mov	rsi, rcx
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	add	rcx, 8
.Ltmp54:
	call	__std_exception_destroy
.Ltmp55:
# %bb.1:
	test	edi, edi
	je	.LBB13_3
# %bb.2:
	mov	rcx, rsi
	call	"??3@YAXPEAX@Z"
.LBB13_3:
	mov	rax, rsi
	add	rsp, 48
	pop	rdi
	pop	rsi
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??_Gbad_array_new_length@std@@UEAAPEAXI@Z")@IMGREL
	.section	.text,"xr",discard,"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
	.seh_endproc
	.def	"?dtor$4@?0???_Gbad_array_new_length@std@@UEAAPEAXI@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$4@?0???_Gbad_array_new_length@std@@UEAAPEAXI@Z@4HA":
.seh_proc "?dtor$4@?0???_Gbad_array_new_length@std@@UEAAPEAXI@Z@4HA"
.LBB13_4:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	sub	rsp, 32
	.seh_stackalloc 32
	lea	rbp, [rdx + 48]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end9:
	.seh_handlerdata
	.section	.text,"xr",discard,"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
	.p2align	2, 0x0
"$cppxdata$??_Gbad_array_new_length@std@@UEAAPEAXI@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??_Gbad_array_new_length@std@@UEAAPEAXI@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??_Gbad_array_new_length@std@@UEAAPEAXI@Z")@IMGREL # IPToStateXData
	.long	40                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??_Gbad_array_new_length@std@@UEAAPEAXI@Z":
	.long	-1                              # ToState
	.long	"?dtor$4@?0???_Gbad_array_new_length@std@@UEAAPEAXI@Z@4HA"@IMGREL # Action
"$ip2state$??_Gbad_array_new_length@std@@UEAAPEAXI@Z":
	.long	.Lfunc_begin9@IMGREL            # IP
	.long	-1                              # ToState
	.long	.Ltmp54@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp55@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
                                        # -- End function
	.def	"?what@exception@std@@UEBAPEBDXZ";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"?what@exception@std@@UEBAPEBDXZ"
	.globl	"?what@exception@std@@UEBAPEBDXZ" # -- Begin function ?what@exception@std@@UEBAPEBDXZ
	.p2align	4, 0x90
"?what@exception@std@@UEBAPEBDXZ":      # @"?what@exception@std@@UEBAPEBDXZ"
# %bb.0:
	mov	rcx, qword ptr [rcx + 8]
	test	rcx, rcx
	lea	rax, [rip + "??_C@_0BC@EOODALEL@Unknown?5exception?$AA@"]
	cmovne	rax, rcx
	ret
                                        # -- End function
	.def	"??_Gbad_alloc@std@@UEAAPEAXI@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??_Gbad_alloc@std@@UEAAPEAXI@Z"
	.globl	"??_Gbad_alloc@std@@UEAAPEAXI@Z" # -- Begin function ??_Gbad_alloc@std@@UEAAPEAXI@Z
	.p2align	4, 0x90
"??_Gbad_alloc@std@@UEAAPEAXI@Z":       # @"??_Gbad_alloc@std@@UEAAPEAXI@Z"
.Lfunc_begin10:
.seh_proc "??_Gbad_alloc@std@@UEAAPEAXI@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	sub	rsp, 48
	.seh_stackalloc 48
	lea	rbp, [rsp + 48]
	.seh_setframe rbp, 48
	.seh_endprologue
	mov	qword ptr [rbp - 8], -2
	mov	edi, edx
	mov	rsi, rcx
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	add	rcx, 8
.Ltmp56:
	call	__std_exception_destroy
.Ltmp57:
# %bb.1:
	test	edi, edi
	je	.LBB15_3
# %bb.2:
	mov	rcx, rsi
	call	"??3@YAXPEAX@Z"
.LBB15_3:
	mov	rax, rsi
	add	rsp, 48
	pop	rdi
	pop	rsi
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??_Gbad_alloc@std@@UEAAPEAXI@Z")@IMGREL
	.section	.text,"xr",discard,"??_Gbad_alloc@std@@UEAAPEAXI@Z"
	.seh_endproc
	.def	"?dtor$4@?0???_Gbad_alloc@std@@UEAAPEAXI@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$4@?0???_Gbad_alloc@std@@UEAAPEAXI@Z@4HA":
.seh_proc "?dtor$4@?0???_Gbad_alloc@std@@UEAAPEAXI@Z@4HA"
.LBB15_4:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	sub	rsp, 32
	.seh_stackalloc 32
	lea	rbp, [rdx + 48]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end10:
	.seh_handlerdata
	.section	.text,"xr",discard,"??_Gbad_alloc@std@@UEAAPEAXI@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??_Gbad_alloc@std@@UEAAPEAXI@Z"
	.p2align	2, 0x0
"$cppxdata$??_Gbad_alloc@std@@UEAAPEAXI@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??_Gbad_alloc@std@@UEAAPEAXI@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??_Gbad_alloc@std@@UEAAPEAXI@Z")@IMGREL # IPToStateXData
	.long	40                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??_Gbad_alloc@std@@UEAAPEAXI@Z":
	.long	-1                              # ToState
	.long	"?dtor$4@?0???_Gbad_alloc@std@@UEAAPEAXI@Z@4HA"@IMGREL # Action
"$ip2state$??_Gbad_alloc@std@@UEAAPEAXI@Z":
	.long	.Lfunc_begin10@IMGREL           # IP
	.long	-1                              # ToState
	.long	.Ltmp56@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp57@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??_Gbad_alloc@std@@UEAAPEAXI@Z"
                                        # -- End function
	.def	"??_Gexception@std@@UEAAPEAXI@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??_Gexception@std@@UEAAPEAXI@Z"
	.globl	"??_Gexception@std@@UEAAPEAXI@Z" # -- Begin function ??_Gexception@std@@UEAAPEAXI@Z
	.p2align	4, 0x90
"??_Gexception@std@@UEAAPEAXI@Z":       # @"??_Gexception@std@@UEAAPEAXI@Z"
.Lfunc_begin11:
.seh_proc "??_Gexception@std@@UEAAPEAXI@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	sub	rsp, 48
	.seh_stackalloc 48
	lea	rbp, [rsp + 48]
	.seh_setframe rbp, 48
	.seh_endprologue
	mov	qword ptr [rbp - 8], -2
	mov	edi, edx
	mov	rsi, rcx
	lea	rax, [rip + "??_7exception@std@@6B@"]
	mov	qword ptr [rcx], rax
	add	rcx, 8
.Ltmp58:
	call	__std_exception_destroy
.Ltmp59:
# %bb.1:
	test	edi, edi
	je	.LBB16_3
# %bb.2:
	mov	rcx, rsi
	call	"??3@YAXPEAX@Z"
.LBB16_3:
	mov	rax, rsi
	add	rsp, 48
	pop	rdi
	pop	rsi
	pop	rbp
	ret
	.seh_handlerdata
	.long	("$cppxdata$??_Gexception@std@@UEAAPEAXI@Z")@IMGREL
	.section	.text,"xr",discard,"??_Gexception@std@@UEAAPEAXI@Z"
	.seh_endproc
	.def	"?dtor$4@?0???_Gexception@std@@UEAAPEAXI@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$4@?0???_Gexception@std@@UEAAPEAXI@Z@4HA":
.seh_proc "?dtor$4@?0???_Gexception@std@@UEAAPEAXI@Z@4HA"
.LBB16_4:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	sub	rsp, 32
	.seh_stackalloc 32
	lea	rbp, [rdx + 48]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end11:
	.seh_handlerdata
	.section	.text,"xr",discard,"??_Gexception@std@@UEAAPEAXI@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??_Gexception@std@@UEAAPEAXI@Z"
	.p2align	2, 0x0
"$cppxdata$??_Gexception@std@@UEAAPEAXI@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??_Gexception@std@@UEAAPEAXI@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??_Gexception@std@@UEAAPEAXI@Z")@IMGREL # IPToStateXData
	.long	40                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??_Gexception@std@@UEAAPEAXI@Z":
	.long	-1                              # ToState
	.long	"?dtor$4@?0???_Gexception@std@@UEAAPEAXI@Z@4HA"@IMGREL # Action
"$ip2state$??_Gexception@std@@UEAAPEAXI@Z":
	.long	.Lfunc_begin11@IMGREL           # IP
	.long	-1                              # ToState
	.long	.Ltmp58@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp59@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??_Gexception@std@@UEAAPEAXI@Z"
                                        # -- End function
	.def	"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
	.globl	"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z" # -- Begin function ??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z
	.p2align	4, 0x90
"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z": # @"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
.Lfunc_begin12:
.seh_proc "??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
	.seh_handler __CxxFrameHandler3, @unwind, @except
# %bb.0:
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rsp + 32]
	.seh_setframe rbp, 32
	.seh_endprologue
	mov	qword ptr [rbp], -2
	mov	rsi, rcx
	mov	rbx, qword ptr [rcx]
	mov	r12, qword ptr [rcx + 8]
	sub	r12, rbx
	sar	r12, 2
	inc	r12
	mov	rax, qword ptr [rcx + 16]
	sub	rax, rbx
	sar	rax, 2
	mov	r13, rax
	shr	r13
	movabs	rcx, 4611686018427387903
	mov	r9, rcx
	sub	r9, r13
	add	r13, rax
	cmp	r13, r12
	cmovbe	r13, r12
	cmp	rax, r9
	cmova	r13, rcx
	mov	rax, r13
	shr	rax, 62
	jne	.LBB17_19
# %bb.1:
	mov	r15, r8
	mov	r14, rdx
	test	r13, r13
	je	.LBB17_2
# %bb.3:
	lea	rcx, [4*r13]
	cmp	r13, 1024
	jb	.LBB17_6
# %bb.4:
	movabs	rax, 4611686018427387895
	cmp	r13, rax
	jae	.LBB17_19
# %bb.5:
	add	rcx, 39
	call	"??2@YAPEAX_K@Z"
	lea	rdi, [rax + 39]
	and	rdi, -32
	mov	qword ptr [rdi - 8], rax
	jmp	.LBB17_7
.LBB17_2:
	xor	edi, edi
	jmp	.LBB17_7
.LBB17_6:
	call	"??2@YAPEAX_K@Z"
	mov	rdi, rax
.LBB17_7:
	mov	rax, r14
	sub	rax, rbx
	lea	rbx, [rdi + rax]
	mov	ecx, dword ptr [r15]
	mov	dword ptr [rdi + rax], ecx
	cmp	qword ptr [rsi + 8], r14
	je	.LBB17_8
# %bb.9:
	lea	r15, [rbx + 4]
	mov	rdx, qword ptr [rsi]
	mov	r8, r14
	sub	r8, rdx
	mov	rcx, rdi
	call	memmove
	mov	r8, qword ptr [rsi + 8]
	sub	r8, r14
	mov	rcx, r15
	mov	rdx, r14
	jmp	.LBB17_10
.LBB17_8:
	mov	rdx, qword ptr [rsi]
	sub	r14, rdx
	mov	rcx, rdi
	mov	r8, r14
.LBB17_10:
	call	memmove
	mov	rcx, qword ptr [rsi]
	test	rcx, rcx
	je	.LBB17_18
# %bb.11:
	mov	rdx, qword ptr [rsi + 16]
	sub	rdx, rcx
	cmp	rdx, 4096
	jb	.LBB17_17
# %bb.12:
	mov	rax, qword ptr [rcx - 8]
	add	rcx, -8
	sub	rcx, rax
	cmp	rcx, 32
	jae	.LBB17_13
# %bb.16:
	add	rdx, 39
	mov	rcx, rax
.LBB17_17:
	call	"??3@YAXPEAX_K@Z"
.LBB17_18:
	mov	qword ptr [rsi], rdi
	lea	rax, [rdi + 4*r12]
	mov	qword ptr [rsi + 8], rax
	lea	rax, [rdi + 4*r13]
	mov	qword ptr [rsi + 16], rax
	mov	rax, rbx
	add	rsp, 40
	pop	rbx
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret
.LBB17_19:
	call	"?_Throw_bad_array_new_length@std@@YAXXZ"
.LBB17_13:
.Ltmp60:
	call	_invalid_parameter_noinfo_noreturn
.Ltmp61:
# %bb.14:
	int3
	.seh_handlerdata
	.long	("$cppxdata$??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z")@IMGREL
	.section	.text,"xr",discard,"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
	.seh_endproc
	.def	"?dtor$15@?0???$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4, 0x90
"?dtor$15@?0???$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z@4HA":
.seh_proc "?dtor$15@?0???$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z@4HA"
.LBB17_15:
	mov	qword ptr [rsp + 16], rdx
	push	rbp
	.seh_pushreg rbp
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	lea	rbp, [rdx + 32]
	.seh_endprologue
	call	__std_terminate
	int3
.Lfunc_end12:
	.seh_handlerdata
	.section	.text,"xr",discard,"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
	.seh_endproc
	.section	.xdata,"dr",associative,"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
	.p2align	2, 0x0
"$cppxdata$??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z":
	.long	429065506                       # MagicNumber
	.long	1                               # MaxState
	.long	("$stateUnwindMap$??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z")@IMGREL # UnwindMap
	.long	0                               # NumTryBlocks
	.long	0                               # TryBlockMap
	.long	3                               # IPMapEntries
	.long	("$ip2state$??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z")@IMGREL # IPToStateXData
	.long	32                              # UnwindHelp
	.long	0                               # ESTypeList
	.long	1                               # EHFlags
"$stateUnwindMap$??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z":
	.long	-1                              # ToState
	.long	"?dtor$15@?0???$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z@4HA"@IMGREL # Action
"$ip2state$??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z":
	.long	.Lfunc_begin12@IMGREL           # IP
	.long	-1                              # ToState
	.long	.Ltmp60@IMGREL+1                # IP
	.long	0                               # ToState
	.long	.Ltmp61@IMGREL+1                # IP
	.long	-1                              # ToState
	.section	.text,"xr",discard,"??$_Emplace_reallocate@AEBH@?$vector@HV?$allocator@H@std@@@std@@AEAAPEAHQEAHAEBH@Z"
                                        # -- End function
	.section	.bss,"bw",discard,"?has_popcnt@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@4_NB"
	.globl	"?has_popcnt@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@4_NB" # @"?has_popcnt@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@4_NB"
"?has_popcnt@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@4_NB":
	.byte	0                               # 0x0

	.section	.bss,"bw",discard,"?$TSS0@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
	.globl	"?$TSS0@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA" # @"?$TSS0@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
	.p2align	2, 0x0
"?$TSS0@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA":
	.long	0                               # 0x0

	.section	.rdata,"dr",discard,"??_C@_0BA@FOIKENOD@vector?5too?5long?$AA@"
	.globl	"??_C@_0BA@FOIKENOD@vector?5too?5long?$AA@" # @"??_C@_0BA@FOIKENOD@vector?5too?5long?$AA@"
"??_C@_0BA@FOIKENOD@vector?5too?5long?$AA@":
	.asciz	"vector too long"

	.section	.data,"dw",discard,"??_R0?AVbad_array_new_length@std@@@8"
	.globl	"??_R0?AVbad_array_new_length@std@@@8" # @"??_R0?AVbad_array_new_length@std@@@8"
	.p2align	4, 0x0
"??_R0?AVbad_array_new_length@std@@@8":
	.quad	"??_7type_info@@6B@"
	.quad	0
	.asciz	".?AVbad_array_new_length@std@@"
	.zero	1

	.section	.xdata,"dr",discard,"_CT??_R0?AVbad_array_new_length@std@@@8??0bad_array_new_length@std@@QEAA@AEBV01@@Z24"
	.globl	"_CT??_R0?AVbad_array_new_length@std@@@8??0bad_array_new_length@std@@QEAA@AEBV01@@Z24" # @"_CT??_R0?AVbad_array_new_length@std@@@8??0bad_array_new_length@std@@QEAA@AEBV01@@Z24"
	.p2align	4, 0x0
"_CT??_R0?AVbad_array_new_length@std@@@8??0bad_array_new_length@std@@QEAA@AEBV01@@Z24":
	.long	0                               # 0x0
	.long	"??_R0?AVbad_array_new_length@std@@@8"@IMGREL
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	24                              # 0x18
	.long	"??0bad_array_new_length@std@@QEAA@AEBV01@@Z"@IMGREL

	.section	.data,"dw",discard,"??_R0?AVbad_alloc@std@@@8"
	.globl	"??_R0?AVbad_alloc@std@@@8"     # @"??_R0?AVbad_alloc@std@@@8"
	.p2align	4, 0x0
"??_R0?AVbad_alloc@std@@@8":
	.quad	"??_7type_info@@6B@"
	.quad	0
	.asciz	".?AVbad_alloc@std@@"
	.zero	4

	.section	.xdata,"dr",discard,"_CT??_R0?AVbad_alloc@std@@@8??0bad_alloc@std@@QEAA@AEBV01@@Z24"
	.globl	"_CT??_R0?AVbad_alloc@std@@@8??0bad_alloc@std@@QEAA@AEBV01@@Z24" # @"_CT??_R0?AVbad_alloc@std@@@8??0bad_alloc@std@@QEAA@AEBV01@@Z24"
	.p2align	4, 0x0
"_CT??_R0?AVbad_alloc@std@@@8??0bad_alloc@std@@QEAA@AEBV01@@Z24":
	.long	16                              # 0x10
	.long	"??_R0?AVbad_alloc@std@@@8"@IMGREL
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	24                              # 0x18
	.long	"??0bad_alloc@std@@QEAA@AEBV01@@Z"@IMGREL

	.section	.data,"dw",discard,"??_R0?AVexception@std@@@8"
	.globl	"??_R0?AVexception@std@@@8"     # @"??_R0?AVexception@std@@@8"
	.p2align	4, 0x0
"??_R0?AVexception@std@@@8":
	.quad	"??_7type_info@@6B@"
	.quad	0
	.asciz	".?AVexception@std@@"
	.zero	4

	.section	.xdata,"dr",discard,"_CT??_R0?AVexception@std@@@8??0exception@std@@QEAA@AEBV01@@Z24"
	.globl	"_CT??_R0?AVexception@std@@@8??0exception@std@@QEAA@AEBV01@@Z24" # @"_CT??_R0?AVexception@std@@@8??0exception@std@@QEAA@AEBV01@@Z24"
	.p2align	4, 0x0
"_CT??_R0?AVexception@std@@@8??0exception@std@@QEAA@AEBV01@@Z24":
	.long	0                               # 0x0
	.long	"??_R0?AVexception@std@@@8"@IMGREL
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	24                              # 0x18
	.long	"??0exception@std@@QEAA@AEBV01@@Z"@IMGREL

	.section	.xdata,"dr",discard,"_CTA3?AVbad_array_new_length@std@@"
	.globl	"_CTA3?AVbad_array_new_length@std@@" # @"_CTA3?AVbad_array_new_length@std@@"
	.p2align	3, 0x0
"_CTA3?AVbad_array_new_length@std@@":
	.long	3                               # 0x3
	.long	"_CT??_R0?AVbad_array_new_length@std@@@8??0bad_array_new_length@std@@QEAA@AEBV01@@Z24"@IMGREL
	.long	"_CT??_R0?AVbad_alloc@std@@@8??0bad_alloc@std@@QEAA@AEBV01@@Z24"@IMGREL
	.long	"_CT??_R0?AVexception@std@@@8??0exception@std@@QEAA@AEBV01@@Z24"@IMGREL

	.section	.xdata,"dr",discard,"_TI3?AVbad_array_new_length@std@@"
	.globl	"_TI3?AVbad_array_new_length@std@@" # @"_TI3?AVbad_array_new_length@std@@"
	.p2align	3, 0x0
"_TI3?AVbad_array_new_length@std@@":
	.long	0                               # 0x0
	.long	"??1exception@std@@UEAA@XZ"@IMGREL
	.long	0                               # 0x0
	.long	"_CTA3?AVbad_array_new_length@std@@"@IMGREL

	.section	.rdata,"dr",discard,"??_C@_0BF@KINCDENJ@bad?5array?5new?5length?$AA@"
	.globl	"??_C@_0BF@KINCDENJ@bad?5array?5new?5length?$AA@" # @"??_C@_0BF@KINCDENJ@bad?5array?5new?5length?$AA@"
"??_C@_0BF@KINCDENJ@bad?5array?5new?5length?$AA@":
	.asciz	"bad array new length"

	.section	.rdata,"dr",largest,"??_7bad_array_new_length@std@@6B@"
	.p2align	4, 0x0                          # @0
.L__unnamed_1:
	.quad	"??_R4bad_array_new_length@std@@6B@"
	.quad	"??_Gbad_array_new_length@std@@UEAAPEAXI@Z"
	.quad	"?what@exception@std@@UEBAPEBDXZ"

	.section	.rdata,"dr",discard,"??_R4bad_array_new_length@std@@6B@"
	.globl	"??_R4bad_array_new_length@std@@6B@" # @"??_R4bad_array_new_length@std@@6B@"
	.p2align	4, 0x0
"??_R4bad_array_new_length@std@@6B@":
	.long	1                               # 0x1
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	"??_R0?AVbad_array_new_length@std@@@8"@IMGREL
	.long	"??_R3bad_array_new_length@std@@8"@IMGREL
	.long	"??_R4bad_array_new_length@std@@6B@"@IMGREL

	.section	.rdata,"dr",discard,"??_R3bad_array_new_length@std@@8"
	.globl	"??_R3bad_array_new_length@std@@8" # @"??_R3bad_array_new_length@std@@8"
	.p2align	3, 0x0
"??_R3bad_array_new_length@std@@8":
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	3                               # 0x3
	.long	"??_R2bad_array_new_length@std@@8"@IMGREL

	.section	.rdata,"dr",discard,"??_R2bad_array_new_length@std@@8"
	.globl	"??_R2bad_array_new_length@std@@8" # @"??_R2bad_array_new_length@std@@8"
	.p2align	2, 0x0
"??_R2bad_array_new_length@std@@8":
	.long	"??_R1A@?0A@EA@bad_array_new_length@std@@8"@IMGREL
	.long	"??_R1A@?0A@EA@bad_alloc@std@@8"@IMGREL
	.long	"??_R1A@?0A@EA@exception@std@@8"@IMGREL
	.long	0                               # 0x0

	.section	.rdata,"dr",discard,"??_R1A@?0A@EA@bad_array_new_length@std@@8"
	.globl	"??_R1A@?0A@EA@bad_array_new_length@std@@8" # @"??_R1A@?0A@EA@bad_array_new_length@std@@8"
	.p2align	4, 0x0
"??_R1A@?0A@EA@bad_array_new_length@std@@8":
	.long	"??_R0?AVbad_array_new_length@std@@@8"@IMGREL
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	64                              # 0x40
	.long	"??_R3bad_array_new_length@std@@8"@IMGREL

	.section	.rdata,"dr",discard,"??_R1A@?0A@EA@bad_alloc@std@@8"
	.globl	"??_R1A@?0A@EA@bad_alloc@std@@8" # @"??_R1A@?0A@EA@bad_alloc@std@@8"
	.p2align	4, 0x0
"??_R1A@?0A@EA@bad_alloc@std@@8":
	.long	"??_R0?AVbad_alloc@std@@@8"@IMGREL
	.long	1                               # 0x1
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	64                              # 0x40
	.long	"??_R3bad_alloc@std@@8"@IMGREL

	.section	.rdata,"dr",discard,"??_R3bad_alloc@std@@8"
	.globl	"??_R3bad_alloc@std@@8"         # @"??_R3bad_alloc@std@@8"
	.p2align	3, 0x0
"??_R3bad_alloc@std@@8":
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	2                               # 0x2
	.long	"??_R2bad_alloc@std@@8"@IMGREL

	.section	.rdata,"dr",discard,"??_R2bad_alloc@std@@8"
	.globl	"??_R2bad_alloc@std@@8"         # @"??_R2bad_alloc@std@@8"
	.p2align	2, 0x0
"??_R2bad_alloc@std@@8":
	.long	"??_R1A@?0A@EA@bad_alloc@std@@8"@IMGREL
	.long	"??_R1A@?0A@EA@exception@std@@8"@IMGREL
	.long	0                               # 0x0

	.section	.rdata,"dr",discard,"??_R1A@?0A@EA@exception@std@@8"
	.globl	"??_R1A@?0A@EA@exception@std@@8" # @"??_R1A@?0A@EA@exception@std@@8"
	.p2align	4, 0x0
"??_R1A@?0A@EA@exception@std@@8":
	.long	"??_R0?AVexception@std@@@8"@IMGREL
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	64                              # 0x40
	.long	"??_R3exception@std@@8"@IMGREL

	.section	.rdata,"dr",discard,"??_R3exception@std@@8"
	.globl	"??_R3exception@std@@8"         # @"??_R3exception@std@@8"
	.p2align	3, 0x0
"??_R3exception@std@@8":
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	"??_R2exception@std@@8"@IMGREL

	.section	.rdata,"dr",discard,"??_R2exception@std@@8"
	.globl	"??_R2exception@std@@8"         # @"??_R2exception@std@@8"
	.p2align	2, 0x0
"??_R2exception@std@@8":
	.long	"??_R1A@?0A@EA@exception@std@@8"@IMGREL
	.long	0                               # 0x0

	.section	.rdata,"dr",largest,"??_7bad_alloc@std@@6B@"
	.p2align	4, 0x0                          # @1
.L__unnamed_2:
	.quad	"??_R4bad_alloc@std@@6B@"
	.quad	"??_Gbad_alloc@std@@UEAAPEAXI@Z"
	.quad	"?what@exception@std@@UEBAPEBDXZ"

	.section	.rdata,"dr",discard,"??_R4bad_alloc@std@@6B@"
	.globl	"??_R4bad_alloc@std@@6B@"       # @"??_R4bad_alloc@std@@6B@"
	.p2align	4, 0x0
"??_R4bad_alloc@std@@6B@":
	.long	1                               # 0x1
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	"??_R0?AVbad_alloc@std@@@8"@IMGREL
	.long	"??_R3bad_alloc@std@@8"@IMGREL
	.long	"??_R4bad_alloc@std@@6B@"@IMGREL

	.section	.rdata,"dr",largest,"??_7exception@std@@6B@"
	.p2align	4, 0x0                          # @2
.L__unnamed_3:
	.quad	"??_R4exception@std@@6B@"
	.quad	"??_Gexception@std@@UEAAPEAXI@Z"
	.quad	"?what@exception@std@@UEBAPEBDXZ"

	.section	.rdata,"dr",discard,"??_R4exception@std@@6B@"
	.globl	"??_R4exception@std@@6B@"       # @"??_R4exception@std@@6B@"
	.p2align	4, 0x0
"??_R4exception@std@@6B@":
	.long	1                               # 0x1
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	"??_R0?AVexception@std@@@8"@IMGREL
	.long	"??_R3exception@std@@8"@IMGREL
	.long	"??_R4exception@std@@6B@"@IMGREL

	.section	.rdata,"dr",discard,"??_C@_0BC@EOODALEL@Unknown?5exception?$AA@"
	.globl	"??_C@_0BC@EOODALEL@Unknown?5exception?$AA@" # @"??_C@_0BC@EOODALEL@Unknown?5exception?$AA@"
"??_C@_0BC@EOODALEL@Unknown?5exception?$AA@":
	.asciz	"Unknown exception"

	.section	.drectve,"yni"
	.ascii	" /FAILIFMISMATCH:\"annotate_string=0\""
	.ascii	" /FAILIFMISMATCH:\"annotate_vector=0\""
	.ascii	" /FAILIFMISMATCH:\"_CRT_STDIO_ISO_WIDE_SPECIFIERS=0\""
	.ascii	" /FAILIFMISMATCH:\"_MSC_VER=1900\""
	.ascii	" /FAILIFMISMATCH:\"_ITERATOR_DEBUG_LEVEL=0\""
	.ascii	" /FAILIFMISMATCH:\"RuntimeLibrary=MT_StaticRelease\""
	.ascii	" /DEFAULTLIB:libcpmt.lib"
	.globl	"??_7bad_array_new_length@std@@6B@"
.set "??_7bad_array_new_length@std@@6B@", .L__unnamed_1+8
	.globl	"??_7bad_alloc@std@@6B@"
.set "??_7bad_alloc@std@@6B@", .L__unnamed_2+8
	.globl	"??_7exception@std@@6B@"
.set "??_7exception@std@@6B@", .L__unnamed_3+8
	.addrsig
	.addrsig_sym __CxxFrameHandler3
	.addrsig_sym "?has_popcnt@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@4@@Z@4_NB"
	.addrsig_sym "?$TSS0@?1??maximum_independent_set@blueberry@@YA?AV?$vector@HV?$allocator@H@std@@@std@@HAEBV?$vector@U?$pair@HH@std@@V?$allocator@U?$pair@HH@std@@@2@@3@@Z@4HA"
	.addrsig_sym "??_7type_info@@6B@"
	.addrsig_sym "??_R0?AVbad_array_new_length@std@@@8"
	.addrsig_sym __ImageBase
	.addrsig_sym "??_R0?AVbad_alloc@std@@@8"
	.addrsig_sym "??_R0?AVexception@std@@@8"
	.addrsig_sym "??_R4bad_array_new_length@std@@6B@"
	.addrsig_sym "??_R3bad_array_new_length@std@@8"
	.addrsig_sym "??_R2bad_array_new_length@std@@8"
	.addrsig_sym "??_R1A@?0A@EA@bad_array_new_length@std@@8"
	.addrsig_sym "??_R1A@?0A@EA@bad_alloc@std@@8"
	.addrsig_sym "??_R3bad_alloc@std@@8"
	.addrsig_sym "??_R2bad_alloc@std@@8"
	.addrsig_sym "??_R1A@?0A@EA@exception@std@@8"
	.addrsig_sym "??_R3exception@std@@8"
	.addrsig_sym "??_R2exception@std@@8"
	.addrsig_sym "??_R4bad_alloc@std@@6B@"
	.addrsig_sym "??_R4exception@std@@6B@"
