#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <random>
#include <tuple>
#include <vector>
#define blueberry old_blueberry
#include "baseline.hpp"
#undef blueberry
#include "candidate.hpp"
using namespace std;
int main(int argc,char**argv) {
  int which=atoi(argv[1]), n=atoi(argv[2]), m=atoi(argv[3]), kind=atoi(argv[4]), reps=atoi(argv[5]);
  mt19937_64 rng(2147483647);
  vector<tuple<int,int,long long>> e;
  e.reserve(m);
  for (int i=0;i<m;++i) {
    int u=rng()%n,v=rng()%n;
    if(kind==1) {u=0;v=rng()%n;}
    if(kind==2) {u=rng()%(n/2);v=rng()%(n/2);}
    if(kind==3 && i<n-1) {u=i;v=i+1;}
    long long w=static_cast<int>(rng());
    if(kind==4) w=rng()%3-1;
    if(kind==5) w=(static_cast<long long>(rng()&((1ull<<44)-1))-(1ll<<43));
    e.emplace_back(u,v,w);
  }
  long long checksum=0;
  auto start=chrono::steady_clock::now();
  for(int i=0;i<reps;++i) {
    auto a=which ? blueberry::minimum_spanning_forest(n,e) : old_blueberry::minimum_spanning_forest(n,e);
    checksum+=a.first+static_cast<long long>(a.second.size());
  }
  auto finish=chrono::steady_clock::now();
  cout<<chrono::duration<double,milli>(finish-start).count()<<' '<<checksum<<'\n';
}
