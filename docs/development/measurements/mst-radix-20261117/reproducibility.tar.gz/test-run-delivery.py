import hashlib,json,os,pathlib,subprocess,traceback
r=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10'); v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/p for p in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/p/'x64' for p in ('ucrt','um'))]))
results={'status':'running','hashes':{},'steps':[]}
for name in ('candidate.hpp','delivery/tests/random/minimum-spanning-forest-fast.cpp','test-run-delivery.py','atcoder/dsu'):results['hashes'][name]=hashlib.sha256((r/name).read_bytes()).hexdigest()
def save():(r/'delivery-test-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
def run(cmd):
 p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,text=True,errors='replace',timeout=120)
 results['steps'].append({'cmd':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});save()
 if p.returncode:raise RuntimeError('step failed')
save()
try:
 for compiler in ('clang','msvc'):
  for std in ('20','23'):
   for release in (False,True):
    exe=r/f'test-{compiler}{std}{release}.exe'
    if compiler=='clang':cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=c++'+std,'-O2','-Wall','-Wextra','-Werror','-I',str(r/'delivery'),'-I',str(r),str(r/'delivery/tests/random/minimum-spanning-forest-fast.cpp'),'-o',str(exe)]
    else:cmd=[str(vc/'bin/Hostx64/x64/cl.exe'),'/nologo','/std:c++'+('latest' if std=='23' else std),'/O2','/EHsc','/I'+str(r/'delivery'),'/I'+str(r),str(r/'delivery/tests/random/minimum-spanning-forest-fast.cpp'),'/Fe:'+str(exe)]
    if release:cmd.insert(1,'-DRELEASE_HEADER' if compiler=='clang' else '/DRELEASE_HEADER')
    run(cmd);run([str(exe)])
 results['status']='complete';save()
except BaseException:
 results['status']='failed';results['traceback']=traceback.format_exc();save();raise
