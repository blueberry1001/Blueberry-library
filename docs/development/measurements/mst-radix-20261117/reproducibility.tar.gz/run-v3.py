import ctypes,hashlib,json,os,pathlib,platform,statistics,subprocess,time,traceback
r=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10'); v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/p for p in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/p/'x64' for p in ('ucrt','um'))]))
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p
k.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
p=k.GetCurrentProcess();old=ctypes.c_size_t();system=ctypes.c_size_t()
assert k.GetProcessAffinityMask(p,ctypes.byref(old),ctypes.byref(system));mask=1<<8;assert old.value&mask;assert k.SetProcessAffinityMask(p,mask)
result={'status':'running','machine':platform.platform(),'processor':platform.processor(),'affinity':hex(mask),'hashes':{},'builds':[],'runs':[]}
for name in ('baseline.hpp','candidate.hpp','bench.cpp','toplike.hpp','run.py','atcoder/dsu'): result['hashes'][name]=hashlib.sha256((r/name).read_bytes()).hexdigest()
def save(): (r/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
def call(cmd):
 t=time.perf_counter();p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,text=True,errors='replace',timeout=180)
 return {'cmd':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'wall_seconds':time.perf_counter()-t}
save()
try:
 for compiler in ('clang','msvc'):
  exe=r/('bench-'+compiler+'.exe')
  if compiler=='clang': cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=c++20','-O2','-DNDEBUG','-I',str(r),str(r/'bench.cpp'),'-o',str(exe)]
  else: cmd=[str(vc/'bin/Hostx64/x64/cl.exe'),'/nologo','/std:c++20','/O2','/DNDEBUG','/EHsc','/I'+str(r),str(r/'bench.cpp'),'/Fe:'+str(exe)]
  out=call(cmd);result['builds'].append(out);save()
  if out['exit']:raise RuntimeError('compile failed')
  for n,m,kind,reps in [(100000,500000,0,3),(100000,500000,1,3),(100000,500000,2,3),(100000,100000,3,5),(100000,500000,4,3),(100000,500000,5,3),(1000,8000,0,50),(1000,8192,0,50),(100,500,0,500)]:
   checksum=None
   for sample in range(-1,5):
    for j in range(3):
     which=(j+sample+3)%3
     out=call([str(exe),str(which),str(n),str(m),str(kind),str(reps)]);out.update(compiler=compiler,n=n,m=m,kind=kind,reps=reps,sample=sample,which=which);result['runs'].append(out);save()
     if out['exit']: raise RuntimeError('run failed')
     parts=out['stdout'].split()
     if len(parts)!=2: raise RuntimeError('unexpected output')
     if checksum is None: checksum=parts[1]
     if checksum!=parts[1]:raise RuntimeError('checksum mismatch')
 result['status']='complete';save()
except BaseException:
 result['status']='failed';result['traceback']=traceback.format_exc();save();raise
