#pragma once
#include <cstdint>
#include <limits>
#include <tuple>
#include <utility>
#include <vector>
namespace toplike {
struct item { std::uint32_t w, id; int u, v; };
std::pair<long long,std::vector<int>> forest(int n,const std::vector<std::tuple<int,int,long long>>& edges) {
  if(n<=1) return {0,{}};
  if(edges.size()<8192) return old_blueberry::minimum_spanning_forest(n,edges);
  for(auto [u,v,w]:edges)
    if(w<std::numeric_limits<std::int32_t>::min() || w>std::numeric_limits<std::int32_t>::max())
      return old_blueberry::minimum_spanning_forest(n,edges);
  std::vector<item>a(edges.size()),b(edges.size());
  std::size_t cnt[4][256]{};
  for(std::size_t i=0;i<edges.size();++i) {
    auto [u,v,w]=edges[i];auto x=static_cast<std::uint32_t>(w)^0x80000000u;
    a[i]={x,static_cast<std::uint32_t>(i),u,v};
    for(int p=0;p<4;++p)++cnt[p][(x>>(8*p))&255];
  }
  for(int p=0;p<4;++p) {
    std::size_t sum=0;
    for(auto& x:cnt[p]) {auto prev=x;x=sum;sum+=prev;}
    for(auto x:a)b[cnt[p][(x.w>>(8*p))&255]++]=x;
    a.swap(b);
  }
  std::vector<int> parent(n,-1), ids;ids.reserve(n-1);
  auto find=[&](int x){int y=x;while(parent[y]>=0)y=parent[y];while(x!=y){int z=parent[x];parent[x]=y;x=z;}return y;};
  long long total=0;
  for(auto x:a) {
    int u=find(x.u),v=find(x.v);if(u==v)continue;
    if(parent[u]>parent[v])std::swap(u,v);parent[u]+=parent[v];parent[v]=u;
    total+=std::get<2>(edges[x.id]);ids.push_back(x.id);if(ids.size()==static_cast<std::size_t>(n-1))break;
  }
  return {total,std::move(ids)};
}
}
