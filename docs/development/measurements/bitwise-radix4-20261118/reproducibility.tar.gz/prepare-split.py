from pathlib import Path
p=Path(__file__).parent
b=(p/'baseline.hpp').read_text(); c=(p/'candidate-final.hpp').read_text()
i=b.index('template <class T>\nvoid transform(');j=b.index('template <class T>\nvoid check(',i)
baseline=b[i:j]
i=c.index('template <int Kind, bool Inverse, class T>\nvoid transform(');j=c.index('\n}\ntemplate <class T> std::vector<T> bitwise_convolution_and',i)
radix=c[i:j].replace('void transform(', 'void transform4(')
out='''#pragma once
#include <cstddef>
#include <type_traits>
#include <vector>
namespace blueberry {
namespace bitwise_convolution_detail {
'''+baseline+radix+'\n}\n'
for kind,name in [(0,'and'),(1,'or')]:
 out+=f'''template <class T> std::vector<T> bitwise_convolution_{name}(std::vector<T> a, std::vector<T> b) {{
#if defined(_MSC_VER) && !defined(__clang__)
  if constexpr (!std::is_integral_v<T> && sizeof(T) <= 4) {{
    bitwise_convolution_detail::transform4<{kind}, false>(a);
    bitwise_convolution_detail::transform4<{kind}, false>(b);
    for (std::size_t i = 0; i < a.size(); ++i) a[i] *= b[i];
    bitwise_convolution_detail::transform4<{kind}, true>(a);
    return a;
  }}
#endif
  bitwise_convolution_detail::transform(a, {kind}, false);
  bitwise_convolution_detail::transform(b, {kind}, false);
  for (std::size_t i = 0; i < a.size(); ++i) a[i] *= b[i];
  bitwise_convolution_detail::transform(a, {kind}, true);
  return a;
}}
'''
i=c.index('template <class T> std::vector<T> bitwise_convolution_xor');out+=c[i:].replace('bitwise_convolution_detail::transform<2, false>', 'bitwise_convolution_detail::transform4<2, false>')
(p/'candidate-split.hpp').write_text(out,encoding='utf-8',newline='\n')
s=(p/'compare-originalgate.cpp').read_text().replace('#else\n#include "candidate-originalgate.hpp"','#elif VERSION == 4\n#include "candidate-originalgate.hpp"\n#else\n#include "candidate-split.hpp"')
(p/'compare-split.cpp').write_text(s,encoding='utf-8',newline='\n')
s=(p/'run-originalgate.py').read_text().replace("p/'results-originalgate.json'","p/'results-split.json'").replace("p/(cc+'-og-'+str(ver)+'.exe')","p/(cc+'-split-'+str(ver)+'.exe')").replace("p/'compare-originalgate.cpp'","p/'compare-split.cpp'").replace('for ver in (0,3,4):','for ver in (0,3,5):').replace('((0,3,4) if sample%2 else (4,3,0))','((0,3,5) if sample%2 else (5,3,0))')
(p/'run-split.py').write_text(s,encoding='utf-8',newline='\n')
