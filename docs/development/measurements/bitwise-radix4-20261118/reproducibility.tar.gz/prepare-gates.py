from pathlib import Path
p=Path(__file__).parent
s=(p/'candidate-final.hpp').read_text()
needle='  if constexpr (Kind != 2 && (std::is_integral_v<T> || sizeof(T) > 4)) {'
assert needle in s
(p/'candidate-xor.hpp').write_text(s.replace(needle,'  if constexpr (Kind != 2) {'),encoding='utf-8',newline='\n')
hybrid='''#if defined(_MSC_VER) && !defined(__clang__)
  if constexpr (Kind != 2 && (std::is_integral_v<T> || sizeof(T) > 4)) {
#else
  if constexpr (Kind != 2) {
#endif'''
(p/'candidate-msvc.hpp').write_text(s.replace(needle,hybrid),encoding='utf-8',newline='\n')
q=(p/'compare-final.cpp').read_text()
needle='#include "candidate-final.hpp"\n#undef blueberry\n'
q=q.replace(needle,needle+'''#define blueberry candidate2
#include "candidate-xor.hpp"
#undef blueberry
#define blueberry candidate3
#include "candidate-msvc.hpp"
#undef blueberry
''')
start=q.index('    if(kind==0)c=');end=q.index('    for(std::size_t j=0;',start)
q=q[:start]+'''    if(kind==0)c=version==3?candidate3::bitwise_convolution_and(a,b):version==2?candidate2::bitwise_convolution_and(a,b):version?candidate::bitwise_convolution_and(a,b):baseline::bitwise_convolution_and(a,b);
    else if(kind==1)c=version==3?candidate3::bitwise_convolution_or(a,b):version==2?candidate2::bitwise_convolution_or(a,b):version?candidate::bitwise_convolution_or(a,b):baseline::bitwise_convolution_or(a,b);
    else if constexpr(!std::is_integral_v<T>)c=version==3?candidate3::bitwise_convolution_xor(a,b):version==2?candidate2::bitwise_convolution_xor(a,b):version?candidate::bitwise_convolution_xor(a,b):baseline::bitwise_convolution_xor(a,b);
'''+q[end:]
(p/'compare-gates.cpp').write_text(q,encoding='utf-8',newline='\n')
q=(p/'run-final.py').read_text().replace("p/'results-final.json'","p/'results-gates.json'").replace("p/(cc+'-final.exe')","p/(cc+'-gates.exe')").replace("p/'compare-final.cpp'","p/'compare-gates.cpp'").replace('((0,1) if sample%2 else (1,0))','((0,1,2,3) if sample%2 else (3,2,1,0))')
(p/'run-gates.py').write_text(q,encoding='utf-8',newline='\n')
