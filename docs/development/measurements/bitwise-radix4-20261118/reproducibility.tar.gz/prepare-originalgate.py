from pathlib import Path
p=Path(__file__).parent
s=(p/'candidate-msvc.hpp').read_text()
b=(p/'baseline.hpp').read_text();i=b.index('template <class T>\nvoid transform(');j=b.index('template <class T>\nvoid check(',i)
standard=b[i:j].replace('void transform(', 'void original(')
needle='template <int Kind, bool Inverse, class T>\nvoid transform('
assert needle in s;s=s.replace(needle,standard+needle)
needle='}\ntemplate <class T> std::vector<T> bitwise_convolution_and'
wrapper='''template <int Kind, bool Inverse, class T>
void choose(std::vector<T>& a) {
#if defined(_MSC_VER) && !defined(__clang__)
  if constexpr (!std::is_integral_v<T> && sizeof(T) <= 4) transform<Kind, Inverse>(a);
  else original(a, Kind, Inverse);
#else
  original(a, Kind, Inverse);
#endif
}
}
template <class T> std::vector<T> bitwise_convolution_and'''
assert needle in s;s=s.replace(needle,wrapper)
for i in (0,1):
 for inv in ('true','false'):
  s=s.replace(f'bitwise_convolution_detail::transform<{i}, {inv}>',f'bitwise_convolution_detail::choose<{i}, {inv}>')
(p/'candidate-originalgate.hpp').write_text(s,encoding='utf-8',newline='\n')
s=(p/'compare-separate.cpp').read_text().replace('#else\n#include "candidate-msvc.hpp"','#elif VERSION == 3\n#include "candidate-msvc.hpp"\n#else\n#include "candidate-originalgate.hpp"')
(p/'compare-originalgate.cpp').write_text(s,encoding='utf-8',newline='\n')
s=(p/'run-separate.py').read_text().replace("p/'results-separate.json'","p/'results-originalgate.json'").replace("p/(cc+'-sep-'+str(ver)+'.exe')","p/(cc+'-og-'+str(ver)+'.exe')").replace("p/'compare-separate.cpp'","p/'compare-originalgate.cpp'").replace('for ver in range(4):','for ver in (0,3,4):').replace('((0,1,2,3) if sample%2 else (3,2,1,0))','((0,3,4) if sample%2 else (4,3,0))')
(p/'run-originalgate.py').write_text(s,encoding='utf-8',newline='\n')
