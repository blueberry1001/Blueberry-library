from pathlib import Path
p=Path(__file__).parent
s=(p/'candidate.hpp').read_text().replace('#include <vector>','#include <vector>\n#include <cstdint>\n#include <limits>\n#include <type_traits>\n#include <utility>\n#if __has_include(<atcoder/modint>)\n#include <atcoder/modint>\n#define BLUEBERRY_BITWISE_ACL_AVAILABLE 1\n#endif')
needle='template <class T> void check(const std::vector<T>& a, const std::vector<T>& b) {'
insert='''template<class T> struct acl_static_modint : std::false_type {};
#ifdef BLUEBERRY_BITWISE_ACL_AVAILABLE
template<int Mod, std::enable_if_t<(1 <= Mod)>* P>
struct acl_static_modint<atcoder::static_modint<Mod, P>> : std::true_type {};
#endif
template<class T>
std::vector<T> fast_xor(std::vector<T> a, const std::vector<T>& b) {
  const int mod=T::mod(); const std::size_t n=a.size();
  std::vector<std::int64_t> x(n),y(n);
  for(std::size_t i=0;i<n;++i){x[i]=a[i].val();y[i]=b[i].val();}
  transform<2,false>(x);transform<2,false>(y);
  for(std::size_t i=0;i<n;++i) {
    auto p=x[i]%mod,q=y[i]%mod;
    if(p<0)p+=mod;if(q<0)q+=mod;
    x[i]=(p*q)%mod;
  }
  transform<2,false>(x);
  auto inv=(T(1)/T(n)).val();
  for(std::size_t i=0;i<n;++i) {
    auto p=x[i]%mod;if(p<0)p+=mod;
    a[i]=T::raw(static_cast<int>((p*inv)%mod));
  }
  return a;
}
'''
s=s.replace(needle,insert+needle)
needle='  if (a.empty()) return {};\n  bitwise_convolution_detail::transform<2, false>(a);'
s=s.replace(needle,'''  if (a.empty()) return {};
  if constexpr (bitwise_convolution_detail::acl_static_modint<T>::value) {
    if (a.size() >= 256 && T::mod() > 1 && a.size() <= std::size_t(std::numeric_limits<std::int64_t>::max() / (T::mod() - 1)))
      return bitwise_convolution_detail::fast_xor(std::move(a), b);
  }
  bitwise_convolution_detail::transform<2, false>(a);''')
s += '\n#ifdef BLUEBERRY_BITWISE_ACL_AVAILABLE\n#undef BLUEBERRY_BITWISE_ACL_AVAILABLE\n#endif\n'
(p/'candidate3.hpp').write_text(s)
