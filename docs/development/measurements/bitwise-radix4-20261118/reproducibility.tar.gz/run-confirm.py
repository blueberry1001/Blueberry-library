import ctypes,json,pathlib,platform,subprocess,traceback
p=pathlib.Path(__file__).resolve().parent
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<16)
d={'status':'running','platform':platform.platform(),'processor':platform.processor(),'affinity':'0x10000','runs':[]}
def save(): (p/'results-confirm.json').write_text(json.dumps(d,indent=2)+'\n')
try:
 for cc in ('clang','msvc'):
  for typ,kind in ((0,0),(0,1),(0,2),(1,0),(1,1),(2,0),(2,1)):
   for bits,reps in ((12,50),(16,4),(20,1)):
    for sample in range(-1,9):
     outputs=[]
     for ver in ((0,3) if sample%2 else (3,0)):
      exe=p/(cc+'-sep-'+str(ver)+'.exe');cmd=[str(exe),str(ver),str(kind),str(typ),str(bits),str(reps)];r=subprocess.run(cmd,cwd=p,capture_output=True,text=True,timeout=180);o={'cmd':cmd,'cc':cc,'typ':typ,'kind':kind,'bits':bits,'reps':reps,'sample':sample,'ver':ver,'exit':r.returncode,'out':r.stdout,'err':r.stderr};d['runs'].append(o);save()
      if r.returncode:raise RuntimeError('command failed')
      outputs.append(r.stdout.split()[1])
     if len(set(outputs))!=1:raise RuntimeError('mismatching checksums')
 d['status']='complete';save()
except BaseException:
 d['status']='failed';d['traceback']=traceback.format_exc();save();raise
