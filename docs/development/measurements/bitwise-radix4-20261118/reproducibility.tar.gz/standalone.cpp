#include "delivery/blueberry/math/bitwise-convolution.hpp"
#include <cstdint>
int main(){
  std::vector<std::uint64_t> a{1,2},b{3,4};
  auto x=blueberry::bitwise_convolution_and(a,b);
  auto y=blueberry::bitwise_convolution_or(a,b);
  return x[0]!=13||x[1]!=8||y[0]!=3||y[1]!=18;
}
