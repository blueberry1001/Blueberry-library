from pathlib import Path
p=Path(__file__).parent
s=(p/'candidate.hpp').read_text()
needle='template <class T> void check(const std::vector<T>& a, const std::vector<T>& b) {'
insert='''template <int Kind, class T>
void transform_pair(std::vector<T>& a, std::vector<T>& b) {
  const std::size_t n = a.size();
  for (std::size_t half = 1; half < n; half <<= 1)
    for (std::size_t start = 0; start < n; start += half * 2)
      for (std::size_t j = start; j < start + half; ++j) {
        if constexpr (Kind == 0) { a[j] += a[j + half]; b[j] += b[j + half]; }
        else if constexpr (Kind == 1) { a[j + half] += a[j]; b[j + half] += b[j]; }
        else {
          T x = a[j], y = a[j + half]; a[j] = x + y; a[j + half] = x - y;
          T z = b[j], w = b[j + half]; b[j] = z + w; b[j + half] = z - w;
        }
      }
}
'''
s=s.replace(needle,insert+needle)
for i in range(3):
 s=s.replace(f'  bitwise_convolution_detail::transform<{i}, false>(a);\n  bitwise_convolution_detail::transform<{i}, false>(b);',f'  bitwise_convolution_detail::transform_pair<{i}>(a, b);')
(p/'candidate2.hpp').write_text(s)
