	.text
	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
.set @feat.00, 0
	.intel_syntax noprefix
	.file	"codegen-or.cpp"
	.def	"?floor_sum_unsigned@internal@atcoder@@YA_K_K000@Z";
	.scl	2;
	.type	32;
	.endef
	.globl	"?floor_sum_unsigned@internal@atcoder@@YA_K_K000@Z" # -- Begin function ?floor_sum_unsigned@internal@atcoder@@YA_K_K000@Z
	.p2align	4, 0x90
"?floor_sum_unsigned@internal@atcoder@@YA_K_K000@Z": # @"?floor_sum_unsigned@internal@atcoder@@YA_K_K000@Z"
.seh_proc "?floor_sum_unsigned@internal@atcoder@@YA_K_K000@Z"
# %bb.0:
	push	rsi
	.seh_pushreg rsi
	.seh_endprologue
	mov	r10, r9
	mov	rsi, r8
	mov	r8, rdx
	mov	r9, rcx
	xor	ecx, ecx
	cmp	rsi, r8
	jae	.LBB0_3
	jmp	.LBB0_2
	.p2align	4, 0x90
.LBB0_15:
	mov	rax, r9
	xor	edx, edx
	div	r8
	mov	r10, rdx
	mov	rsi, r8
	mov	r8, r11
	mov	r9, rax
	cmp	rsi, r8
	jae	.LBB0_3
.LBB0_2:
	mov	r11, rsi
	cmp	r10, r8
	jae	.LBB0_8
	jmp	.LBB0_12
	.p2align	4, 0x90
.LBB0_3:
	mov	rax, rsi
	or	rax, r8
	shr	rax, 32
	je	.LBB0_4
# %bb.5:
	mov	rax, rsi
	xor	edx, edx
	div	r8
	mov	r11, rdx
	jmp	.LBB0_6
	.p2align	4, 0x90
.LBB0_4:
	mov	eax, esi
	xor	edx, edx
	div	r8d
	mov	r11d, edx
                                        # kill: def $eax killed $eax def $rax
.LBB0_6:
	lea	rdx, [r9 - 1]
	imul	rdx, r9
	shr	rdx
	imul	rdx, rax
	add	rcx, rdx
	cmp	r10, r8
	jb	.LBB0_12
.LBB0_8:
	mov	rax, r10
	or	rax, r8
	shr	rax, 32
	je	.LBB0_9
# %bb.10:
	mov	rax, r10
	xor	edx, edx
	div	r8
	mov	r10, rdx
	jmp	.LBB0_11
	.p2align	4, 0x90
.LBB0_9:
	mov	eax, r10d
	xor	edx, edx
	div	r8d
                                        # kill: def $eax killed $eax def $rax
	mov	r10d, edx
.LBB0_11:
	imul	rax, r9
	add	rcx, rax
.LBB0_12:
	imul	r9, r11
	add	r9, r10
	cmp	r9, r8
	jb	.LBB0_16
# %bb.13:
	mov	rax, r9
	or	rax, r8
	shr	rax, 32
	jne	.LBB0_15
# %bb.14:
	mov	eax, r9d
	xor	edx, edx
	div	r8d
	mov	r10d, edx
	mov	rsi, r8
	mov	r8, r11
	mov	r9d, eax
	cmp	rsi, r8
	jae	.LBB0_3
	jmp	.LBB0_2
.LBB0_16:
	mov	rax, rcx
	pop	rsi
	ret
	.seh_endproc
                                        # -- End function
	.def	"?old_or@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z";
	.scl	2;
	.type	32;
	.endef
	.globl	__xmm@80000000800000008000000080000000 # -- Begin function ?old_or@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z
	.section	.rdata,"dr",discard,__xmm@80000000800000008000000080000000
	.p2align	4, 0x0
__xmm@80000000800000008000000080000000:
	.long	2147483648                      # 0x80000000
	.long	2147483648                      # 0x80000000
	.long	2147483648                      # 0x80000000
	.long	2147483648                      # 0x80000000
	.globl	__xmm@bb800001bb800001bb800001bb800001
	.section	.rdata,"dr",discard,__xmm@bb800001bb800001bb800001bb800001
	.p2align	4, 0x0
__xmm@bb800001bb800001bb800001bb800001:
	.long	3145728001                      # 0xbb800001
	.long	3145728001                      # 0xbb800001
	.long	3145728001                      # 0xbb800001
	.long	3145728001                      # 0xbb800001
	.globl	__xmm@c47fffffc47fffffc47fffffc47fffff
	.section	.rdata,"dr",discard,__xmm@c47fffffc47fffffc47fffffc47fffff
	.p2align	4, 0x0
__xmm@c47fffffc47fffffc47fffffc47fffff:
	.long	3296722943                      # 0xc47fffff
	.long	3296722943                      # 0xc47fffff
	.long	3296722943                      # 0xc47fffff
	.long	3296722943                      # 0xc47fffff
	.text
	.globl	"?old_or@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z"
	.p2align	4, 0x90
"?old_or@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z": # @"?old_or@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z"
.seh_proc "?old_or@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z"
# %bb.0:
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbp
	.seh_pushreg rbp
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 56
	.seh_stackalloc 56
	movdqa	xmmword ptr [rsp + 32], xmm8    # 16-byte Spill
	.seh_savexmm xmm8, 32
	movdqa	xmmword ptr [rsp + 16], xmm7    # 16-byte Spill
	.seh_savexmm xmm7, 16
	movdqa	xmmword ptr [rsp], xmm6         # 16-byte Spill
	.seh_savexmm xmm6, 0
	.seh_endprologue
	mov	rax, qword ptr [rcx]
	mov	rcx, qword ptr [rcx + 8]
	sub	rcx, rax
	sar	rcx, 2
	cmp	rcx, 2
	jb	.LBB1_10
# %bb.1:
	lea	rdx, [rax + 16]
	mov	r8d, 1
	movdqa	xmm0, xmmword ptr [rip + __xmm@80000000800000008000000080000000] # xmm0 = [2147483648,2147483648,2147483648,2147483648]
	movdqa	xmm1, xmmword ptr [rip + __xmm@bb800001bb800001bb800001bb800001] # xmm1 = [3145728001,3145728001,3145728001,3145728001]
	movdqa	xmm2, xmmword ptr [rip + __xmm@c47fffffc47fffffc47fffffc47fffff] # xmm2 = [3296722943,3296722943,3296722943,3296722943]
	jmp	.LBB1_2
	.p2align	4, 0x90
.LBB1_9:                                #   in Loop: Header=BB1_2 Depth=1
	mov	r8, r9
	cmp	r9, rcx
	jae	.LBB1_10
.LBB1_2:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB1_3 Depth 2
                                        #       Child Loop BB1_6 Depth 3
                                        #       Child Loop BB1_11 Depth 3
	lea	r9, [r8 + r8]
	mov	r10, r8
	and	r10, -8
	lea	r11, [8*r8]
	lea	rsi, [4*r8]
	lea	rdi, [rax + 4*r8]
	mov	rbx, rdx
	mov	r14, r8
	xor	r15d, r15d
	jmp	.LBB1_3
	.p2align	4, 0x90
.LBB1_8:                                #   in Loop: Header=BB1_3 Depth=2
	add	r15, r9
	add	r14, r9
	add	rbx, r11
	cmp	r15, rcx
	jae	.LBB1_9
.LBB1_3:                                #   Parent Loop BB1_2 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB1_6 Depth 3
                                        #       Child Loop BB1_11 Depth 3
	lea	r12, [r15 + r8]
	cmp	r15, r12
	jae	.LBB1_8
# %bb.4:                                #   in Loop: Header=BB1_3 Depth=2
	mov	r12, r15
	cmp	r8, 8
	jb	.LBB1_11
# %bb.5:                                #   in Loop: Header=BB1_3 Depth=2
	lea	r12, [r15 + r10]
	mov	r13, r10
	mov	rbp, rbx
	.p2align	4, 0x90
.LBB1_6:                                #   Parent Loop BB1_2 Depth=1
                                        #     Parent Loop BB1_3 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movdqu	xmm3, xmmword ptr [rbp - 16]
	movdqu	xmm4, xmmword ptr [rbp]
	movdqu	xmm5, xmmword ptr [rbp + rsi - 16]
	paddd	xmm5, xmm3
	movdqu	xmm3, xmmword ptr [rbp + rsi]
	paddd	xmm3, xmm4
	movdqa	xmm4, xmm5
	pxor	xmm4, xmm0
	movdqa	xmm6, xmm1
	pcmpgtd	xmm6, xmm4
	movdqa	xmm4, xmm3
	pxor	xmm4, xmm0
	movdqa	xmm7, xmm1
	pcmpgtd	xmm7, xmm4
	movdqa	xmm4, xmm5
	paddd	xmm4, xmm2
	movdqa	xmm8, xmm3
	paddd	xmm8, xmm2
	pand	xmm5, xmm6
	pandn	xmm6, xmm4
	por	xmm6, xmm5
	pand	xmm3, xmm7
	pandn	xmm7, xmm8
	por	xmm7, xmm3
	movdqu	xmmword ptr [rbp + rsi - 16], xmm6
	movdqu	xmmword ptr [rbp + rsi], xmm7
	add	rbp, 32
	add	r13, -8
	jne	.LBB1_6
# %bb.7:                                #   in Loop: Header=BB1_3 Depth=2
	cmp	r8, r10
	je	.LBB1_8
	.p2align	4, 0x90
.LBB1_11:                               #   Parent Loop BB1_2 Depth=1
                                        #     Parent Loop BB1_3 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	mov	ebp, dword ptr [rdi + 4*r12]
	add	ebp, dword ptr [rax + 4*r12]
	mov	r13d, ebp
	sub	r13d, 998244353
	cmovb	r13d, ebp
	mov	dword ptr [rdi + 4*r12], r13d
	inc	r12
	cmp	r14, r12
	jne	.LBB1_11
	jmp	.LBB1_8
.LBB1_10:
	movaps	xmm6, xmmword ptr [rsp]         # 16-byte Reload
	movaps	xmm7, xmmword ptr [rsp + 16]    # 16-byte Reload
	movaps	xmm8, xmmword ptr [rsp + 32]    # 16-byte Reload
	add	rsp, 56
	pop	rbx
	pop	rbp
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	ret
	.seh_endproc
                                        # -- End function
	.def	"?new_or@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z";
	.scl	2;
	.type	32;
	.endef
	.globl	"?new_or@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z" # -- Begin function ?new_or@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z
	.p2align	4, 0x90
"?new_or@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z": # @"?new_or@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z"
.seh_proc "?new_or@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z"
# %bb.0:
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbp
	.seh_pushreg rbp
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 56
	.seh_stackalloc 56
	movdqa	xmmword ptr [rsp + 32], xmm8    # 16-byte Spill
	.seh_savexmm xmm8, 32
	movdqa	xmmword ptr [rsp + 16], xmm7    # 16-byte Spill
	.seh_savexmm xmm7, 16
	movdqa	xmmword ptr [rsp], xmm6         # 16-byte Spill
	.seh_savexmm xmm6, 0
	.seh_endprologue
	mov	rax, qword ptr [rcx]
	mov	rcx, qword ptr [rcx + 8]
	sub	rcx, rax
	sar	rcx, 2
	cmp	rcx, 2
	jb	.LBB2_10
# %bb.1:
	lea	rdx, [rax + 16]
	mov	r8d, 1
	movdqa	xmm0, xmmword ptr [rip + __xmm@80000000800000008000000080000000] # xmm0 = [2147483648,2147483648,2147483648,2147483648]
	movdqa	xmm1, xmmword ptr [rip + __xmm@bb800001bb800001bb800001bb800001] # xmm1 = [3145728001,3145728001,3145728001,3145728001]
	movdqa	xmm2, xmmword ptr [rip + __xmm@c47fffffc47fffffc47fffffc47fffff] # xmm2 = [3296722943,3296722943,3296722943,3296722943]
	jmp	.LBB2_2
	.p2align	4, 0x90
.LBB2_9:                                #   in Loop: Header=BB2_2 Depth=1
	mov	r8, r9
	cmp	r9, rcx
	jae	.LBB2_10
.LBB2_2:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB2_3 Depth 2
                                        #       Child Loop BB2_6 Depth 3
                                        #       Child Loop BB2_11 Depth 3
	lea	r9, [r8 + r8]
	mov	r10, r8
	and	r10, -8
	lea	r11, [8*r8]
	lea	rsi, [4*r8]
	lea	rdi, [rax + 4*r8]
	mov	rbx, rdx
	mov	r14, r8
	xor	r15d, r15d
	jmp	.LBB2_3
	.p2align	4, 0x90
.LBB2_8:                                #   in Loop: Header=BB2_3 Depth=2
	add	r15, r9
	add	r14, r9
	add	rbx, r11
	cmp	r15, rcx
	jae	.LBB2_9
.LBB2_3:                                #   Parent Loop BB2_2 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB2_6 Depth 3
                                        #       Child Loop BB2_11 Depth 3
	lea	r12, [r15 + r8]
	cmp	r15, r12
	jae	.LBB2_8
# %bb.4:                                #   in Loop: Header=BB2_3 Depth=2
	mov	r12, r15
	cmp	r8, 8
	jb	.LBB2_11
# %bb.5:                                #   in Loop: Header=BB2_3 Depth=2
	lea	r12, [r15 + r10]
	mov	r13, r10
	mov	rbp, rbx
	.p2align	4, 0x90
.LBB2_6:                                #   Parent Loop BB2_2 Depth=1
                                        #     Parent Loop BB2_3 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movdqu	xmm3, xmmword ptr [rbp - 16]
	movdqu	xmm4, xmmword ptr [rbp]
	movdqu	xmm5, xmmword ptr [rbp + rsi - 16]
	paddd	xmm5, xmm3
	movdqu	xmm3, xmmword ptr [rbp + rsi]
	paddd	xmm3, xmm4
	movdqa	xmm4, xmm5
	pxor	xmm4, xmm0
	movdqa	xmm6, xmm1
	pcmpgtd	xmm6, xmm4
	movdqa	xmm4, xmm3
	pxor	xmm4, xmm0
	movdqa	xmm7, xmm1
	pcmpgtd	xmm7, xmm4
	movdqa	xmm4, xmm5
	paddd	xmm4, xmm2
	movdqa	xmm8, xmm3
	paddd	xmm8, xmm2
	pand	xmm5, xmm6
	pandn	xmm6, xmm4
	por	xmm6, xmm5
	pand	xmm3, xmm7
	pandn	xmm7, xmm8
	por	xmm7, xmm3
	movdqu	xmmword ptr [rbp + rsi - 16], xmm6
	movdqu	xmmword ptr [rbp + rsi], xmm7
	add	rbp, 32
	add	r13, -8
	jne	.LBB2_6
# %bb.7:                                #   in Loop: Header=BB2_3 Depth=2
	cmp	r8, r10
	je	.LBB2_8
	.p2align	4, 0x90
.LBB2_11:                               #   Parent Loop BB2_2 Depth=1
                                        #     Parent Loop BB2_3 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	mov	ebp, dword ptr [rdi + 4*r12]
	add	ebp, dword ptr [rax + 4*r12]
	mov	r13d, ebp
	sub	r13d, 998244353
	cmovb	r13d, ebp
	mov	dword ptr [rdi + 4*r12], r13d
	inc	r12
	cmp	r14, r12
	jne	.LBB2_11
	jmp	.LBB2_8
.LBB2_10:
	movaps	xmm6, xmmword ptr [rsp]         # 16-byte Reload
	movaps	xmm7, xmmword ptr [rsp + 16]    # 16-byte Reload
	movaps	xmm8, xmmword ptr [rsp + 32]    # 16-byte Reload
	add	rsp, 56
	pop	rbx
	pop	rbp
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	ret
	.seh_endproc
                                        # -- End function
	.section	.drectve,"yni"
	.ascii	" /FAILIFMISMATCH:\"_MSC_VER=1900\""
	.ascii	" /FAILIFMISMATCH:\"_ITERATOR_DEBUG_LEVEL=0\""
	.ascii	" /FAILIFMISMATCH:\"RuntimeLibrary=MT_StaticRelease\""
	.ascii	" /DEFAULTLIB:libcpmt.lib"
	.ascii	" /FAILIFMISMATCH:\"_CRT_STDIO_ISO_WIDE_SPECIFIERS=0\""
	.ascii	" /FAILIFMISMATCH:\"annotate_string=0\""
	.ascii	" /FAILIFMISMATCH:\"annotate_vector=0\""
	.addrsig
