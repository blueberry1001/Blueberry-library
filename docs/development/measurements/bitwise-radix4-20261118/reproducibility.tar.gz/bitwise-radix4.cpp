#include <atcoder/modint>
#include <cstdint>
#include <iostream>
#include <random>
#include <vector>
#include "blueberry/math/bitwise-convolution.hpp"

template<class T, bool Xor> bool test(std::mt19937_64& gen) {
  for(int bits=0;bits<=8;++bits) for(int rep=0;rep<15;++rep) {
    int n=1<<bits;std::vector<T> a(n),b(n),u(n),v(n),w(n);
    for(int i=0;i<n;++i) {a[i]=T(gen()%3);b[i]=T(gen()%3);}
    for(int i=0;i<n;++i) for(int j=0;j<n;++j) {
      u[i&j]+=a[i]*b[j];v[i|j]+=a[i]*b[j];
      if constexpr(Xor)w[i^j]+=a[i]*b[j];
    }
    if(blueberry::bitwise_convolution_and(a,b)!=u||blueberry::bitwise_convolution_or(a,b)!=v) {
      std::cerr<<"AND/OR mismatch bits="<<bits<<" rep="<<rep<<'\n';return false;
    }
    if constexpr(Xor) if(blueberry::bitwise_convolution_xor(a,b)!=w) {
      std::cerr<<"XOR mismatch bits="<<bits<<" rep="<<rep<<'\n';return false;
    }
  }
  return true;
}
int main(){
  std::mt19937_64 gen(7251231);
  if(!test<atcoder::modint998244353,true>(gen))return 1;
  if(!test<atcoder::static_modint<3>,true>(gen))return 2;
  if(!test<atcoder::static_modint<7>,true>(gen))return 3;
  if(!test<std::uint32_t,false>(gen)||!test<std::uint64_t,false>(gen))return 4;
  if(!test<std::int64_t,false>(gen)||!test<double,true>(gen))return 5;
  using M=atcoder::modint998244353;
  if(!blueberry::bitwise_convolution_and(std::vector<M>{},std::vector<M>{}).empty())return 6;
  if(!blueberry::bitwise_convolution_or(std::vector<M>{},std::vector<M>{}).empty())return 7;
  if(!blueberry::bitwise_convolution_xor(std::vector<M>{},std::vector<M>{}).empty())return 8;
  std::cout<<"PASS seed=7251231, lengths 0..256, 7 coefficient types\n";
}
