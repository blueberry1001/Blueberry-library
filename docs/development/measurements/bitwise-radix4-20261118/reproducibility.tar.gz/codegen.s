	.text
	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
.set @feat.00, 0
	.intel_syntax noprefix
	.file	"codegen.cpp"
	.def	"?floor_sum_unsigned@internal@atcoder@@YA_K_K000@Z";
	.scl	2;
	.type	32;
	.endef
	.globl	"?floor_sum_unsigned@internal@atcoder@@YA_K_K000@Z" # -- Begin function ?floor_sum_unsigned@internal@atcoder@@YA_K_K000@Z
	.p2align	4, 0x90
"?floor_sum_unsigned@internal@atcoder@@YA_K_K000@Z": # @"?floor_sum_unsigned@internal@atcoder@@YA_K_K000@Z"
.seh_proc "?floor_sum_unsigned@internal@atcoder@@YA_K_K000@Z"
# %bb.0:
	push	rsi
	.seh_pushreg rsi
	.seh_endprologue
	mov	r10, r9
	mov	rsi, r8
	mov	r8, rdx
	mov	r9, rcx
	xor	ecx, ecx
	cmp	rsi, r8
	jae	.LBB0_3
	jmp	.LBB0_2
	.p2align	4, 0x90
.LBB0_15:
	mov	rax, r9
	xor	edx, edx
	div	r8
	mov	r10, rdx
	mov	rsi, r8
	mov	r8, r11
	mov	r9, rax
	cmp	rsi, r8
	jae	.LBB0_3
.LBB0_2:
	mov	r11, rsi
	cmp	r10, r8
	jae	.LBB0_8
	jmp	.LBB0_12
	.p2align	4, 0x90
.LBB0_3:
	mov	rax, rsi
	or	rax, r8
	shr	rax, 32
	je	.LBB0_4
# %bb.5:
	mov	rax, rsi
	xor	edx, edx
	div	r8
	mov	r11, rdx
	jmp	.LBB0_6
	.p2align	4, 0x90
.LBB0_4:
	mov	eax, esi
	xor	edx, edx
	div	r8d
	mov	r11d, edx
                                        # kill: def $eax killed $eax def $rax
.LBB0_6:
	lea	rdx, [r9 - 1]
	imul	rdx, r9
	shr	rdx
	imul	rdx, rax
	add	rcx, rdx
	cmp	r10, r8
	jb	.LBB0_12
.LBB0_8:
	mov	rax, r10
	or	rax, r8
	shr	rax, 32
	je	.LBB0_9
# %bb.10:
	mov	rax, r10
	xor	edx, edx
	div	r8
	mov	r10, rdx
	jmp	.LBB0_11
	.p2align	4, 0x90
.LBB0_9:
	mov	eax, r10d
	xor	edx, edx
	div	r8d
                                        # kill: def $eax killed $eax def $rax
	mov	r10d, edx
.LBB0_11:
	imul	rax, r9
	add	rcx, rax
.LBB0_12:
	imul	r9, r11
	add	r9, r10
	cmp	r9, r8
	jb	.LBB0_16
# %bb.13:
	mov	rax, r9
	or	rax, r8
	shr	rax, 32
	jne	.LBB0_15
# %bb.14:
	mov	eax, r9d
	xor	edx, edx
	div	r8d
	mov	r10d, edx
	mov	rsi, r8
	mov	r8, r11
	mov	r9d, eax
	cmp	rsi, r8
	jae	.LBB0_3
	jmp	.LBB0_2
.LBB0_16:
	mov	rax, rcx
	pop	rsi
	ret
	.seh_endproc
                                        # -- End function
	.def	"?old_xor@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z";
	.scl	2;
	.type	32;
	.endef
	.globl	"?old_xor@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z" # -- Begin function ?old_xor@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z
	.p2align	4, 0x90
"?old_xor@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z": # @"?old_xor@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z"
.seh_proc "?old_xor@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z"
# %bb.0:
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbp
	.seh_pushreg rbp
	push	rbx
	.seh_pushreg rbx
	push	rax
	.seh_stackalloc 8
	.seh_endprologue
	mov	rax, qword ptr [rcx + 8]
	sub	rax, qword ptr [rcx]
	sar	rax, 2
	mov	qword ptr [rsp], rax            # 8-byte Spill
	cmp	rax, 2
	jb	.LBB1_6
# %bb.1:
	mov	edx, 1
	jmp	.LBB1_2
	.p2align	4, 0x90
.LBB1_5:                                #   in Loop: Header=BB1_2 Depth=1
	mov	rdx, r8
	cmp	r8, qword ptr [rsp]             # 8-byte Folded Reload
	jae	.LBB1_6
.LBB1_2:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB1_3 Depth 2
                                        #       Child Loop BB1_7 Depth 3
	lea	r8, [rdx + rdx]
	lea	r9, [8*rdx]
	xor	r10d, r10d
	mov	r11, rdx
	xor	esi, esi
	jmp	.LBB1_3
	.p2align	4, 0x90
.LBB1_4:                                #   in Loop: Header=BB1_3 Depth=2
	add	rsi, r8
	add	r11, r8
	add	r10, r9
	cmp	rsi, qword ptr [rsp]            # 8-byte Folded Reload
	jae	.LBB1_5
.LBB1_3:                                #   Parent Loop BB1_2 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB1_7 Depth 3
	lea	r15, [rsi + rdx]
	mov	rdi, r10
	mov	rbx, r11
	mov	r14, rdx
	cmp	rsi, r15
	jae	.LBB1_4
	.p2align	4, 0x90
.LBB1_7:                                #   Parent Loop BB1_2 Depth=1
                                        #     Parent Loop BB1_3 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	mov	r15, qword ptr [rcx]
	mov	r12d, dword ptr [r15 + rdi]
	mov	r13d, dword ptr [r15 + 4*rbx]
	lea	eax, [r12 + r13]
	mov	ebp, eax
	sub	ebp, 998244353
	cmovb	ebp, eax
	mov	dword ptr [r15 + rdi], ebp
	sub	r12d, r13d
	lea	eax, [r12 + 998244353]
	cmp	r12d, 998244353
	cmovb	eax, r12d
	mov	r15, qword ptr [rcx]
	mov	dword ptr [r15 + 4*rbx], eax
	inc	rbx
	add	rdi, 4
	dec	r14
	jne	.LBB1_7
	jmp	.LBB1_4
.LBB1_6:
	add	rsp, 8
	pop	rbx
	pop	rbp
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	ret
	.seh_endproc
                                        # -- End function
	.def	"?new_xor@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z";
	.scl	2;
	.type	32;
	.endef
	.globl	"?new_xor@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z" # -- Begin function ?new_xor@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z
	.p2align	4, 0x90
"?new_xor@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z": # @"?new_xor@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z"
# %bb.0:
	jmp	"??$transform@$01$0A@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@bitwise_convolution_detail@candidate@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z" # TAILCALL
                                        # -- End function
	.def	"??$transform@$01$0A@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@bitwise_convolution_detail@candidate@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z";
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,"??$transform@$01$0A@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@bitwise_convolution_detail@candidate@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z"
	.globl	"??$transform@$01$0A@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@bitwise_convolution_detail@candidate@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z" # -- Begin function ??$transform@$01$0A@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@bitwise_convolution_detail@candidate@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z
	.p2align	4, 0x90
"??$transform@$01$0A@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@bitwise_convolution_detail@candidate@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z": # @"??$transform@$01$0A@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@bitwise_convolution_detail@candidate@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z"
.seh_proc "??$transform@$01$0A@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@bitwise_convolution_detail@candidate@@YAXAEAV?$vector@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@V?$allocator@U?$static_modint@$0DLIAAAAB@$0A@@atcoder@@@std@@@std@@@Z"
# %bb.0:
	push	r15
	.seh_pushreg r15
	push	r14
	.seh_pushreg r14
	push	r13
	.seh_pushreg r13
	push	r12
	.seh_pushreg r12
	push	rsi
	.seh_pushreg rsi
	push	rdi
	.seh_pushreg rdi
	push	rbp
	.seh_pushreg rbp
	push	rbx
	.seh_pushreg rbx
	sub	rsp, 40
	.seh_stackalloc 40
	.seh_endprologue
	mov	rax, qword ptr [rcx + 8]
	sub	rax, qword ptr [rcx]
	sar	rax, 2
	mov	edx, 1
	mov	qword ptr [rsp], rax            # 8-byte Spill
	cmp	rax, 4
	jae	.LBB3_1
.LBB3_6:
	cmp	rdx, qword ptr [rsp]            # 8-byte Folded Reload
	jae	.LBB3_10
# %bb.7:
	lea	r8, [rdx + rdx]
	lea	r9, [8*rdx]
	xor	r10d, r10d
	mov	r11, rdx
	xor	esi, esi
	jmp	.LBB3_8
	.p2align	4, 0x90
.LBB3_9:                                #   in Loop: Header=BB3_8 Depth=1
	add	rsi, r8
	add	r11, r8
	add	r10, r9
	cmp	rsi, qword ptr [rsp]            # 8-byte Folded Reload
	jae	.LBB3_10
.LBB3_8:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_12 Depth 2
	lea	rax, [rsi + rdx]
	mov	rdi, r10
	mov	rbx, r11
	mov	r14, rdx
	cmp	rsi, rax
	jae	.LBB3_9
	.p2align	4, 0x90
.LBB3_12:                               #   Parent Loop BB3_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	mov	rax, qword ptr [rcx]
	mov	r15d, dword ptr [rax + rdi]
	mov	r12d, dword ptr [rax + 4*rbx]
	lea	ebp, [r12 + r15]
	mov	r13d, ebp
	sub	r13d, 998244353
	cmovb	r13d, ebp
	mov	dword ptr [rax + rdi], r13d
	sub	r15d, r12d
	lea	eax, [r15 + 998244353]
	cmp	r15d, 998244353
	cmovb	eax, r15d
	mov	r15, qword ptr [rcx]
	mov	dword ptr [r15 + 4*rbx], eax
	inc	rbx
	add	rdi, 4
	dec	r14
	jne	.LBB3_12
	jmp	.LBB3_9
.LBB3_10:
	add	rsp, 40
	pop	rbx
	pop	rbp
	pop	rdi
	pop	rsi
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	ret
.LBB3_1:
	mov	rax, qword ptr [rsp]            # 8-byte Reload
	shr	rax, 2
	mov	qword ptr [rsp + 8], rax        # 8-byte Spill
	mov	r15d, 1
	jmp	.LBB3_2
	.p2align	4, 0x90
.LBB3_5:                                #   in Loop: Header=BB3_2 Depth=1
	mov	r15, rdx
	cmp	rdx, qword ptr [rsp + 8]        # 8-byte Folded Reload
	ja	.LBB3_6
.LBB3_2:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_3 Depth 2
                                        #       Child Loop BB3_11 Depth 3
	lea	rdx, [4*r15]
	lea	r10, [rdx + 2*rdx]
	mov	rax, r15
	shl	rax, 4
	mov	qword ptr [rsp + 16], rax       # 8-byte Spill
	lea	rsi, [8*r15]
	xor	r14d, r14d
	xor	ebx, ebx
	mov	qword ptr [rsp + 24], r15       # 8-byte Spill
	jmp	.LBB3_3
	.p2align	4, 0x90
.LBB3_4:                                #   in Loop: Header=BB3_3 Depth=2
	add	rbx, rdx
	mov	r14, qword ptr [rsp + 32]       # 8-byte Reload
	add	r14, qword ptr [rsp + 16]       # 8-byte Folded Reload
	cmp	rbx, qword ptr [rsp]            # 8-byte Folded Reload
	mov	r15, qword ptr [rsp + 24]       # 8-byte Reload
	jae	.LBB3_5
.LBB3_3:                                #   Parent Loop BB3_2 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB3_11 Depth 3
	lea	r8, [rbx + r15]
	mov	qword ptr [rsp + 32], r14       # 8-byte Spill
	cmp	rbx, r8
	jae	.LBB3_4
	.p2align	4, 0x90
.LBB3_11:                               #   Parent Loop BB3_2 Depth=1
                                        #     Parent Loop BB3_3 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	mov	rbp, qword ptr [rcx]
	lea	r12, [r14 + rbp]
	mov	eax, dword ptr [rbp + r14]
	mov	r13d, dword ptr [rdx + r12]
	lea	r11d, [rax + r13]
	mov	r8d, r11d
	sub	r8d, 998244353
	cmovb	r8d, r11d
	sub	eax, r13d
	lea	r13d, [rax + 998244353]
	cmp	eax, 998244353
	cmovb	r13d, eax
	mov	eax, dword ptr [rsi + r12]
	mov	r11d, dword ptr [r10 + r12]
	lea	r9d, [r11 + rax]
	mov	edi, r9d
	sub	edi, 998244353
	cmovb	edi, r9d
	sub	eax, r11d
	lea	r9d, [rax + 998244353]
	cmp	eax, 998244353
	cmovb	r9d, eax
	lea	eax, [rdi + r8]
	mov	r11d, eax
	sub	r11d, 998244353
	cmovb	r11d, eax
	sub	r8d, edi
	lea	eax, [r8 + 998244353]
	cmp	r8d, 998244353
	cmovb	eax, r8d
	mov	dword ptr [rbp + r14], r11d
	mov	dword ptr [rsi + r12], eax
	lea	eax, [r9 + r13]
	mov	r8d, eax
	sub	r8d, 998244353
	cmovb	r8d, eax
	sub	r13d, r9d
	lea	eax, [r13 + 998244353]
	cmp	r13d, 998244353
	cmovb	eax, r13d
	mov	dword ptr [rdx + r12], r8d
	mov	dword ptr [r10 + r12], eax
	add	r14, 4
	dec	r15
	jne	.LBB3_11
	jmp	.LBB3_4
	.seh_endproc
                                        # -- End function
	.section	.drectve,"yni"
	.ascii	" /FAILIFMISMATCH:\"_MSC_VER=1900\""
	.ascii	" /FAILIFMISMATCH:\"_ITERATOR_DEBUG_LEVEL=0\""
	.ascii	" /FAILIFMISMATCH:\"RuntimeLibrary=MT_StaticRelease\""
	.ascii	" /DEFAULTLIB:libcpmt.lib"
	.ascii	" /FAILIFMISMATCH:\"_CRT_STDIO_ISO_WIDE_SPECIFIERS=0\""
	.ascii	" /FAILIFMISMATCH:\"annotate_string=0\""
	.ascii	" /FAILIFMISMATCH:\"annotate_vector=0\""
	.addrsig
