#pragma once
#include <bit>
#include <cassert>
#include <cstddef>
#include <vector>
#include <cstdint>
#include <limits>
#include <type_traits>
#include <utility>
#if __has_include(<atcoder/modint>)
#include <atcoder/modint>
#define BLUEBERRY_BITWISE_ACL_AVAILABLE 1
#endif

namespace blueberry {
namespace bitwise_convolution_detail {
template <int Kind, bool Inverse, class T>
void transform(std::vector<T>& a) {
  const std::size_t n = a.size();
  std::size_t half = 1;
  for (; half <= n / 4; half *= 4) {
    for (std::size_t start = 0; start < n; start += half * 4) {
      for (std::size_t j = start; j < start + half; ++j) {
        auto &x0 = a[j], &x1 = a[j + half], &x2 = a[j + half * 2], &x3 = a[j + half * 3];
        if constexpr (Kind == 0) {
          if constexpr (Inverse) { x0 -= x1; x2 -= x3; x0 -= x2; x1 -= x3; }
          else { x0 += x1; x2 += x3; x0 += x2; x1 += x3; }
        } else if constexpr (Kind == 1) {
          if constexpr (Inverse) { x1 -= x0; x3 -= x2; x2 -= x0; x3 -= x1; }
          else { x1 += x0; x3 += x2; x2 += x0; x3 += x1; }
        } else {
          T a0 = x0 + x1, a1 = x0 - x1, a2 = x2 + x3, a3 = x2 - x3;
          x0 = a0 + a2; x2 = a0 - a2; x1 = a1 + a3; x3 = a1 - a3;
        }
      }
    }
  }
  if (half < n) for (std::size_t start = 0; start < n; start += half * 2) {
    for (std::size_t j = start; j < start + half; ++j) {
      if constexpr (Kind == 0) { if constexpr (Inverse) a[j] -= a[j + half]; else a[j] += a[j + half]; }
      else if constexpr (Kind == 1) { if constexpr (Inverse) a[j + half] -= a[j]; else a[j + half] += a[j]; }
      else { T x = a[j], y = a[j + half]; a[j] = x + y; a[j + half] = x - y; }
    }
  }
}
template<class T> struct acl_static_modint : std::false_type {};
#ifdef BLUEBERRY_BITWISE_ACL_AVAILABLE
template<int Mod, std::enable_if_t<(1 <= Mod)>* P>
struct acl_static_modint<atcoder::static_modint<Mod, P>> : std::true_type {};
#endif
template<class T>
std::vector<T> fast_xor(std::vector<T> a, const std::vector<T>& b) {
  const int mod=T::mod(); const std::size_t n=a.size();
  std::vector<std::int64_t> x(n),y(n);
  for(std::size_t i=0;i<n;++i){x[i]=a[i].val();y[i]=b[i].val();}
  transform<2,false>(x);transform<2,false>(y);
  for(std::size_t i=0;i<n;++i) {
    auto p=x[i]%mod,q=y[i]%mod;
    if(p<0)p+=mod;if(q<0)q+=mod;
    x[i]=(p*q)%mod;
  }
  transform<2,false>(x);
  auto inv=(T(1)/T(n)).val();
  for(std::size_t i=0;i<n;++i) {
    auto p=x[i]%mod;if(p<0)p+=mod;
    a[i]=T::raw(static_cast<int>((p*inv)%mod));
  }
  return a;
}
template <class T> void check(const std::vector<T>& a, const std::vector<T>& b) {
  assert(a.size() == b.size() && (a.empty() || std::has_single_bit(a.size())));
  (void)a; (void)b;
}
}
template <class T> std::vector<T> bitwise_convolution_and(std::vector<T> a, std::vector<T> b) {
  bitwise_convolution_detail::check(a, b);
  bitwise_convolution_detail::transform<0, false>(a);
  bitwise_convolution_detail::transform<0, false>(b);
  for (std::size_t i = 0; i < a.size(); ++i) a[i] *= b[i];
  bitwise_convolution_detail::transform<0, true>(a);
  return a;
}
template <class T> std::vector<T> bitwise_convolution_or(std::vector<T> a, std::vector<T> b) {
  bitwise_convolution_detail::check(a, b);
  bitwise_convolution_detail::transform<1, false>(a);
  bitwise_convolution_detail::transform<1, false>(b);
  for (std::size_t i = 0; i < a.size(); ++i) a[i] *= b[i];
  bitwise_convolution_detail::transform<1, true>(a);
  return a;
}
template <class T> std::vector<T> bitwise_convolution_xor(std::vector<T> a, std::vector<T> b) {
  bitwise_convolution_detail::check(a, b);
  if (a.empty()) return {};
  if constexpr (bitwise_convolution_detail::acl_static_modint<T>::value) {
    if (a.size() >= 256 && T::mod() > 1 && a.size() <= std::size_t(std::numeric_limits<std::int64_t>::max() / (T::mod() - 1)))
      return bitwise_convolution_detail::fast_xor(std::move(a), b);
  }
  bitwise_convolution_detail::transform<2, false>(a);
  bitwise_convolution_detail::transform<2, false>(b);
  for (std::size_t i = 0; i < a.size(); ++i) a[i] *= b[i];
  bitwise_convolution_detail::transform<2, false>(a);
  const T inverse_size = T(1) / T(a.size());
  for (T& value : a) value *= inverse_size;
  return a;
}
}

#ifdef BLUEBERRY_BITWISE_ACL_AVAILABLE
#undef BLUEBERRY_BITWISE_ACL_AVAILABLE
#endif
