#include <atcoder/modint>
#include <vector>
#define blueberry baseline
#include "baseline.hpp"
#undef blueberry
#define blueberry candidate
#include "candidate-final.hpp"
#undef blueberry
using Mint=atcoder::modint998244353;
void old_xor(std::vector<Mint>& a){baseline::bitwise_convolution_detail::transform(a,2,false);}
void new_xor(std::vector<Mint>& a){candidate::bitwise_convolution_detail::transform<2,false>(a);}
