#include <atcoder/modint>
#include <vector>
#define blueberry baseline
#include "baseline.hpp"
#undef blueberry
#define blueberry candidate
#include "candidate-split.hpp"
#undef blueberry
using Mint=atcoder::modint998244353;
void old_or(std::vector<Mint>& a){baseline::bitwise_convolution_detail::transform(a,1,false);}
void new_or(std::vector<Mint>& a){candidate::bitwise_convolution_detail::transform(a,1,false);}
