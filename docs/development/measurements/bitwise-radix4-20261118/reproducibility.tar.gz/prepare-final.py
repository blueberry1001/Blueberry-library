from pathlib import Path
p=Path(__file__).parent
s=(p/'candidate.hpp').read_text().replace('#include <vector>', '#include <vector>\n#include <type_traits>')
needle='  const std::size_t n = a.size();\n  std::size_t half = 1;'
replacement='''  const std::size_t n = a.size();
  if constexpr (Kind != 2 && (std::is_integral_v<T> || sizeof(T) > 4)) {
    for (std::size_t half = 1; half < n; half <<= 1)
      for (std::size_t start = 0; start < n; start += half * 2)
        for (std::size_t j = start; j < start + half; ++j) {
          if constexpr (Kind == 0) { if constexpr (Inverse) a[j] -= a[j + half]; else a[j] += a[j + half]; }
          else { if constexpr (Inverse) a[j + half] -= a[j]; else a[j + half] += a[j]; }
        }
    return;
  }
  std::size_t half = 1;'''
if needle not in s:raise RuntimeError('needle missing')
s=s.replace(needle,replacement).replace('#include <bit>\n#include <cassert>\n','')
check='''template <class T> void check(const std::vector<T>& a, const std::vector<T>& b) {
  assert(a.size() == b.size() && (a.empty() || std::has_single_bit(a.size())));
  (void)a; (void)b;
}
'''
if check not in s:raise RuntimeError('check missing')
s=s.replace(check,'').replace('  bitwise_convolution_detail::check(a, b);\n','')
(p/'candidate-final.hpp').write_text(s,encoding='utf-8',newline='\n')
