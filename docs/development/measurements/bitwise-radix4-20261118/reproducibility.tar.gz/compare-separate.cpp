#include <atcoder/modint>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>
#if VERSION == 0
#include "baseline.hpp"
#elif VERSION == 1
#include "candidate-final.hpp"
#elif VERSION == 2
#include "candidate-xor.hpp"
#else
#include "candidate-msvc.hpp"
#endif
template<class T> std::uint64_t get(const T& x) { return x.val(); }
template<> std::uint64_t get(const std::uint64_t& x) { return x; }
template<> std::uint64_t get(const std::uint32_t& x) { return x; }
template<class T> int run(int,int kind,int bits,int repeats) {
  std::size_t n=std::size_t(1)<<bits;std::vector<T>a(n),b(n);std::uint64_t x=7251231;
  for(std::size_t i=0;i<n;++i){x^=x<<7;x^=x>>9;a[i]=T(x);x^=x<<7;x^=x>>9;b[i]=T(x);}
  std::uint64_t sum=0;auto start=std::chrono::steady_clock::now();
  for(int rep=0;rep<repeats;++rep) {
    std::vector<T> c;
    if(kind==0)c=blueberry::bitwise_convolution_and(a,b);
    else if(kind==1)c=blueberry::bitwise_convolution_or(a,b);
    else if constexpr(!std::is_integral_v<T>)c=blueberry::bitwise_convolution_xor(a,b);
    for(std::size_t j=0;j<c.size();++j) sum=sum*0x9e3779b97f4a7c15ULL+get(c[j]);
  }
  auto end=std::chrono::steady_clock::now();std::printf("%.4f %llu\n",std::chrono::duration<double,std::milli>(end-start).count(),(unsigned long long)sum);return 0;
}
int main(int argc,char**argv){if(argc!=6)return 1;int v=std::atoi(argv[1]),k=std::atoi(argv[2]),t=std::atoi(argv[3]),bits=std::atoi(argv[4]),reps=std::atoi(argv[5]);if(t==0)return run<atcoder::modint998244353>(v,k,bits,reps);if(t==1)return run<std::uint64_t>(v,k,bits,reps);return run<std::uint32_t>(v,k,bits,reps);}
