import gzip,hashlib,io,pathlib,tarfile
p=pathlib.Path(__file__).resolve().parent
files=[]
for f in p.iterdir():
 if f.is_file() and f.suffix in ('.py','.cpp','.hpp','.json','.s','.txt'):
  files.append(f)
for f in [p/'delivery/blueberry/math/bitwise-convolution.hpp',p/'delivery/tests/random/bitwise-radix4.cpp']:
 files.append(f)
items={f.relative_to(p).as_posix():f.read_bytes() for f in files}
items['SHA256SUMS']=''.join(hashlib.sha256(v).hexdigest()+'  '+k+'\n' for k,v in sorted(items.items())).encode()
out=p/'delivery/docs/development/measurements/bitwise-radix4-20261118/reproducibility.tar.gz'
with out.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as archive:
   for name,data in sorted(items.items()):
    t=tarfile.TarInfo(name);t.size=len(data);t.mtime=0;t.mode=0o644;t.uid=t.gid=0;t.uname=t.gname='';archive.addfile(t,io.BytesIO(data))
with tarfile.open(out,'r:gz') as archive:
 for name,data in items.items():
  assert archive.extractfile(name).read()==data,name
(out.parent/'archive.sha256').write_text(hashlib.sha256(out.read_bytes()).hexdigest()+'  reproducibility.tar.gz\n')
print(len(items),'entries',out.stat().st_size,'bytes')
