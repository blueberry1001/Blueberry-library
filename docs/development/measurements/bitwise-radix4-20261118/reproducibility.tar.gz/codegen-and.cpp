#include <atcoder/modint>
#include <vector>
#define blueberry baseline
#include "baseline.hpp"
#undef blueberry
#define blueberry candidate
#include "candidate-split.hpp"
#undef blueberry
using Mint=atcoder::modint998244353;
void old_and(std::vector<Mint>& a){baseline::bitwise_convolution_detail::transform(a,0,false);}
void new_and(std::vector<Mint>& a){candidate::bitwise_convolution_detail::transform(a,0,false);}
