from pathlib import Path
p=Path(__file__).parent
s=(p/'compare-final.cpp').read_text()
i=s.index('#define blueberry baseline');j=s.index('template<class T> std::uint64_t get')
s=s[:i]+'''#if VERSION == 0
#include "baseline.hpp"
#elif VERSION == 1
#include "candidate-final.hpp"
#elif VERSION == 2
#include "candidate-xor.hpp"
#else
#include "candidate-msvc.hpp"
#endif
'''+s[j:]
i=s.index('    if(kind==0)c=');j=s.index('    for(std::size_t j=0;',i)
s=s[:i]+'''    if(kind==0)c=blueberry::bitwise_convolution_and(a,b);
    else if(kind==1)c=blueberry::bitwise_convolution_or(a,b);
    else if constexpr(!std::is_integral_v<T>)c=blueberry::bitwise_convolution_xor(a,b);
'''+s[j:]
s=s.replace('int version,int kind,int bits,int repeats','int,int kind,int bits,int repeats')
(p/'compare-separate.cpp').write_text(s,encoding='utf-8',newline='\n')
