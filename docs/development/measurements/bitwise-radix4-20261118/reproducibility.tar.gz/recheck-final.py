import ctypes,json,pathlib,subprocess
p=pathlib.Path(__file__).parent
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<16)
out=[]
for kind in (0,1,2):
 for s in range(-1,11):
  for ver in ((0,1) if s%2 else (1,0)):
   cmd=[str(p/'clang-final.exe'),str(ver),str(kind),'0','20','4'];r=subprocess.run(cmd,cwd=p,capture_output=True,text=True,timeout=180);out.append({'cmd':cmd,'kind':kind,'sample':s,'ver':ver,'exit':r.returncode,'out':r.stdout,'err':r.stderr});(p/'recheck-final.json').write_text(json.dumps(out,indent=2)+'\n');
   if r.returncode:raise SystemExit(r.returncode)
