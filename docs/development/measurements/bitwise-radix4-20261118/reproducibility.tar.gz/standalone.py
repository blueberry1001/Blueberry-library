import json,os,pathlib,subprocess
p=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10');v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/x for x in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/x/'x64' for x in ('ucrt','um'))]))
results=[]
for cc in ('clang','msvc'):
 exe=p/('standalone-'+cc+'.exe')
 cmd=([str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-Wall','-Wextra','-Wshadow','-Werror',str(p/'standalone.cpp'),'-o',str(exe)] if cc=='clang' else [str(vc/'bin/Hostx64/x64/cl.exe'),'/nologo','/std:c++20','/O2','/EHsc',str(p/'standalone.cpp'),'/Fe:'+str(exe)])
 for cmd0 in (cmd,[str(exe)]):
  r=subprocess.run(cmd0,cwd=p,env=env,capture_output=True,text=True,errors='replace');results.append({'cmd':cmd0,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(p/'standalone.json').write_text(json.dumps(results,indent=2)+'\n');
  if r.returncode:raise SystemExit(r.returncode)
