from pathlib import Path
p=Path(__file__).parent
s=(p/'compare.cpp').read_text()
start=s.index('#define blueberry candidate\n');end=s.index('template<class T> std::uint64_t get')
s=s[:start]+'''#define blueberry candidate
#include "candidate-final.hpp"
#undef blueberry
'''+s[end:]
start=s.index('    if(kind==0)c=');end=s.index('    for(std::size_t j=0;',start)
s=s[:start]+'''    if(kind==0)c=version?candidate::bitwise_convolution_and(a,b):baseline::bitwise_convolution_and(a,b);
    else if(kind==1)c=version?candidate::bitwise_convolution_or(a,b):baseline::bitwise_convolution_or(a,b);
    else if constexpr(!std::is_integral_v<T>)c=version?candidate::bitwise_convolution_xor(a,b):baseline::bitwise_convolution_xor(a,b);
'''+s[end:]
(p/'compare-final.cpp').write_text(s,encoding='utf-8',newline='\n')
s=(p/'run.py').read_text().replace("p/'results.json'","p/'results-final.json'").replace("p/(cc+'.exe')","p/(cc+'-final.exe')").replace("p/'compare.cpp'","p/'compare-final.cpp'").replace('((0,4) if sample%2 else (4,0))','((0,1) if sample%2 else (1,0))')
(p/'run-final.py').write_text(s,encoding='utf-8',newline='\n')
