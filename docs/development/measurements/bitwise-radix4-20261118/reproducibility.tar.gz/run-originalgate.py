import ctypes,json,os,pathlib,platform,subprocess,traceback
p=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10');v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe');acl=p.parent/'speed-snapshot-20261117'/'.deps'/'ac-library'
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/x for x in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/x/'x64' for x in ('ucrt','um'))]))
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<16)
d={'status':'running','platform':platform.platform(),'processor':platform.processor(),'affinity':'0x10000','runs':[]}
def save(): (p/'results-originalgate.json').write_text(json.dumps(d,indent=2)+'\n')
def call(cmd):
 r=subprocess.run(cmd,cwd=p,env=env,capture_output=True,text=True,errors='replace',timeout=180);v={'cmd':list(map(str,cmd)),'exit':r.returncode,'out':r.stdout,'err':r.stderr};d['runs'].append(v);save()
 if r.returncode:raise RuntimeError('command failed')
 return v
try:
 for cc in ('clang','msvc'):
  src=p/'compare-originalgate.cpp'
  for ver in (0,3,4):
   exe=p/(cc+'-og-'+str(ver)+'.exe')
   cmd=([str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG','-DVERSION='+str(ver),'-isystem',str(acl),str(src),'-o',str(exe)] if cc=='clang' else [str(vc/'bin/Hostx64/x64/cl.exe'),'/nologo','/std:c++20','/O2','/DNDEBUG','/EHsc','/DVERSION='+str(ver),'/I'+str(acl),str(src),'/Fe:'+str(exe)])
   call(cmd)
  for typ in (0,1,2):
   for kind in (range(3) if typ==0 else range(2)):
    for bits,reps in ((12,50),(16,4),(20,1)):
     for sample in range(-1,5):
      outputs=[]
      for ver in ((0,3,4) if sample%2 else (4,3,0)):
       exe=p/(cc+'-og-'+str(ver)+'.exe');o=call([str(exe),str(ver),str(kind),str(typ),str(bits),str(reps)]);o.update(cc=cc,typ=typ,kind=kind,bits=bits,reps=reps,sample=sample,ver=ver);outputs.append(o['out'].split()[1]);save()
      if len(set(outputs))!=1:raise RuntimeError('mismatching checksums')
 d['status']='complete';save()
except BaseException:
 d['status']='failed';d['traceback']=traceback.format_exc();save();raise
