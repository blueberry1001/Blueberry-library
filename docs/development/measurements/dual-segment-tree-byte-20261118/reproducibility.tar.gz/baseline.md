---
title: Dual Segment Tree
documentation_of: //blueberry/data-structure/dual-segment-tree.hpp
---

[カテゴリへ戻る]({{ '/categories/data-structure.html' | relative_url }})

## 概要

範囲作用と一点取得に特化した `DualSegmentTree<S, F, mapping, composition, id>` です。区間集約のop/eは不要です。`mapping(f,x)` は値への作用、`composition(f,g)` は **gの後にf**、`id()` は恒等作用です。合成は結合的でmappingと整合し、可換性は不要です。

Nは要素数。構築・メモリはO(N)、範囲作用・一点操作は最悪O(log(N+1))。空入力・空区間に対応します。

## 操作一覧

| 操作 | 計算量 |
| --- | --- |
| [`DualSegmentTree`](#default) | O(1) |
| [`DualSegmentTree`](#vector) | O(N) |
| [`DualSegmentTree`](#fill) | O(N) |
| [`size`](#size) | O(1) |
| [`S`](#get) | O(log(N+1)) |
| [`set`](#set) | O(log(N+1)) |
| [`apply`](#point-apply) | O(log(N+1)) |
| [`apply`](#range-apply) | O(log(N+1)) |
| [`get_all`](#get-all) | O(N) |

<details class="extra-operations" markdown="1">
<summary>その他の操作・型</summary>

| 操作 | 計算量 |
| --- | --- |
| [`DualSegmentTree`](#copy-constructor) | O(N) |
| [`operator=`](#copy-assignment) | O(N + M) |
| [`DualSegmentTree`](#move-constructor) | O(1) |
| [`operator=`](#move-assignment) | O(M) |

</details>

<!-- library-implementation -->

<details class="library-notes" markdown="1">
<summary>補足・制約</summary>

## 概要・前提 {#概要前提}

- ACL lazy_segtreeと異なり、葉の値と作用だけを保持します。Fの等値比較は不要です。
- S/Fはコピー可能、既定構築は不要です。`N <= INT_MAX`。数値演算のオーバーフローは利用側で防いでください。
- getは遅延作用を伝播するため非constです。get_allも内部状態を更新しますが、返す値・配列は独立したコピーです。
- コピーした木は独立し、ムーブ元は長さ0で再利用できます。

## 操作の補足 {#操作の補足}

- Mはコピー・結合相手または置換前の保持量です。
- 型のコピー・演算・比較をO(1)とします。

</details>

## 最小使用例

{% raw %}
```cpp
#include <cassert>
#include <vector>
#include "blueberry/data-structure/dual-segment-tree.hpp"
struct F { long long a, b; };
long long mapping(F f, long long x) { return f.a * x + f.b; }
F composition(F f, F g) { return {f.a * g.a, f.a * g.b + f.b}; }
F id() { return {1, 0}; }
int main() {
  blueberry::DualSegmentTree<long long, F, mapping, composition, id> tree(std::vector<long long>{1, 2, 3});
  tree.apply(0, 3, F{2, 1});
  tree.apply(1, 3, F{3, 0});
  assert(tree.get(0) == 3 && tree.get(1) == 15);
  tree.set(2, 9);
  assert((tree.get_all() == std::vector<long long>{3, 15, 9}));
}
```
{% endraw %}

<details class="api-operation" id="default" markdown="1">
<summary><code>DualSegmentTree()</code> — O(1)</summary>

長さ0の木を作る。

{% raw %}
```cpp
using Tree = blueberry::DualSegmentTree<long long, F, mapping, composition, id>;
Tree tree;
```
{% endraw %}

注意点: get/set の有効な添字はない。

</details>

<details class="api-operation" id="vector" markdown="1">
<summary><code>DualSegmentTree(const std::vector&lt;S&gt;&amp; values)</code> — O(N)</summary>

入力をコピーして構築。

{% raw %}
```cpp
Tree tree(std::vector<S>{1, 2, 3});
```
{% endraw %}

注意点: 空入力も有効。入力の寿命には依存しない。

</details>

<details class="api-operation" id="fill" markdown="1">
<summary><code>DualSegmentTree(int n, const S&amp; value)</code> — O(N)</summary>

全 n 要素が value の木。

{% raw %}
```cpp
Tree tree(10, S(0));
```
{% endraw %}

注意点: 0 <= n <= INT_MAX。

</details>

<details class="api-operation" id="copy-constructor" markdown="1">
<summary><code>DualSegmentTree(const DualSegmentTree&amp; other)</code> — O(N)</summary>

内容を複製する。更新は互いに独立。

{% raw %}
```cpp
DualSegmentTree copy(tree);
```
{% endraw %}

注意点: 空状態のコピーも可能。

</details>

<details class="api-operation" id="copy-assignment" markdown="1">
<summary><code>DualSegmentTree&amp; operator=(const DualSegmentTree&amp; other)</code> — O(N + M)</summary>

代入元 N 要素で置換し、自身への参照を返す。M は置換前の保持量。

{% raw %}
```cpp
copy = tree;
```
{% endraw %}

注意点: 自己代入は内容を保つ。返された参照は代入先が生存する間有効。

</details>

<details class="api-operation" id="move-constructor" markdown="1">
<summary><code>DualSegmentTree(DualSegmentTree&amp;&amp; other)</code> — O(1)</summary>

所有権を移し、元を空状態にする。

{% raw %}
```cpp
DualSegmentTree moved(std::move(tree));
```
{% endraw %}

注意点: <utility> が必要。空状態の意味は概要を参照。

</details>

<details class="api-operation" id="move-assignment" markdown="1">
<summary><code>DualSegmentTree&amp; operator=(DualSegmentTree&amp;&amp; other)</code> — O(M)</summary>

古い保持要素 M 個の破棄を含めて置換し、自身への参照を返す。

{% raw %}
```cpp
moved = std::move(tree);
```
{% endraw %}

注意点: 自己ムーブ代入は内容を保つ。元は空になる。参照の寿命は代入先の寿命と同じ。

</details>

<details class="api-operation" id="size" markdown="1">
<summary><code>int size() const</code> — O(1)</summary>

元配列の長さを返す。

{% raw %}
```cpp
int n = tree.size();
```
{% endraw %}

注意点: 内部のパディングは含まない。

</details>

<details class="api-operation" id="get" markdown="1">
<summary><code>S get(int p)</code> — O(log(N+1))</summary>

p の現在値をコピーして返す。

{% raw %}
```cpp
auto value = tree.get(0);
```
{% endraw %}

注意点: 0 <= p < N。遅延作用を内部で伝播する。

</details>

<details class="api-operation" id="set" markdown="1">
<summary><code>void set(int p, const S&amp; value)</code> — O(log(N+1))</summary>

p を value で代入する。

{% raw %}
```cpp
tree.set(0, S(5));
```
{% endraw %}

注意点: 0 <= p < N。過去の作用を伝播してから置換する。

</details>

<details class="api-operation" id="point-apply" markdown="1">
<summary><code>void apply(int p, const F&amp; f)</code> — O(log(N+1))</summary>

p の現在値に f を作用させる。

{% raw %}
```cpp
tree.apply(0, F{2, 1});
```
{% endraw %}

注意点: 0 <= p < N。呼出順を保つ。

</details>

<details class="api-operation" id="range-apply" markdown="1">
<summary><code>void apply(int l, int r, const F&amp; f)</code> — O(log(N+1))</summary>

半開区間 [l,r) に f を作用させる。

{% raw %}
```cpp
tree.apply(0, tree.size(), F{2, 1});
```
{% endraw %}

注意点: 0 <= l <= r <= N。空区間は何もしない。非可換な作用でも時系列順に合成する。

</details>

<details class="api-operation" id="get-all" markdown="1">
<summary><code>std::vector&lt;S&gt; get_all()</code> — O(N)</summary>

すべての遅延作用を伝播し、現在値をコピーして返す。

{% raw %}
```cpp
auto values = tree.get_all();
```
{% endraw %}

注意点: 空なら空vector。返したvectorの変更は木に影響しない。

</details>

<details class="library-notes" markdown="1">
<summary>出典・検証</summary>

## 出典・検証 {#出典検証}

- [maspypy Dual SegTree](https://maspypy.github.io/library/ds/segtree/dual_segtree.hpp) を設計比較資料とし独立実装。
- Library Checker [Range Affine Point Get](https://judge.yosupo.jp/problem/range_affine_point_get)。
- `tests/random/specialized-structures.cpp` で非可換 affine 作用・一点代入・空区間を愚直配列と比較。

</details>
