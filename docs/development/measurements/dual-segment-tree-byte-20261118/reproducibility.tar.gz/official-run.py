import ctypes,hashlib,json,os,pathlib,subprocess,time,traceback
p=pathlib.Path(__file__).resolve().parent;lc=p/'official'
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10');v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
acl=p.parent/'speed-snapshot-20261117'/'.deps'/'ac-library';env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/x for x in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/x/'x64' for x in ('ucrt','um'))]))
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<12)
sha=lambda s:hashlib.sha256(s.replace(b'\r\n',b'\n')).hexdigest()
official=json.loads((lc/'hash.json').read_text());d={'status':'running','revision':'73876f1cbcf082d2b22722924b924d3d65a2f00e','calls':[],'cases':[]}
def save():(p/'official-results.json').write_text(json.dumps(d,indent=2)+'\n')
def call(cmd, data=None):
 t=time.perf_counter();r=subprocess.run(cmd,cwd=p,env=env,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180);d['calls'].append({'cmd':list(map(str,cmd)),'exit':r.returncode,'elapsed':time.perf_counter()-t,'stderr':r.stderr.decode(errors='replace')});save()
 if r.returncode:raise RuntimeError('command failed')
 return r.stdout
try:
 common=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2']
 for name in ('max_random','random','small','small_random'):
  call(common+['-I'+str(lc),str(lc/'gen'/f'{name}.cpp'),'-o',str(p/f'gen-{name}.exe')])
 for version,define in [('baseline','BASELINE'),('byte','BYTE'),('peek','USE_PEEK')]:
  call(common+['-DNDEBUG','-D'+define,'-isystem',str(acl),str(p/'official-solve.cpp'),'-o',str(p/f'official-{version}.exe')])
 for name,count in [('example',1),('small_random',2),('small',10),('random',3),('max_random',3)]:
  for seed in range(count):
   case=f'{name}_{seed:02d}'
   raw=(lc/'gen'/'example_00.in').read_bytes() if name=='example' else call([str(p/f'gen-{name}.exe'),str(seed)])
   if sha(raw)!=official[case+'.in']:raise RuntimeError(case+' input hash mismatch '+sha(raw))
   row={'case':case,'input_sha256':sha(raw),'output_sha256':{}}
   for version in ('baseline','byte','peek'):
    output=call([str(p/f'official-{version}.exe')],raw);row['output_sha256'][version]=sha(output)
    if sha(output)!=official[case+'.out']:raise RuntimeError(case+' output hash mismatch '+version)
   d['cases'].append(row);save();print(case,flush=True)
 for seed in range(3):
  raw=call([str(p/'gen-max_random.exe'),str(seed)])
  for repeat in range(3):
   for version in (('baseline','byte','peek') if repeat!=1 else ('peek','byte','baseline')):
    output=call([str(p/f'official-{version}.exe')],raw)
    if sha(output)!=official[f'max_random_{seed:02d}.out']:raise RuntimeError('timed output mismatch')
 d['status']='complete';save()
except BaseException:
 d['status']='failed';d['traceback']=traceback.format_exc();save();raise
