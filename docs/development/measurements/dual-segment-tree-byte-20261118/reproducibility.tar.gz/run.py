import ctypes,hashlib,json,os,pathlib,platform,subprocess,time,traceback
p=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10');v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/x for x in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/x/'x64' for x in ('ucrt','um'))]))
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<12)
d={'status':'running','platform':platform.platform(),'cpu':platform.processor(),'affinity':'0x1000','sources':{},'calls':[]}
for f in ('baseline.hpp','byte.hpp','merged.hpp','dedup.hpp','bench.cpp','check.cpp','run.py'):d['sources'][f]=hashlib.sha256((p/f).read_bytes()).hexdigest()
def save():(p/'results.json').write_text(json.dumps(d,indent=2)+'\n')
def call(cmd,meta):
 t=time.perf_counter();r=subprocess.run(cmd,cwd=p,env=env,capture_output=True,text=True,errors='replace',timeout=300);x={'cmd':list(map(str,cmd)),'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'elapsed':time.perf_counter()-t,**meta};d['calls'].append(x);save()
 if r.returncode:raise RuntimeError('command failed')
 return x
try:
 for comp in ('clang','msvc'):
  for standard in ('20','23'):
   for release in (False,True):
    source=p/'check.cpp';exe=p/f'check-{comp}-{standard}-{release}.exe'
    cmd=([str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++'+standard,'-O2','-Wall','-Wextra','-Wshadow','-Werror',*(['-DNDEBUG'] if release else []),str(source),'-o',str(exe)] if comp=='clang' else [str(vc/'bin/Hostx64/x64/cl.exe'),'/nologo','/std:c++'+('latest' if standard=='23' else '20'),'/O2','/EHsc',*(['/DNDEBUG'] if release else []),str(source),'/Fo'+str(exe)+'.obj','/Fe:'+str(exe)])
    call(cmd,{'comp':comp,'standard':standard,'release':release,'kind':'build-check'});call([str(exe)],{'comp':comp,'standard':standard,'release':release,'kind':'check'})
  source=p/'bench.cpp';exe=p/f'bench-{comp}.exe'
  cmd=([str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG',str(source),'-o',str(exe)] if comp=='clang' else [str(vc/'bin/Hostx64/x64/cl.exe'),'/nologo','/std:c++20','/O2','/EHsc','/DNDEBUG',str(source),'/Fo'+str(exe)+'.obj','/Fe:'+str(exe)])
  call(cmd,{'comp':comp,'kind':'build-bench'})
  for mode in range(7):
   expected=None
   for sample in range(-1,5):
    for step in range(4):
     version=(step+sample+4)%4
     x=call([str(exe),str(version),str(mode),'262144','300000'],{'kind':'bench','comp':comp,'mode':mode,'sample':sample,'version':version})
     ans=x['stdout'].split()[1]
     if expected is None:expected=ans
     if ans!=expected:raise RuntimeError('checksum mismatch')
   print(comp,mode,flush=True)
 d['status']='complete';save()
except BaseException:
 d['status']='failed';d['traceback']=traceback.format_exc();save();raise
