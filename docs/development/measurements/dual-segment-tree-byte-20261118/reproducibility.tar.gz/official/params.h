#pragma once
constexpr int N_AND_Q_MAX = 500000;
constexpr int MOD = 998244353;
