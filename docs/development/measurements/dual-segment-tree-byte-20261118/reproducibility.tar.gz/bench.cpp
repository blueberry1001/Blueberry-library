#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <vector>
struct F { std::uint32_t a,b; };
std::uint32_t mapping(F f,std::uint32_t x){return f.a*x+f.b;}
F composition(F f,F g){return {f.a*g.a,f.a*g.b+f.b};}
F id(){return {1,0};}
#define blueberry v0
#include "baseline.hpp"
#undef blueberry
#define blueberry v1
#include "byte.hpp"
#undef blueberry
#define blueberry v2
#include "merged.hpp"
#undef blueberry
#define blueberry v3
#include "dedup.hpp"
#undef blueberry
struct Query{int l,r,typ;F f;};
template <typename T> std::uint64_t test(const std::vector<std::uint32_t>& a,const std::vector<Query>& qs) {
 T tree(a);std::uint64_t hash=0;
 for(auto q:qs)if(q.typ==0)tree.apply(q.l,q.r,q.f);else if(q.typ==1)hash=hash*1664525+tree.get(q.l);else if(q.typ==2)tree.set(q.l,q.f.b);else tree.apply(q.l,q.f);
 auto all=tree.get_all();for(auto x:all)hash=hash*1664525+x;return hash;
}
int main(int argc,char** argv){
 int ver=std::atoi(argv[1]),mode=std::atoi(argv[2]),n=std::atoi(argv[3]),q=std::atoi(argv[4]);std::mt19937 rng(714781);std::vector<std::uint32_t> a(n);for(auto& x:a)x=rng();std::vector<Query> qs;qs.reserve(q);
 for(int i=0;i<q;i++){int l=rng()%n,r=rng()%n;if(l>r)std::swap(l,r);++r;int typ=mode==0?(rng()%100<70?0:1):mode==1?(rng()%2):mode==2?0:mode==3?1:rng()%4;if(mode==5){l=rng()%n;r=std::min(n,l+int(rng()%32));}if(mode==6){l=0;r=n;}qs.push_back({l,r,typ,{std::uint32_t(rng()),std::uint32_t(rng())}});}
 using T0=v0::DualSegmentTree<std::uint32_t,F,mapping,composition,id>;using T1=v1::DualSegmentTree<std::uint32_t,F,mapping,composition,id>;using T2=v2::DualSegmentTree<std::uint32_t,F,mapping,composition,id>;using T3=v3::DualSegmentTree<std::uint32_t,F,mapping,composition,id>;
 auto start=std::chrono::steady_clock::now();std::uint64_t z=ver==0?test<T0>(a,qs):ver==1?test<T1>(a,qs):ver==2?test<T2>(a,qs):test<T3>(a,qs);double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();std::printf("%.3f %llu\n",ms,(unsigned long long)z);
}
