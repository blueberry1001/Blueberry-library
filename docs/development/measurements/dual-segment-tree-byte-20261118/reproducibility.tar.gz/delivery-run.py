import json,os,pathlib,subprocess,traceback
p=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10');v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/x for x in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/x/'x64' for x in ('ucrt','um'))]))
d={'status':'running','calls':[]}
def save():(p/'delivery-results.json').write_text(json.dumps(d,indent=2)+'\n')
def call(cmd,meta):
 r=subprocess.run(cmd,cwd=p,env=env,capture_output=True,text=True,errors='replace',timeout=300);x={'cmd':list(map(str,cmd)),'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,**meta};d['calls'].append(x);save()
 if r.returncode:raise RuntimeError('command failed')
try:
 for comp in ('clang','msvc'):
  for standard in ('20','23'):
   for release in (False,True):
    source=p/'delivery/tests/random/dual-segment-tree-byte.cpp';exe=p/f'delivery-{comp}-{standard}-{release}.exe'
    cmd=([str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++'+standard,'-O2','-Wall','-Wextra','-Wshadow','-Werror',*(['-DNDEBUG'] if release else []),'-I'+str(p/'delivery'),str(source),'-o',str(exe)] if comp=='clang' else [str(vc/'bin/Hostx64/x64/cl.exe'),'/nologo','/std:c++'+('latest' if standard=='23' else '20'),'/O2','/EHsc',*(['/DNDEBUG'] if release else []),'/I'+str(p/'delivery'),str(source),'/Fo'+str(exe)+'.obj','/Fe:'+str(exe)])
    call(cmd,{'comp':comp,'standard':standard,'release':release,'kind':'build'});call([str(exe)],{'comp':comp,'standard':standard,'release':release,'kind':'test'});print(comp,standard,release,flush=True)
 d['status']='complete';save()
except BaseException:
 d['status']='failed';d['traceback']=traceback.format_exc();save();raise
