#include <cstdint>
#include <cstdio>
#include <random>
#include <utility>
#include <vector>
struct S { std::uint32_t v; S()=delete; explicit S(std::uint32_t x):v(x){} };
struct F { std::uint32_t a,b; F()=delete; F(std::uint32_t x,std::uint32_t y):a(x),b(y){} };
S mapping(F f,S x){return S(f.a*x.v+f.b);}
F composition(F f,F g){return F(f.a*g.a,f.a*g.b+f.b);}
F id(){return F(1,0);}
#define blueberry v0
#include "baseline.hpp"
#undef blueberry
#define blueberry v1
#include "byte.hpp"
#undef blueberry
#define blueberry v2
#include "merged.hpp"
#undef blueberry
#define blueberry v3
#include "dedup.hpp"
#undef blueberry
template<class T> bool run(){
 std::mt19937 rng(732517);
 for(int n=0;n<=130;++n){
  std::vector<S>a(n,S(0));for(S& x:a)x=S(rng());T tree(a);
  for(int step=0;step<1000;++step){int l=n?rng()%(n+1):0,r=n?rng()%(n+1):0;if(l>r)std::swap(l,r);F f(rng(),rng());
   switch(rng()%6){
    case 0:case 1:tree.apply(l,r,f);for(int j=l;j<r;++j)a[j]=mapping(f,a[j]);break;
    case 2:if(l<n){S value(rng());tree.set(l,value);a[l]=value;}break;
    case 3:if(l<n){tree.apply(l,f);a[l]=mapping(f,a[l]);}break;
    case 4:if(l<n&&tree.get(l).v!=a[l].v)return false;break;
    case 5:{T copy=tree;T moved=std::move(copy);auto z=moved.get_all();if(z.size()!=a.size()||copy.size()!=0)return false;for(int i=0;i<n;++i)if(z[i].v!=a[i].v)return false;break;}
   }
  }
  auto all=tree.get_all();if(all.size()!=a.size())return false;for(int i=0;i<n;++i)if(all[i].v!=a[i].v)return false;
 }
 return true;
}
int main(){using T0=v0::DualSegmentTree<S,F,mapping,composition,id>;using T1=v1::DualSegmentTree<S,F,mapping,composition,id>;using T2=v2::DualSegmentTree<S,F,mapping,composition,id>;using T3=v3::DualSegmentTree<S,F,mapping,composition,id>;if(!(run<T0>()&&run<T1>()&&run<T2>()&&run<T3>()))return 1;std::puts("PASS");}
