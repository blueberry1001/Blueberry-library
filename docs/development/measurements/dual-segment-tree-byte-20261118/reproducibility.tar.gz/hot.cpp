#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <vector>
using U=std::uint32_t;constexpr U mod=998244353;
struct F{U a,b;};
U mapping(F f,U x){return (std::uint64_t(f.a)*x+f.b)%mod;}
F composition(F f,F g){return {U(std::uint64_t(f.a)*g.a%mod),U((std::uint64_t(f.a)*g.b+f.b)%mod)};}
F id(){return{1,0};}
#define blueberry v0
#include "baseline.hpp"
#undef blueberry
#define blueberry v1
#include "byte.hpp"
#undef blueberry
#define blueberry v2
#include "peek.hpp"
#undef blueberry
template<class T> std::uint64_t run(int mode){
 const int n=262144,q=1000000,p=100000;T tree(std::vector<U>(n,123));std::mt19937 g(47);
 if(mode<2)tree.apply(0,n,F{789,100});
 else {for(int h=1;h<=18;++h){int w=1<<h,l=(p/w)*w;tree.apply(l,l+w,F{U(h+1),U(h)});}}
 std::uint64_t ans=0;for(int i=0;i<q;++i)ans=ans*9+tree.get(mode==1?int(g()%n):p);return ans;
}
int main(int,char** argv){int ver=std::atoi(argv[1]),mode=std::atoi(argv[2]);using T0=v0::DualSegmentTree<U,F,mapping,composition,id>;using T1=v1::DualSegmentTree<U,F,mapping,composition,id>;using T2=v2::DualSegmentTree<U,F,mapping,composition,id>;auto t=std::chrono::steady_clock::now();auto ans=ver==0?run<T0>(mode):ver==1?run<T1>(mode):run<T2>(mode);double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t).count();std::printf("%.3f %llu\n",ms,(unsigned long long)ans);}
