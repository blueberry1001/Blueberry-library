import hashlib,json,os,platform,statistics,subprocess,time
from pathlib import Path
p=Path(__file__).resolve().parent
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');ver='10.0.22621.0';cl=vc/'bin/Hostx64/x64/cl.exe';clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(cl.parent)+os.pathsep+env.get('PATH','');env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/ver/x for x in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/ver/x/'x64' for x in ('ucrt','um'))]))
cases=[]
def add(name,n=100000,q=100000,sigma=50000,shape=0,kind=0,typ=0):cases.append(dict(name=name,n=n,q=q,sigma=sigma,shape=shape,kind=kind,type=typ))
for sigma in (2,20,316,50000,0):add('uniform-values-'+str(sigma),sigma=sigma)
for sigma in (20,50000):
 for shape,name in [(1,'identical'),(2,'same-left'),(3,'same-right')]:add(name+'-'+str(sigma),sigma=sigma,shape=shape)
for shape,name in [(4,'left-8'),(5,'left-9'),(6,'right-8'),(7,'right-9'),(10,'short-intervals')]:add(name,shape=shape)
add('single-short',q=1,shape=8);add('single-full',q=1,shape=9)
add('q-100',q=100);add('q-1000',q=1000)
add('64bit-signed',kind=2,typ=1);add('string',n=30000,q=30000,sigma=5000,typ=2)
add('empty-q',q=0)
out={'status':'running','platform':platform.platform(),'cpu':os.getenv('PROCESSOR_IDENTIFIER'),'cpu_pinned':False,'note':'Shared system load not measured; no CPU pinning. Input generation and post-check excluded; time includes construction, query and return.','seed':'0x5e07117','warmups':1,'runs':5,'pr82_head':'35c83bdb40115ab91c3fa7bd53c16ef5161c45e5','pr82_git_blob':'8f93a7e8137b7a5b462a752001a2343c8ad2a5c0','sha256':{x:hashlib.sha256((p/x).read_bytes()).hexdigest() for x in ['cross.cpp','baseline.hpp','our.hpp','pr82.hpp']},'cases':[]}
def save():(p/'results.json').write_text(json.dumps(out,indent=2)+'\n')
try:
 exe=p/'cross.exe';cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG',str(p/'cross.cpp'),'-o',str(exe)]
 run=subprocess.run(cmd,cwd=p,env=env,text=True,errors='replace',capture_output=True);out['compile']={'command':cmd,'exit':run.returncode,'output':run.stdout+run.stderr};save()
 if run.returncode:raise RuntimeError('compile failed')
 for case in cases:
  row={'case':case,'samples':[]};out['cases'].append(row);checksums=set()
  for rep in range(-1,5):
   order=[1,2] if rep%2 else [2,1]
   for variant in order:
    cmd2=[str(exe),str(variant),*(str(case[k]) for k in ('n','q','sigma','shape','kind','type'))]
    run=subprocess.run(cmd2,cwd=p,env=env,text=True,errors='replace',capture_output=True,timeout=120)
    sample={'variant':variant,'rep':rep,'exit':run.returncode,'stdout':run.stdout,'stderr':run.stderr};row['samples'].append(sample);save()
    if run.returncode:raise RuntimeError('case failed '+case['name']+' '+str(variant))
    ms,checksum=run.stdout.split();sample.update(ms=float(ms),checksum=checksum);checksums.add(checksum);save()
   if len(checksums)!=1:raise RuntimeError('frequency checksum mismatch '+case['name'])
  row['summary']={str(v):{'median_ms':statistics.median(s['ms'] for s in row['samples'] if s['variant']==v and s['rep']>=0),'min_ms':min(s['ms'] for s in row['samples'] if s['variant']==v and s['rep']>=0)} for v in (1,2)};save()
  print(case['name'],*(round(row['summary'][str(v)]['median_ms'],3) for v in (1,2)),flush=True)
 out['status']='complete'
except BaseException as e:out['status']='failed';out['error']=repr(e);raise
finally:save()
