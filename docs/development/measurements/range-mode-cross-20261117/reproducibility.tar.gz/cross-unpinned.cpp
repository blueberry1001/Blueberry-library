#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <random>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
#define blueberry old_mode
#include "baseline.hpp"
#undef blueberry
#define blueberry ours
#include "our.hpp"
#undef blueberry
#define blueberry theirs
#include "pr82.hpp"
#undef blueberry
using namespace std;
template<class T> int benchmark(int variant,int n,int q,int sigma,int shape,int value_kind){
 mt19937_64 rng(0x5e07117);vector<T>a(n);
 for(int i=0;i<n;i++){
  long long x=sigma?static_cast<long long>(rng()%sigma):i;
  if constexpr(is_same_v<T,string>) a[i]=to_string(x*1000003-700000001);
  else {if(value_kind==1)x=x*1000003-700000001; if(value_kind==2)x=x*1000000007LL-(1LL<<50);a[i]=T(x);}
 }
 if(!sigma)shuffle(a.begin(),a.end(),rng);
 vector<pair<int,int>> query(q);
 for(auto& [l,r]:query){
  if(shape==1){l=n/3;r=2*n/3;}
  else if(shape==2){l=n/3;r=l+int(rng()%(n-l+1));}
  else if(shape==3){r=2*n/3;l=int(rng()%(r+1));}
  else if(shape==4||shape==5){l=int(rng()%(shape==4?8:9))*n/20;r=l+int(rng()%(n-l+1));}
  else if(shape==6||shape==7){r=n-int(rng()%(shape==6?8:9))*n/20;l=int(rng()%(r+1));}
  else if(shape==8){l=n/3;r=min(n,l+10);}
  else if(shape==9){l=0;r=n;}
  else if(shape==10){l=int(rng()%(n+1));r=min(n,l+int(rng()%100));}
  else {l=int(rng()%(n+1));r=int(rng()%(n+1));if(l>r)swap(l,r);}
 }
 const auto begin=chrono::steady_clock::now();
 auto result=variant==0?old_mode::static_range_mode(a,query):(variant==1?ours::static_range_mode(a,query):theirs::static_range_mode(a,query));
 const auto end=chrono::steady_clock::now();
 if(result.size()!=query.size())return 3;
 uint64_t checksum=0;for(auto[index,f]:result){checksum=checksum*0x9e3779b185ebca87ULL+uint64_t(f);if((f==0&&index!=-1)||(f>0&&(index<0||index>=n)))return 4;}
 int samples=min(q,24);
 for(int k=0;k<samples;k++){
  int id=int(uint64_t(k)*q/samples);auto[l,r]=query[id];unordered_map<T,int>cnt;int best=0;
  for(int i=l;i<r;++i)best=max(best,++cnt[a[i]]);
  auto[index,f]=result[id];if(f!=best||(f&&cnt[a[index]]!=f)){cerr<<"wrong variant="<<variant<<" n="<<n<<" q="<<q<<" sigma="<<sigma<<" shape="<<shape<<" query="<<id<<" l="<<l<<" r="<<r<<" best="<<best<<" got="<<index<<','<<f<<'\n';return 5;}
 }
 cout<<chrono::duration<double,milli>(end-begin).count()<<' '<<checksum<<'\n';return 0;
}
int main(int argc,char**argv){if(argc!=8)return 1;int v=atoi(argv[1]),n=atoi(argv[2]),q=atoi(argv[3]),sigma=atoi(argv[4]),shape=atoi(argv[5]),kind=atoi(argv[6]),type=atoi(argv[7]);
 if(type==1)return benchmark<long long>(v,n,q,sigma,shape,kind);if(type==2)return benchmark<string>(v,n,q,sigma,shape,kind);return benchmark<int>(v,n,q,sigma,shape,kind);}
