#pragma once
#include <algorithm>
#include <cmath>
#include <numeric>
#include <limits>
#include <utility>
#include <type_traits>
#include <vector>

namespace blueberry {
template <class T>
std::vector<std::pair<int, int>> static_range_mode(
    const std::vector<T>& a, const std::vector<std::pair<int, int>>& queries) {
  const int n = static_cast<int>(a.size()), q = static_cast<int>(queries.size());
  if (!q) return {};
  auto [only_l, only_r] = queries[0];
  if (q >= 32 || static_cast<long long>(only_r - only_l) * 16 < n) {
    bool identical = true;
    for (int i = 1; i < q; ++i) if (queries[i] != queries[0]) { identical = false; break; }
    if constexpr (requires { static_cast<bool>(a[0] < a[0]); static_cast<bool>(a[0] == a[0]); }) {
      if (identical) {
        std::vector<int> sorted(only_r - only_l); std::iota(sorted.begin(), sorted.end(), only_l);
        std::sort(sorted.begin(), sorted.end(), [&](int x, int y) { return a[x] < a[y]; });
        int best = -1, frequency = 0;
        for (int i = 0, j; i < only_r - only_l; i = j) {
          j = i + 1; while (j < only_r - only_l && a[sorted[i]] == a[sorted[j]]) ++j;
          if (j - i > frequency) { frequency = j - i; best = sorted[i]; }
        }
        return std::vector<std::pair<int, int>>(q, {best, frequency});
      }
    }
  }
  std::vector<int> rank(n), representative, order(q);
  int m = 0;
  if constexpr (std::is_integral_v<T> && !std::is_same_v<T, bool>) {
    using U = std::make_unsigned_t<T>;
    std::vector<int> idx(n), tmp(n);
    std::iota(idx.begin(), idx.end(), 0);
    constexpr int digits = std::numeric_limits<U>::digits;
    constexpr U sign = std::is_signed_v<T> ? U(U(1) << (digits - 1)) : U(0);
    for (int shift = 0; shift < digits; shift += 8) {
      int count[256] = {};
      for (int i : idx) ++count[((U(a[i]) ^ sign) >> shift) & 255];
      int offset = 0;
      for (int& c : count) { int k = c; c = offset; offset += k; }
      for (int i : idx) tmp[count[((U(a[i]) ^ sign) >> shift) & 255]++] = i;
      idx.swap(tmp);
    }
    for (int i = 0; i < n; ++i) {
      if (!i || a[idx[i]] != a[idx[i - 1]]) { representative.push_back(idx[i]); ++m; }
      else representative.back() = idx[i];
      rank[idx[i]] = m - 1;
    }
  } else {
    std::vector<T> values = a;
    std::sort(values.begin(), values.end());
    values.erase(std::unique(values.begin(), values.end()), values.end());
    m = static_cast<int>(values.size());
    representative.resize(m);
    for (int i = 0; i < n; ++i) {
      rank[i] = static_cast<int>(std::lower_bound(values.begin(), values.end(), a[i]) - values.begin());
      representative[rank[i]] = i;
    }
  }
  if (m <= 2 || m == n) {
    std::vector<std::pair<int, int>> answer(q, {-1, 0});
    if (m == 2 && m != n) {
      std::vector<int> prefix(n + 1);
      for (int i = 0; i < n; ++i) prefix[i + 1] = prefix[i] + (rank[i] == 0);
      for (int i = 0; i < q; ++i) {
        auto [l, r] = queries[i]; int x = prefix[r] - prefix[l], y = r - l - x;
        if (x || y) answer[i] = x >= y ? std::pair{representative[0], x} : std::pair{representative[1], y};
      }
    } else for (int i = 0; i < q; ++i) {
      auto [l, r] = queries[i];
      if (l != r) answer[i] = m == 1 ? std::pair{representative[0], r - l} : std::pair{l, 1};
    }
    return answer;
  }
  int left_values[8], right_values[8], left_count = 0, right_count = 0;
  for (auto [l, r] : queries) {
    if (left_count <= 8) {
      int i = 0; while (i < left_count && left_values[i] != l) ++i;
      if (i == left_count) { if (left_count < 8) left_values[left_count] = l; ++left_count; }
    }
    if (right_count <= 8) {
      int i = 0; while (i < right_count && right_values[i] != r) ++i;
      if (i == right_count) { if (right_count < 8) right_values[right_count] = r; ++right_count; }
    }
    if (left_count > 8 && right_count > 8) break;
  }
  if (left_count <= 8 || right_count <= 8) {
    std::vector<std::pair<int, int>> answer(q, {-1, 0});
    bool left = left_count <= right_count;
    std::vector<int> order(q), count(m); std::iota(order.begin(), order.end(), 0);
    std::sort(order.begin(), order.end(), [&](int x, int y) {
      auto [lx, rx] = queries[x]; auto [ly, ry] = queries[y];
      return left ? (lx != ly ? lx < ly : rx < ry) : (rx != ry ? rx < ry : lx > ly);
    });
    int key = -1, cursor = 0, frequency = 0, best = -1;
    for (int id : order) {
      auto [l, r] = queries[id]; int current_key = left ? l : r;
      if (key != current_key) { std::fill(count.begin(), count.end(), 0); key = current_key; cursor = key; frequency = 0; best = -1; }
      while (left ? cursor < r : cursor > l) {
        int x = rank[left ? cursor++ : --cursor];
        if (++count[x] > frequency) { frequency = count[x]; best = x; }
      }
      answer[id] = {best < 0 ? -1 : representative[best], frequency};
    }
    return answer;
  }
  std::iota(order.begin(), order.end(), 0);
  const int block = std::max(1, static_cast<int>(n / std::sqrt(static_cast<double>(std::max(1, q)))));
  std::vector<int> blocks(q);
  for (int i = 0; i < q; ++i) blocks[i] = queries[i].first / block;
  std::sort(order.begin(), order.end(), [&](int x, int y) {
    if (blocks[x] != blocks[y]) return blocks[x] < blocks[y];
    if (queries[x].second != queries[y].second) return queries[x].second < queries[y].second;
    return queries[x].first < queries[y].first;
  });
  std::vector<int> count(m);
  std::vector<std::pair<int, int>> answer(q);
  int current_block = -1, end = 0, right = 0, best = -1, maximum = 0;
  auto add = [&](int index) {
    int x = rank[index], f = ++count[x];
    if (f > maximum) { maximum = f; best = x; }
  };
  int last_left = -1, last_right = -1, last_id = -1;
  for (int id : order) {
    auto [left, qr] = queries[id];
    if (left == last_left && qr == last_right) { answer[id] = answer[last_id]; continue; }
    last_left = left; last_right = qr; last_id = id;
    if (current_block != blocks[id]) {
      for (int i = end; i < right; ++i) count[rank[i]] = 0;
      current_block = blocks[id];
      end = static_cast<int>(std::min(static_cast<long long>(n), (static_cast<long long>(current_block) + 1) * block));
      right = end; best = -1; maximum = 0;
    }
    if (qr <= end) {
      for (int i = left; i < qr; ++i) add(i);
      answer[id] = {maximum ? representative[best] : -1, maximum};
      for (int i = left; i < qr; ++i) --count[rank[i]];
      best = -1; maximum = 0;
    } else {
      while (right < qr) add(right++);
      int saved_best = best, saved_maximum = maximum;
      for (int i = left; i < end; ++i) add(i);
      answer[id] = {maximum ? representative[best] : -1, maximum};
      for (int i = left; i < end; ++i) --count[rank[i]];
      best = saved_best; maximum = saved_maximum;
    }
  }
  return answer;
}
}
