import json,os,shutil,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent;inc=p/'include';h=inc/'blueberry/data-structure/static-range-mode.hpp';h.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p/'combined-query.hpp',h)
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');ver='10.0.22621.0';cl=vc/'bin/Hostx64/x64/cl.exe';clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(cl.parent)+os.pathsep+env.get('PATH','');env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/ver/x for x in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/ver/x/'x64' for x in ('ucrt','um'))]))
out={'status':'running','cases':[]}
def save():(p/'verify-copy-results.json').write_text(json.dumps(out,indent=2)+'\n')
try:
 for compiler in ('clang','msvc'):
  for standard in ('20','23'):
   exe=p/(compiler+standard+'-copytest.exe')
   cmd=([str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++'+standard,'-O2','-I',str(inc),str(p/'verify-copy.cpp'),'-o',str(exe)] if compiler=='clang' else [str(cl),'/nologo','/std:c++'+('20' if standard=='20' else 'latest'),'/EHsc','/O2','/I'+str(inc),str(p/'verify-copy.cpp'),'/Fo'+str(p/'copytest.obj'),'/Fe'+str(exe)])
   a=subprocess.run(cmd,cwd=p,env=env,text=True,errors='replace',capture_output=True);row={'compiler':compiler,'standard':standard,'command':cmd,'compile_exit':a.returncode,'compile_output':a.stdout+a.stderr,'runs':[]};out['cases'].append(row);save()
   if a.returncode:raise RuntimeError('compile failed')
   for seed in (1,2,17):
    b=subprocess.run([str(exe),str(seed)],cwd=p,env=env,text=True,errors='replace',capture_output=True,timeout=240);row['runs'].append({'seed':seed,'exit':b.returncode,'output':b.stdout+b.stderr});save()
    if b.returncode:raise RuntimeError('test failed')
   print(compiler,standard,'OK seeds 1,2,17',flush=True)
 out['status']='complete'
except BaseException as e:out['status']='failed';out['error']=repr(e);raise
finally:save()
