#include <iostream>
#include <vector>
#include <utility>
#ifdef USE_BASELINE
#include "pr82.hpp"
#else
#include "combined-query.hpp"
#endif
int main(){
 std::ios::sync_with_stdio(false); std::cin.tie(nullptr);
 int n,q;if(!(std::cin>>n>>q))return 1;
 std::vector<int>a(n);for(auto&x:a)std::cin>>x;
 std::vector<std::pair<int,int>>queries(q);for(auto&[l,r]:queries)std::cin>>l>>r;
 auto ans=blueberry::static_range_mode(a,queries);
 for(auto[i,f]:ans) std::cout<<a[i]<<' '<<f<<'\n';
}
