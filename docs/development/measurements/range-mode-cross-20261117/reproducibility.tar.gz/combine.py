from pathlib import Path
p=Path(__file__).parent
s=(p/'our.hpp').read_text();pr=(p/'pr82.hpp').read_text()
original='  if (!q) return {};\n'
assert s.count(original)==1
same='''  auto [only_l, only_r] = queries[0];
  if (q >= 32 || static_cast<long long>(only_r - only_l) * 16 < n) {
    if constexpr (requires { static_cast<bool>(a[0] < a[0]); static_cast<bool>(a[0] == a[0]); }) {
      bool identical = true;
      for (int i = 1; i < q; ++i) if (queries[i] != queries[0]) { identical = false; break; }
      if (identical) {
        std::vector<int> sorted(only_r - only_l); std::iota(sorted.begin(), sorted.end(), only_l);
        std::sort(sorted.begin(), sorted.end(), [&](int x, int y) { return a[x] < a[y]; });
        int best = -1, frequency = 0;
        for (int i = 0, j; i < only_r - only_l; i = j) {
          j = i + 1; while (j < only_r - only_l && a[sorted[i]] == a[sorted[j]]) ++j;
          if (j - i > frequency) { frequency = j - i; best = sorted[i]; }
        }
        return std::vector<std::pair<int, int>>(q, {best, frequency});
      }
    }
  }
'''
s=s.replace(original,original+same)
start=pr.index('  int left_values[8]');end=pr.index('  int width =',start)
fixed=pr[start:end].replace('  if (left_count <= 8 || right_count <= 8) {','  if (left_count <= 8 || right_count <= 8) {\n    std::vector<std::pair<int, int>> answer(q, {-1, 0});')
marker='  std::iota(order.begin(), order.end(), 0);\n';assert s.count(marker)==1
s=s.replace(marker,fixed+marker)
s=s.replace('    return queries[x].second < queries[y].second;','    if (queries[x].second != queries[y].second) return queries[x].second < queries[y].second;\n    return queries[x].first < queries[y].first;')
s=s.replace('  for (int id : order) {\n    auto [left, qr] = queries[id];','  int last_left = -1, last_right = -1, last_id = -1;\n  for (int id : order) {\n    auto [left, qr] = queries[id];\n    if (left == last_left && qr == last_right) { answer[id] = answer[last_id]; continue; }\n    last_left = left; last_right = qr; last_id = id;')
(p/'combined.hpp').write_text(s,newline='\n')
