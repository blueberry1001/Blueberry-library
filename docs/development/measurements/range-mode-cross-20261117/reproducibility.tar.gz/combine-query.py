from pathlib import Path
p=Path(__file__).parent
s=(p/'combined.hpp').read_text();pr=(p/'pr82.hpp').read_text()
s=s.replace('  std::vector<int> rank(n), representative, order(q);','  std::vector<int> rank(n), representative;')
marker='''  } else {
    std::vector<T> values = a;
    std::sort(values.begin(), values.end());'''
replacement='''  } else if constexpr (!std::is_move_constructible_v<T> || !std::is_move_assignable_v<T> || !std::is_swappable_v<T>) {
    std::vector<T> values = a;
    std::vector<int> idx(n);
    std::iota(idx.begin(), idx.end(), 0);
    std::sort(idx.begin(), idx.end(), [&](int i, int j) { return values[i] < values[j]; });
    for (int i = 0; i < n; ++i) {
      if (!i || !(values[idx[i]] == values[idx[i - 1]])) { representative.push_back(idx[i]); ++m; }
      else representative.back() = idx[i];
      rank[idx[i]] = m - 1;
    }
  } else {
    std::vector<T> values = a;
    std::sort(values.begin(), values.end());'''
assert s.count(marker)==1
s=s.replace(marker,replacement)
start=s.index('  std::iota(order.begin(), order.end(), 0);')
end=pr.index('  int width =')
tail=pr[end:]
tail=tail.replace('  int width =','  std::vector<std::pair<int, int>> answer(q, {-1, 0});\n  int width =',1)
(p/'combined-query.hpp').write_text(s[:start]+tail,newline='\n')
