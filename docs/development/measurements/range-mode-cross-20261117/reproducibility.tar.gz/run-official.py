import bisect,ctypes,hashlib,json,os,platform,shutil,statistics,subprocess,time
from pathlib import Path
here=Path(__file__).resolve().parent
repo=Path(r'C:\Users\kubar\Documents\GitHub\Blueberry-library\.verification\library-checker-problems')
problem=repo/'data_structure/static_range_mode_query'; tmp=here/'official-tmp';(tmp/'gen').mkdir(parents=True,exist_ok=True)
for file in ('base.hpp','random.cpp','small_n.cpp','small_q.cpp','example_00.in'):shutil.copyfile(problem/'gen'/file,tmp/'gen'/file)
shutil.copyfile(repo/'common/random.h',tmp/'gen/random.h');shutil.copyfile(problem/'sol/correct.cpp',tmp/'correct.cpp')
(tmp/'params.h').write_text('#pragma once\nconstexpr int N_MIN=1, N_MAX=100000, Q_MIN=0, Q_MAX=100000, A_MIN=0, A_MAX=1000000000;\n')
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');ver='10.0.22621.0';cl=vc/'bin/Hostx64/x64/cl.exe';clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(cl.parent)+os.pathsep+env.get('PATH','');env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/ver/x for x in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/ver/x/'x64' for x in ('ucrt','um'))]))
prefix=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG']
out={'status':'running','problem_commit':'73876f1cbcf082d2b22722924b924d3d65a2f00e','platform':platform.platform(),'compiler':str(clang),'flags':prefix[1:],'warmups':1,'runs':3,'io':'included, baseline=PR82/final=combined-query same iostream driver, official reference uses scanf/printf','cpu_pinned':False,'warning':'System load and physical-core sibling interference not measured','sha256':{f:hashlib.sha256((here/f).read_bytes()).hexdigest() for f in ['official-driver.cpp','pr82.hpp','combined-query.hpp']},'build':[],'cases':[]}
def save(): (here/'official-results.json').write_text(json.dumps(out,indent=2)+'\n')
def build(name,source,flags=[]):
 exe=tmp/(name+'.exe');cmd=prefix+flags+[str(source),'-o',str(exe)];p=subprocess.run(cmd,cwd=tmp,env=env,text=True,errors='replace',capture_output=True);out['build'].append({'command':cmd,'exit':p.returncode,'output':p.stdout+p.stderr});save()
 if p.returncode:raise RuntimeError('compile failure '+name)
 return exe
try:
 kernel=ctypes.windll.kernel32;kernel.GetCurrentProcess.restype=ctypes.c_void_p
 kernel.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
 kernel.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
 process=kernel.GetCurrentProcess();before=ctypes.c_size_t();system=ctypes.c_size_t()
 if not kernel.GetProcessAffinityMask(process,ctypes.byref(before),ctypes.byref(system)) or not(before.value&1) or not kernel.SetProcessAffinityMask(process,1):raise RuntimeError('CPU0 affinity setup failed')
 after=ctypes.c_size_t()
 if not kernel.GetProcessAffinityMask(process,ctypes.byref(after),ctypes.byref(system)) or after.value!=1:raise RuntimeError('CPU0 affinity verification failed')
 out.update(cpu_pinned=True,process_affinity_before=hex(before.value),process_affinity_after=hex(after.value));save()
 gens={name:build(name,tmp/'gen'/f'{name}.cpp') for name in ('random','small_n','small_q')}
 executables={'baseline':build('baseline',here/'official-driver.cpp',['-DUSE_BASELINE']),'final':build('candidate',here/'official-driver.cpp'),'official-reference':build('correct',tmp/'correct.cpp')}
 cases=[('example',0)]+[('small_n',i) for i in range(3)]+[('small_q',0)]+[('random',i) for i in range(6)]
 for name,seed in cases:
  inp=tmp/'input.txt'
  if name=='example':shutil.copyfile(tmp/'gen/example_00.in',inp)
  else:
   with inp.open('wb') as f: p=subprocess.run([str(gens[name]),str(seed)],cwd=tmp,env=env,stdout=f,stderr=subprocess.PIPE,timeout=60)
   if p.returncode:raise RuntimeError('generate failed '+name+str(seed)+repr(p.stderr))
  raw=inp.read_text().split();n=int(raw[0]);q=int(raw[1]);a=list(map(int,raw[2:2+n]));queries=list(zip(map(int,raw[2+n::2]),map(int,raw[3+n::2])));assert len(queries)==q
  indices={}
  for i,x in enumerate(a): indices.setdefault(x,[]).append(i)
  row={'name':name,'seed':seed,'n':n,'q':q,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'samples':[]};out['cases'].append(row);save()
  for rep in range(-1,3):
   for variant,exe in executables.items():
    op=tmp/(variant+'.out');start=time.perf_counter()
    with inp.open('rb') as src,op.open('wb') as dst:p=subprocess.run([str(exe)],stdin=src,stdout=dst,stderr=subprocess.PIPE,cwd=tmp,env=env,timeout=120)
    elapsed=(time.perf_counter()-start)*1000
    row['samples'].append({'variant':variant,'rep':rep,'ms':elapsed,'exit':p.returncode,'stderr':p.stderr.decode(errors='replace')});save()
    if p.returncode:raise RuntimeError('run failed '+name+str(seed)+variant)
   expected=(tmp/'official-reference.out').read_text().split();assert len(expected)==2*q
   for variant in ('baseline','final'):
    actual=(tmp/(variant+'.out')).read_text().split();assert len(actual)==2*q
    for i,(l,r) in enumerate(queries):
     x=int(actual[2*i]);f=int(actual[2*i+1]);indices_x=indices.get(x,[])
     if f!=int(expected[2*i+1]) or bisect.bisect_left(indices_x,r)-bisect.bisect_left(indices_x,l)!=f:raise RuntimeError(f'mismatch {name} {seed} {variant} query {i}')
  row['verified']=True;save();print(name,seed,n,q,{v:round(statistics.median(x['ms'] for x in row['samples'] if x['variant']==v and x['rep']>=0),2) for v in executables},flush=True)
 out['status']='complete'
except BaseException as e:
 out['status']='failed';out['error']=repr(e);save();raise
save()
