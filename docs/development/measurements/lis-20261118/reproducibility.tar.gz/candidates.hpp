#pragma once
#include <algorithm>
#include <vector>
template<int Mode, class T>
std::vector<int> test_lis(const std::vector<T>& values) {
  const int n = static_cast<int>(values.size());
  std::vector<int> tails, previous(values.size(), -1);
  tails.reserve(values.size());
  for (int i = 0; i < n; ++i) {
    if constexpr (Mode != 0 && Mode != 3) {
      if (tails.empty() || values[tails.back()] < values[i]) {
        if (!tails.empty()) previous[i] = tails.back();
        tails.push_back(i); continue;
      }
    }
    auto it = tails.begin();
    if constexpr (Mode == 2 || Mode == 3) {
      std::size_t width = tails.size() + 1;
      while (width > 1) {
        auto half = width / 2;
        width -= half;
        it += static_cast<std::size_t>(static_cast<bool>(values[*(it + half - 1)] < values[i])) * half;
      }
    } else {
      it = std::lower_bound(tails.begin(), tails.end(), values[i],
                            [&](int j, const T& value) { return values[j] < value; });
    }
    if (it != tails.begin()) previous[i] = *(it - 1);
    if (it == tails.end()) tails.push_back(i); else *it = i;
  }
  std::vector<int> result;
  if (!tails.empty()) {
    for (int i = tails.back(); i != -1; i = previous[i]) result.push_back(i);
    std::reverse(result.begin(), result.end());
  }
  return result;
}
template<int Variant=0,class T>
std::vector<int> value_lis(const std::vector<T>& values) {
  const int n = static_cast<int>(values.size());
  std::vector<int> tails, previous(values.size(), -1);
  std::vector<T> tail_values;
  tails.reserve(values.size());tail_values.reserve(values.size());
  for (int i = 0; i < n; ++i) {
    const auto& v = values[i];
    if (tails.empty() || tail_values.back() < v) {
      if (!tails.empty()) previous[i] = tails.back();
      tails.push_back(i);tail_values.push_back(v);continue;
    }
    if constexpr (Variant == 3 || Variant == 4) {
      if (tails.size() == 1) { tails[0] = i; tail_values[0] = v; continue; }
    }
    if constexpr (Variant == 1) {
      if (!(tail_values.front() < v)) { tails[0] = i; tail_values[0] = v; continue; }
    }
    std::size_t pos = (Variant==1), width = tail_values.size() + 1 - pos;
    if constexpr (Variant == 2 || Variant == 3) {
      pos = std::lower_bound(tail_values.begin(),tail_values.end(),v)-tail_values.begin();
    } else while (width > 1) {
      const auto half = width / 2; width -= half;
      pos += static_cast<std::size_t>(static_cast<bool>(tail_values[pos + half - 1] < v)) * half;
    }
    if (pos) previous[i] = tails[pos-1];
    tails[pos] = i;tail_values[pos] = v;
  }
  std::vector<int> result;
  if (!tails.empty()) {
    for (int i = tails.back(); i != -1; i = previous[i]) result.push_back(i);
    std::reverse(result.begin(), result.end());
  }
  return result;
}
template<bool Branchless,class T>
std::vector<int> rank_lis(const std::vector<T>& values) {
  const int n=static_cast<int>(values.size());
  std::vector<int> rank(n);
  std::vector<T> tails; tails.reserve(values.size());
  for (int i=0;i<n;++i) {
    const T v=values[i];
    if (tails.empty() || tails.back()<v) { tails.push_back(v); rank[i]=static_cast<int>(tails.size());continue; }
    if (tails.size()==1) { tails[0]=v;rank[i]=1;continue; }
    std::size_t pos=0;
    if constexpr (!Branchless) pos=std::lower_bound(tails.begin(),tails.end(),v)-tails.begin();
    else { std::size_t width=tails.size()+1;while(width>1) { auto half=width/2;width-=half;pos+=std::size_t(tails[pos+half-1]<v)*half; } }
    tails[pos]=v;rank[i]=static_cast<int>(pos)+1;
  }
  int need=static_cast<int>(tails.size());std::vector<int> result(need);
  for(int i=n;i-- && need;) if(rank[i]==need) result[--need]=i;
  return result;
}
