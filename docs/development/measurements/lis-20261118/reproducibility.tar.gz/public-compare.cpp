#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <random>
#include <string>
#include <vector>
#define blueberry baseline
#include "baseline.hpp"
#undef blueberry
#define blueberry candidate
#include "public.hpp"
#undef blueberry

struct MoveOnly { int x; explicit MoveOnly(int v):x(v){} MoveOnly(MoveOnly&&)=default; MoveOnly(const MoveOnly&)=delete; bool operator<(const MoveOnly& a)const{return x<a.x;} };
template<class T> bool valid(const std::vector<T>& a,const std::vector<int>& r,int len){
 if((int)r.size()!=len)return false;
 for(int i=0;i<len;++i)if(r[i]<0||r[i]>=(int)a.size()||(i&&(!(r[i-1]<r[i])||!(a[r[i-1]]<a[r[i]]))))return false;
 return true;
}
template<class T> int bench(int ver,int n,int kind,int reps){
 std::mt19937_64 g(123456);std::vector<T>a(n);
 for(int i=0;i<n;++i){
  if(kind==0)a[i]=T(g());
  if(kind==1)a[i]=T(i);
  if(kind==2)a[i]=T(n-i);
  if(kind==3)a[i]=T(42);
  if(kind==4)a[i]=T(g()%256);
  if(kind==5)a[i]=T(i%1000);
  if(kind==6)a[i]=T(i+int(g()%25)-12);
 }
 auto start=std::chrono::steady_clock::now();std::uint64_t sum=0;
 for(int i=0;i<reps;++i){auto x=ver?candidate::longest_increasing_subsequence(a):baseline::longest_increasing_subsequence(a);sum+=x.size();}
 auto end=std::chrono::steady_clock::now();std::printf("%.3f %llu\n",std::chrono::duration<double,std::milli>(end-start).count(),(unsigned long long)sum);return 0;
}
int main(int argc,char**argv){
 std::mt19937_64 g(321);
 if(argc==1){
  for(int z=0;z<50000;++z){int n=g()%45;std::vector<long long>a(n);for(auto&x:a)x=(long long)(g()%25)-12;
   int best=0;std::vector<int>d(n,1);for(int i=0;i<n;++i){for(int j=0;j<i;++j)if(a[j]<a[i])d[i]=std::max(d[i],d[j]+1);best=std::max(best,d[i]);}
   if(!valid(a,candidate::longest_increasing_subsequence(a),best)){std::printf("FAIL %d\n",z);return 1;}
  }
  std::vector<MoveOnly>a;a.emplace_back(3);a.emplace_back(1);a.emplace_back(2);if(!valid(a,candidate::longest_increasing_subsequence(a),2))return 2;
  std::vector<std::string>s{"d","b","c","b","a"};if(!valid(s,candidate::longest_increasing_subsequence(s),2))return 3;
  std::vector<bool>b{true,false,true};if(!valid(b,candidate::longest_increasing_subsequence(b),2))return 4;
  std::puts("PASS 50000 + generic");return 0;
 }
 const int ver=std::atoi(argv[1]),n=std::atoi(argv[2]),kind=std::atoi(argv[3]),reps=std::atoi(argv[4]),bits=std::atoi(argv[5]);
 return bits==32?bench<std::uint32_t>(ver,n,kind,reps):bench<std::int64_t>(ver,n,kind,reps);
}
