import ctypes,json,os,pathlib,platform,subprocess,time,traceback
p=pathlib.Path(__file__).resolve().parent
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10');v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/x for x in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/x/'x64' for x in ('ucrt','um'))]))
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<4)
d={'status':'running','platform':platform.platform(),'processor':platform.processor(),'affinity':'0x10','results':[]}
def save(): (p/'result.json').write_text(json.dumps(d,indent=2)+'\n')
def call(cmd):
 t=time.perf_counter();r=subprocess.run(cmd,cwd=p,env=env,capture_output=True,text=True,errors='replace',timeout=180);x={'cmd':list(map(str,cmd)),'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'seconds':time.perf_counter()-t};d['results'].append(x);save()
 if r.returncode:raise RuntimeError('command failed')
 return x
try:
 for cc in ('clang','msvc'):
  exe=p/(cc+'.exe')
  cmd=([str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG',str(p/'compare.cpp'),'-o',str(exe)] if cc=='clang' else [str(vc/'bin/Hostx64/x64/cl.exe'),'/nologo','/std:c++20','/O2','/DNDEBUG','/EHsc',str(p/'compare.cpp'),'/Fe:'+str(exe)])
  call(cmd);call([str(exe)])
  for kind in range(7):
   for sample in range(-1,5):
    lengths=[]
    versions=[0,7,8,9,10]
    for j in range(len(versions)):
     ver=versions[(j+sample+len(versions))%len(versions)];x=call([str(exe),str(ver),'200000',str(kind),'3']);x.update(compiler=cc,kind=kind,sample=sample,version=ver);lengths.append(x['stdout'].split()[1]);save()
    if len(set(lengths))!=1:raise RuntimeError('length mismatch')
 d['status']='complete';save()
except BaseException:
 d['status']='failed';d['traceback']=traceback.format_exc();save();raise
