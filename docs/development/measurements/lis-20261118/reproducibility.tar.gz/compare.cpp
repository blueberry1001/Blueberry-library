#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <limits>
#include <random>
#include <vector>
#include "baseline.hpp"
#include "candidates.hpp"

template<class T> std::vector<int> solve(int v,const std::vector<T>&a){
  if(v==0)return blueberry::longest_increasing_subsequence(a);
  if(v==1)return test_lis<1>(a);
  if(v==2)return test_lis<2>(a);
  if(v==3)return test_lis<3>(a);
  if(v==4)return value_lis<0>(a);
  if(v==5)return value_lis<1>(a);
  if(v==6)return value_lis<2>(a);
  if(v==7)return value_lis<3>(a);
  if(v==8)return value_lis<4>(a);
  if(v==9)return rank_lis<false>(a);
  return rank_lis<true>(a);
}
template<class T> bool valid(const std::vector<T>& a,const std::vector<int>& r,int len){
 if((int)r.size()!=len)return false;
 for(int i=0;i<len;++i)if(r[i]<0||r[i]>=(int)a.size()||(i&&(!(r[i-1]<r[i])||!(a[r[i-1]]<a[r[i]]))))return false;
 return true;
}
int main(int argc,char**argv){
 std::mt19937_64 g(123456);
 if(argc==1){
  for(int z=0;z<60000;++z){int n=g()%45;std::vector<long long>a(n);for(auto&x:a)x=(long long)(g()%25)-12;
   int best=0;std::vector<int>d(n,1);for(int i=0;i<n;++i){for(int j=0;j<i;++j)if(a[j]<a[i])d[i]=std::max(d[i],d[j]+1);best=std::max(best,d[i]);}
   for(int ver=0;ver<11;++ver)if(!valid(a,solve(ver,a),best)){std::printf("FAIL case=%d version=%d\n",z,ver);return 1;}
  }std::puts("PASS 60000");return 0;
 }
 const int ver=std::atoi(argv[1]),n=std::atoi(argv[2]),kind=std::atoi(argv[3]),reps=std::atoi(argv[4]);
 std::vector<std::int64_t>a(n);
 for(int i=0;i<n;++i){
  if(kind==0)a[i]=std::int64_t(g()>>1);
  if(kind==1)a[i]=i;
  if(kind==2)a[i]=n-i;
  if(kind==3)a[i]=42;
  if(kind==4)a[i]=g()%256;
  if(kind==5)a[i]=i%1000;
  if(kind==6)a[i]=i+int(g()%25)-12;
 }
 auto start=std::chrono::steady_clock::now();std::uint64_t sum=0;
 for(int i=0;i<reps;++i){auto x=solve(ver,a);sum+=x.size();}
 auto end=std::chrono::steady_clock::now();std::printf("%.3f %llu\n",std::chrono::duration<double,std::milli>(end-start).count(),(unsigned long long)sum);
}
