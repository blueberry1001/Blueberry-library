import hashlib, json, os, subprocess, time
from pathlib import Path
here=Path(__file__).resolve().parent
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');version='10.0.22621.0'
msvc=vc/'bin/Hostx64/x64/cl.exe'
clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(msvc.parent)+os.pathsep+env.get('PATH','')
env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/version/p for p in ('ucrt','shared','um'))]))
env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/version/p/'x64' for p in ('ucrt','um'))]))
test=here/'tests/random/divisor-convolution-fused.cpp'
out={'status':'running','header_sha256':hashlib.sha256((here/'final.hpp').read_bytes()).hexdigest(),'test_sha256':hashlib.sha256(test.read_bytes()).hexdigest(),'rows':[]}
def save():(here/'matrix-results.json').write_text(json.dumps(out,indent=2)+'\n')
try:
 for compiler,standard in [('msvc','c++20'),('msvc','c++latest'),('clang','gnu++20'),('clang','gnu++23')]:
  exe=here/f'matrix-{compiler}-{standard.replace("+","p")}.exe'
  if compiler=='msvc':cmd=[str(msvc),'/nologo',f'/std:{standard}','/EHsc','/O2','/DNDEBUG','/I'+str(here),str(test),'/Fo'+str(exe)+'.obj','/Fe'+str(exe)]
  else:cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link',f'-std={standard}','-O2','-DNDEBUG','-I'+str(here),str(test),'-o',str(exe)]
  q=subprocess.run(cmd,env=env,capture_output=True,text=True,errors='replace',timeout=120)
  row={'compiler':compiler,'standard':standard,'command':cmd,'compile_exit':q.returncode,'compile_output':q.stdout+q.stderr,'tests':[]};out['rows'].append(row);save()
  if q.returncode:raise RuntimeError('compile failed')
  for seed in [1,2,17]:
   t=time.perf_counter();q=subprocess.run([str(exe),str(seed)],env=env,capture_output=True,text=True,errors='replace',timeout=120)
   row['tests'].append({'seed':seed,'exit':q.returncode,'seconds':time.perf_counter()-t,'stdout':q.stdout,'stderr':q.stderr});save()
   if q.returncode:raise RuntimeError('test failed')
  print(compiler,standard,'ok',flush=True)
 out['status']='complete'
except BaseException as e:
 out['status']='failed';out['error']=repr(e);save();raise
save()
