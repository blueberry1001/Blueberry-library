import hashlib, json, os, shutil, subprocess, time
from pathlib import Path
here=Path(__file__).resolve().parent
repo=Path(os.environ.get('LIBRARY_CHECKER_PROBLEMS', r'C:\Users\kubar\Documents\GitHub\Blueberry-library\.verification\library-checker-problems'))
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=Path(r'C:\Program Files (x86)\Windows Kits\10'); version='10.0.22621.0'
clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env.get('PATH','')
env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/version/p for p in ('ucrt','shared','um'))]))
env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/version/p/'x64' for p in ('ucrt','um'))]))
work=here/'official-work';work.mkdir(exist_ok=True)
out={'status':'running','problem_commit':'73876f1cbcf082d2b22722924b924d3d65a2f00e','note':'official generators and correct.cpp; hashes normalized CRLF to LF for Windows stdout; elapsed includes process and I/O, not comparative benchmark','compiles':[],'cases':[]}
def save():(here/'official-results.json').write_text(json.dumps(out,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest()
def build(source,exe):
 cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG','-I'+str(repo/'common'),str(source),'-o',str(exe)]
 q=subprocess.run(cmd,env=env,capture_output=True,text=True,errors='replace',timeout=180)
 out['compiles'].append({'command':cmd,'exit':q.returncode,'output':q.stdout+q.stderr});save()
 if q.returncode:raise RuntimeError('compile failed '+str(source))
def run(cmd,inp,output):
 start=time.perf_counter()
 with (open(inp,'rb') if inp else open(os.devnull,'rb')) as fi,open(output,'wb') as fo:
  q=subprocess.run(cmd,stdin=fi,stdout=fo,stderr=subprocess.PIPE,env=env,timeout=120)
 return {'command':list(map(str,cmd)),'exit':q.returncode,'stderr':q.stderr.decode('utf8','replace'),'seconds':time.perf_counter()-start,'sha256_lf':sha(output)}
try:
 build(here/'official.cpp',work/'candidate.exe')
 for mode,name in enumerate(['gcd_convolution','lcm_convolution']):
  src=repo/'convolution'/name;dst=work/name;dst.mkdir(exist_ok=True)
  shutil.copytree(src/'gen',dst/'gen',dirs_exist_ok=True)
  (dst/'params.h').write_text('constexpr long long N_MAX = 1000000;\nconstexpr long long MOD = 998244353;\n')
  build(src/'sol'/'correct.cpp',dst/'correct.exe')
  counts={'small':16,'random':3,'max_random':2,'near_prime':3,'near_prime_squared':3}
  for gen in counts:build(dst/'gen'/f'{gen}.cpp',dst/f'{gen}.exe')
  expected=json.loads((src/'hash.json').read_text())
  cases=[('example',0),('all_zero',0)]+[(gen,i) for gen,n in counts.items() for i in range(n)]
  for gen,seed in cases:
   stem=f'{gen}_{seed:02}'
   input=dst/'input.tmp';correct=dst/'correct.tmp';old=dst/'old.tmp';new=dst/'new.tmp'
   if gen in ('example','all_zero'):
    shutil.copyfile(dst/'gen'/f'{stem}.in',input);g={'exit':0,'sha256_lf':sha(input)}
   else:g=run([dst/f'{gen}.exe',str(seed)],None,input)
   row={'mode':name,'case':stem,'generator':g};out['cases'].append(row);save()
   if g['exit'] or g['sha256_lf']!=expected[stem+'.in']:raise RuntimeError('input hash mismatch '+stem)
   for key,cmd,path in [('correct',[dst/'correct.exe'],correct),('old',[work/'candidate.exe',str(mode),'0'],old),('new',[work/'candidate.exe',str(mode),'1'],new)]:
    row[key]=run(cmd,input,path);save()
    if row[key]['exit'] or row[key]['sha256_lf']!=expected[stem+'.out']:raise RuntimeError('output mismatch '+name+' '+stem+' '+key)
   print(name,stem,'ok',flush=True)
  for p in [input,correct,old,new]:p.unlink()
 out['status']='complete'
except BaseException as e:
 out['status']='failed';out['error']=repr(e);save();raise
save()
