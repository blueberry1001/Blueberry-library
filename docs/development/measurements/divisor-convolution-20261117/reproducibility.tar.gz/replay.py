from pathlib import Path
import shutil, subprocess, sys, time

source = Path(__file__).resolve().parent
output = Path.cwd() / '.build' / f'divisor-convolution-replay-{time.time_ns()}'
output.parent.mkdir(parents=True, exist_ok=True)
shutil.copytree(source, output)
for name in ['run.py', 'run-u64.py', 'run-matrix-tests.py', 'run-official.py', 'run-end-to-end.py']:
    result = subprocess.run([sys.executable, str(output / name)], cwd=output, capture_output=True, text=True, errors='replace')
    (output / f'{name}.log').write_text(result.stdout + result.stderr, encoding='utf-8')
    print(name, 'exit', result.returncode, flush=True)
    if result.returncode:
        print('Results:', output, flush=True)
        sys.exit(result.returncode)
print('Results:', output)
