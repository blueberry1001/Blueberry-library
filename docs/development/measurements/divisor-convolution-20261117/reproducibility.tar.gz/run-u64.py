import hashlib,json,os,platform,statistics,subprocess
from pathlib import Path
here=Path(__file__).resolve().parent
vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk=Path(r'C:\Program Files (x86)\Windows Kits\10');version='10.0.22621.0'
msvc=vc/'bin/Hostx64/x64/cl.exe';clang=Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(msvc.parent)+os.pathsep+env.get('PATH','')
env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/version/p for p in ('ucrt','shared','um'))]))
env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/version/p/'x64' for p in ('ucrt','um'))]))
out={'status':'running','platform':platform.platform(),'cpu':platform.processor(),'note':'uint64 ring, intentional modulo 2^64 unsigned arithmetic; unpinned shared CPU; wall time includes vector copies, allocation, convolution, and checksum','hashes':{p:hashlib.sha256((here/p).read_bytes()).hexdigest() for p in ['final.hpp','baseline_renamed.hpp','u64-driver.cpp']},'rows':[]}
def save():(here/'u64-results.json').write_text(json.dumps(out,indent=2)+'\n')
try:
 for compiler in ['msvc','clang']:
  exe=here/(compiler+'-u64.exe')
  if compiler=='msvc':cmd=[str(msvc),'/nologo','/std:c++20','/EHsc','/O2','/DNDEBUG',str(here/'u64-driver.cpp'),'/Fo'+str(exe)+'.obj','/Fe'+str(exe)]
  else:cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG',str(here/'u64-driver.cpp'),'-o',str(exe)]
  q=subprocess.run(cmd,env=env,capture_output=True,text=True,errors='replace',timeout=120)
  row={'compiler':compiler,'command':cmd,'exit':q.returncode,'output':q.stdout+q.stderr,'samples':[]};out['rows'].append(row);save()
  if q.returncode:raise RuntimeError('compile failed')
  for mode in [0,1]:
   for n,reps in [(16,40000),(128,5000),(511,1000),(512,1000),(4096,40),(65536,4),(1000001,1)]:
    hashes=set()
    for rep in range(-1,5):
     for variant in ([0,1] if rep%2==0 else [1,0]):
      q=subprocess.run([str(exe),str(variant),str(mode),str(n),str(reps)],env=env,capture_output=True,text=True,errors='replace',timeout=120)
      if q.returncode:raise RuntimeError('benchmark failure '+q.stderr)
      f=q.stdout.split();hashes.add(f[5]);row['samples'].append({'mode':mode,'n':n,'reps':reps,'rep':rep,'variant':variant,'ms':float(f[4]),'checksum':f[5]});save()
     if len(hashes)!=1:raise RuntimeError('checksum mismatch')
    print(compiler,mode,n,[(v,round(statistics.median(s['ms'] for s in row['samples'] if s['mode']==mode and s['n']==n and s['rep']>=0 and s['variant']==v),3)) for v in [0,1]],flush=True)
 out['status']='complete'
except BaseException as e:
 out['status']='failed';out['error']=repr(e);save();raise
save()
