#pragma once
#include <cassert>
#include <cstddef>
#include <vector>

namespace blueberry_fast {
template <bool Divisor, class T>
std::vector<T> convolution(std::vector<T> a, std::vector<T> b) {
  assert(a.size() == b.size());
  const std::size_t n = a.size();
  if (!n) return a;
  std::vector<bool> composite(n);
  std::vector<std::size_t> primes;
  for (std::size_t p = 2; p < n; ++p) {
    if (composite[p]) continue;
    primes.push_back(p);
    if (p <= (n - 1) / p) for (std::size_t j = p * p; j < n; j += p) composite[j] = true;
  }
  for (const auto p : primes) {
    const auto count = (n - 1) / p;
    for (std::size_t j = 1; j <= count; ++j) {
      const auto i = Divisor ? j : count + 1 - j;
      if constexpr (Divisor) { a[i * p] += a[i]; b[i * p] += b[i]; }
      else { a[i] += a[i * p]; b[i] += b[i * p]; }
    }
  }
  for (std::size_t i = 1; i < n; ++i) a[i] *= b[i];
  for (const auto p : primes) {
    const auto count = (n - 1) / p;
    for (std::size_t j = 1; j <= count; ++j) {
      const auto i = Divisor ? count + 1 - j : j;
      if constexpr (Divisor) a[i * p] -= a[i];
      else a[i] -= a[i * p];
    }
  }
  a[0] = T{};
  return a;
}
}
