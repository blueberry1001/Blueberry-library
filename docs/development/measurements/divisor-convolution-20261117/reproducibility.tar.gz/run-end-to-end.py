import hashlib,json,os,platform,statistics,subprocess,time
from pathlib import Path
here=Path(__file__).resolve().parent;work=here/'official-work'
repo=Path(os.environ.get('LIBRARY_CHECKER_PROBLEMS', r'C:\Users\kubar\Documents\GitHub\Blueberry-library\.verification\library-checker-problems'))
out={'status':'running','platform':platform.platform(),'cpu':platform.processor(),'note':'Clang 18 gnu++20 -O2 -DNDEBUG, unpinned Windows CPU, warmup then 5 alternating runs; process start, I/O, copies, allocation, computation and formatting all included; file cached, stdout is same local file.','runs':[]}
def save():(here/'end-to-end-results.json').write_text(json.dumps(out,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest()
try:
 for mode,name in enumerate(['gcd_convolution','lcm_convolution']):
  dst=work/name;inp=dst/'bench-input.tmp';result=dst/'bench-output.tmp'
  with open(inp,'wb') as f:
   q=subprocess.run([dst/'max_random.exe','0'],stdout=f,stderr=subprocess.PIPE,timeout=90)
  expected=json.loads((repo/'convolution'/name/'hash.json').read_text())
  if q.returncode or sha(inp)!=expected['max_random_00.in']:raise RuntimeError('generator failed')
  for rep in range(-1,5):
   order=[0,1] if rep%2==0 else [1,0]
   for v in order:
    t=time.perf_counter()
    with open(inp,'rb') as fi,open(result,'wb') as fo:
     q=subprocess.run([work/'candidate.exe',str(mode),str(v)],stdin=fi,stdout=fo,stderr=subprocess.PIPE,timeout=120)
    ms=(time.perf_counter()-t)*1000
    row={'mode':name,'case':'max_random_00','rep':rep,'variant':'old' if v==0 else 'final','ms':ms,'exit':q.returncode,'sha256_lf':sha(result),'stderr':q.stderr.decode('utf8','replace')};out['runs'].append(row);save()
    if q.returncode or row['sha256_lf']!=expected['max_random_00.out']:raise RuntimeError('wrong output')
  for v in ['old','final']:
   print(name,v,round(statistics.median(s['ms'] for s in out['runs'] if s['mode']==name and s['rep']>=0 and s['variant']==v),3),flush=True)
  inp.unlink();result.unlink()
 out['status']='complete'
except BaseException as e:
 out['status']='failed';out['error']=repr(e);save();raise
save()
