#include <algorithm>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <random>
#include <string>
#include <vector>
#include "baseline_renamed.hpp"
#include "final.hpp"
int main(int, char** argv) {
  int variant=std::stoi(argv[1]), mode=std::stoi(argv[2]), n=std::stoi(argv[3]), reps=std::stoi(argv[4]);
  std::mt19937_64 rng(20261117);std::vector<std::uint64_t>a(n),b(n);
  for(auto& x:a)x=rng();for(auto& x:b)x=rng();
  auto start=std::chrono::steady_clock::now();std::uint64_t checksum=0;
  for(int rep=0;rep<reps;++rep){
    auto c=variant ? (mode?blueberry::lcm_convolution(a,b):blueberry::gcd_convolution(a,b)) : (mode?blueberry_old::lcm_convolution(a,b):blueberry_old::gcd_convolution(a,b));
    for(std::size_t i=0;i<c.size();i+=std::max<std::size_t>(1,c.size()/101))checksum+=c[i];
  }
  auto ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
  std::cout<<variant<<' '<<mode<<' '<<n<<' '<<reps<<' '<<ms<<' '<<checksum<<'\n';
}
