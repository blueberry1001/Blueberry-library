#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <random>
#include <vector>
#include "baseline.hpp"
#include "candidate.hpp"
using namespace std;
struct Matrix {
 array<uint64_t,4> v{};
 Matrix& operator+=(const Matrix& o){for(int k=0;k<4;k++)v[k]=(v[k]+o.v[k])%101;return *this;}
 Matrix& operator-=(const Matrix& o){for(int k=0;k<4;k++)v[k]=(v[k]+101-o.v[k])%101;return *this;}
 Matrix& operator*=(const Matrix& o){auto x=v;v={(x[0]*o.v[0]+x[1]*o.v[2])%101,(x[0]*o.v[1]+x[1]*o.v[3])%101,(x[2]*o.v[0]+x[3]*o.v[2])%101,(x[2]*o.v[1]+x[3]*o.v[3])%101};return *this;}
};
bool eq(const vector<Matrix>&a,const vector<Matrix>&b){if(a.size()!=b.size())return false;for(size_t i=0;i<a.size();++i)if(a[i].v!=b[i].v)return false;return true;}
void fail(const char*label,int n,int seed){cerr<<"FAIL "<<label<<" n="<<n<<" seed="<<seed<<'\n';exit(1);}
int main(){
 Matrix x{{1,1,0,1}},y{{1,0,1,1}};auto xy=x,yx=y;xy*=y;yx*=x;if(xy.v==yx.v)abort();
 for(int seed:{7,29})for(int n:{0,1,2,31,127,510,511,512,513,514,1024}){
  mt19937 rng(seed*123+n);vector<Matrix>a(n),b(n);for(auto&e:a)for(auto&v:e.v)v=rng()%101;for(auto&e:b)for(auto&v:e.v)v=rng()%101;
  auto dz=a,mz=a,old_dz=a,old_mz=a;blueberry::divisor_zeta(dz);blueberry::multiple_zeta(mz);old_blueberry::divisor_zeta(old_dz);old_blueberry::multiple_zeta(old_mz);
  if(!eq(dz,old_dz)||!eq(mz,old_mz))fail("zeta",n,seed);
  for(int i=1;i<n;++i){Matrix d{},m{};for(int j=1;j<n;++j){if(i%j==0)d+=a[j];if(j%i==0)m+=a[j];}if(d.v!=dz[i].v||m.v!=mz[i].v)fail("zeta-naive",n,seed);}
  blueberry::divisor_mobius(dz);blueberry::multiple_mobius(mz);if(!eq(dz,a)||!eq(mz,a))fail("inversion",n,seed);
  auto g=blueberry::gcd_convolution(a,b),l=blueberry::lcm_convolution(a,b);auto og=old_blueberry::gcd_convolution(a,b),ol=old_blueberry::lcm_convolution(a,b);
  if(!eq(g,og)||!eq(l,ol))fail("baseline",n,seed);
  vector<Matrix> bg(n),bl(n);for(int i=1;i<n;++i)for(int j=1;j<n;++j){auto product=a[i];product*=b[j];bg[gcd(i,j)]+=product;int k=lcm(i,j);if(k<n)bl[k]+=product;}
  if(!eq(g,bg)||!eq(l,bl))fail("brute",n,seed);
 }
 cout<<"OK noncommutative ring, +=/-=/*= only; sizes=0,1,2,31,127,510..514,1024; seeds=7,29\n";
}
