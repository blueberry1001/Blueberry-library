import hashlib, json, os, platform, statistics, subprocess
from pathlib import Path
here = Path(__file__).resolve().parent
vc = Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808')
sdk = Path(r'C:\Program Files (x86)\Windows Kits\10')
version = '10.0.22621.0'
msvc = vc / 'bin/Hostx64/x64/cl.exe'
clang = Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env = os.environ.copy()
env['PATH'] = str(msvc.parent) + os.pathsep + env.get('PATH', '')
env['INCLUDE'] = os.pathsep.join(map(str, [vc/'include', *(sdk/'Include'/version/p for p in ('ucrt','shared','um'))]))
env['LIB'] = os.pathsep.join(map(str, [vc/'lib/x64', *(sdk/'Lib'/version/p/'x64' for p in ('ucrt','um'))]))
out = {'status':'running','platform':platform.platform(),'cpu':platform.processor(),'note':'Unpinned shared Windows CPU; wall time includes copies, allocation, transform, pointwise multiplication and checksumming; input generation is outside the timed region. Nyaan normalized index 0; only nonempty gcd. GCC/Clang on Linux unmeasured.','hashes':{x:hashlib.sha256((here/x).read_bytes()).hexdigest() for x in ['baseline.hpp','baseline_renamed.hpp','final.hpp','candidate.hpp','candidate1.hpp','nyaan.hpp','driver.cpp']},'results':[]}
def save(): (here/'results.json').write_text(json.dumps(out, indent=2)+'\n')
try:
 for compiler in ['msvc','clang']:
  exe=here/(compiler+'.exe')
  if compiler=='msvc': cmd=[str(msvc),'/nologo','/std:c++20','/EHsc','/O2','/DNDEBUG',str(here/'driver.cpp'),'/Fo'+str(here/'msvc.obj'),'/Fe'+str(exe)]
  else: cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG',str(here/'driver.cpp'),'-o',str(exe)]
  p=subprocess.run(cmd,cwd=here,env=env,capture_output=True,text=True,errors='replace')
  row={'compiler':compiler,'compile':cmd,'compile_exit':p.returncode,'compile_output':p.stdout+p.stderr,'tests':[],'samples':[]};out['results'].append(row);save()
  if p.returncode: raise RuntimeError('compile failed '+compiler)
  for seed in [1,2,17]:
   p=subprocess.run([str(exe),str(seed)],env=env,capture_output=True,text=True,errors='replace',timeout=120)
   row['tests'].append({'seed':seed,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});save()
   if p.returncode: raise RuntimeError('test failed')
  for mode in [0,1]:
   for n,reps in [(16,40000),(128,5000),(511,1000),(512,1000),(4096,40),(65536,4),(1000001,1)]:
    variants=[0,2,4] if mode==0 else [0,4]
    checksums=set()
    for rep in range(-1,5):
     order=variants[rep%len(variants):]+variants[:rep%len(variants)]
     for v in order:
      p=subprocess.run([str(exe),str(v),str(mode),str(n),str(reps)],env=env,capture_output=True,text=True,errors='replace',timeout=120)
      if p.returncode: raise RuntimeError('run failed '+p.stdout+p.stderr)
      fields=p.stdout.split(); sample={'mode':mode,'n':n,'reps':reps,'rep':rep,'variant':v,'ms':float(fields[4]),'checksum':fields[5]}
      checksums.add(fields[5]);row['samples'].append(sample);save()
     if len(checksums)!=1: raise RuntimeError('checksum mismatch '+str(checksums))
    print(compiler,mode,n,[(v,round(statistics.median(s['ms'] for s in row['samples'] if s['mode']==mode and s['n']==n and s['variant']==v and s['rep']>=0),3)) for v in variants],flush=True)
 out['status']='complete'
except BaseException as e:
 out['status']='failed';out['error']=repr(e);save();raise
save()
