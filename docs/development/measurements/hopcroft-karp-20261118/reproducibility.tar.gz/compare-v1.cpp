#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <random>
#include <utility>
#include <vector>
#define blueberry baseline
#include "baseline.hpp"
#undef blueberry
#define blueberry candidate
#include "candidate.hpp"
#undef blueberry
using Edges=std::vector<std::pair<int,int>>;
int brute(int n,int m,const Edges& edges) {
  std::vector<int> masks(n); for(auto [u,v]:edges)masks[u]|=1<<v;
  std::vector<int> dp(1<<m,-1);dp[0]=0;
  for(int u=0;u<n;u++){auto next=dp;for(int mask=0;mask<(1<<m);mask++)if(dp[mask]>=0)for(int v=0;v<m;v++)if((masks[u]>>v&1)&&!(mask>>v&1))next[mask|1<<v]=std::max(next[mask|1<<v],dp[mask]+1);dp.swap(next);}
  return *std::max_element(dp.begin(),dp.end());
}
template<class M> bool valid(const M& x,int n,int m,const Edges& edges,int expected){
 if(x.size()!=expected)return false;auto pairs=x.pairs();if((int)pairs.size()!=expected)return false;
 std::vector<int> left(n,-1),right(m,-1);for(auto [u,v]:pairs){if(u<0||u>=n||v<0||v>=m||left[u]!=-1||right[v]!=-1||std::find(edges.begin(),edges.end(),std::pair{u,v})==edges.end())return false;left[u]=v;right[v]=u;}
 for(int i=0;i<n;i++)if(x.left_match(i)!=left[i])return false;for(int i=0;i<m;i++)if(x.right_match(i)!=right[i])return false;
 auto [a,b]=x.min_vertex_cover();if((int)(a.size()+b.size())!=expected)return false;
 std::vector<char> coverl(n),coverr(m);for(auto i:a)coverl[i]=1;for(auto i:b)coverr[i]=1;for(auto [u,v]:edges)if(!coverl[u]&&!coverr[v])return false;return true;
}
int main(int argc,char**argv) {
 std::mt19937 rng(891247);
 if(argc==1){for(int rep=0;rep<25000;rep++){int n=rng()%9,m=rng()%9;Edges e; if(n&&m)for(int j=0;j<int(rng()%80);j++)e.emplace_back(rng()%n,rng()%m);int ans=brute(n,m,e);baseline::HopcroftKarp a(n,m,e);candidate::HopcroftKarp b(n,m,e);if(!valid(a,n,m,e,ans)||!valid(b,n,m,e,ans)){std::printf("FAILED %d n=%d m=%d\n",rep,n,m);return 1;}}std::puts("OK: 25000 randomized graphs with cover and brute force");return 0;}
 int version=std::atoi(argv[1]),n=std::atoi(argv[2]),kind=std::atoi(argv[3]),reps=std::atoi(argv[4]);int m=kind==5?n/4:n;Edges edges;
 if(kind==0)for(int i=0;i<n;i++)edges.emplace_back(i,i);
 if(kind==1||kind==2){int deg=kind==1?3:8;for(int i=0;i<n;i++)for(int j=0;j<deg;j++)edges.emplace_back(i,int(rng()%m));}
 if(kind==3)for(int i=0;i<n;i++)for(int j=0;j<4;j++)edges.emplace_back(i,0);
 if(kind==4){for(int i=0;i<n-1;i++){edges.emplace_back(i,i);edges.emplace_back(i,i+1);}edges.emplace_back(n-1,0);}
 if(kind==5)for(int i=0;i<n;i++)for(int j=0;j<4;j++)edges.emplace_back(i,int(rng()%m));
 if(kind==7)for(int i=0;i<n;i++)for(int j=0;j<3;j++)edges.emplace_back(i,(i+j)%m);
 long long hash=0;auto start=std::chrono::steady_clock::now();
 for(int i=0;i<reps;i++){if(version){candidate::HopcroftKarp x(n,m,edges);hash+=x.size();}else{baseline::HopcroftKarp x(n,m,edges);hash+=x.size();}}
 std::printf("%.6f %lld %zu\n",std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count(),hash,edges.size());
}
