#include <algorithm>
#include <chrono>
#include <cstdio>
#include <iostream>
#include <utility>
#include <vector>
#define blueberry baseline
#include "baseline.hpp"
#undef blueberry
#define blueberry candidate
#include "candidate.hpp"
#undef blueberry
template<class M> bool validate(const M& h,int n,int m,const std::vector<std::pair<int,int>>& e) {
 auto pairs=h.pairs(); if(int(pairs.size())!=h.size())return false;
 std::vector<char> found(n),left(n),right(m),taken(n),takev(m);
 for(auto [u,v]:pairs){if(u<0||u>=n||v<0||v>=m||taken[u]||takev[v]||h.left_match(u)!=v||h.right_match(v)!=u)return false;taken[u]=takev[v]=1;}
 for(auto [u,v]:e)if(taken[u]&&h.left_match(u)==v)found[u]=1;
 for(auto [u,v]:pairs)if(!found[u])return false;
 auto [a,b]=h.min_vertex_cover();if(int(a.size()+b.size())!=h.size())return false;
 for(auto u:a)left[u]=1;for(auto v:b)right[v]=1;
 for(auto [u,v]:e)if(!left[u]&&!right[v])return false;return true;
}
int main(int argc,char**argv){
 if(argc!=2)return 2;std::ios::sync_with_stdio(false);std::cin.tie(nullptr);
 int n,m,k;std::cin>>n>>m>>k;std::vector<std::pair<int,int>> e(k);for(auto& [u,v]:e)std::cin>>u>>v;
 auto t=std::chrono::steady_clock::now();int result;
 if(argv[1][0]=='0') {baseline::HopcroftKarp h(n,m,e);auto end=std::chrono::steady_clock::now();result=h.size();if(!validate(h,n,m,e))return 3;std::printf("%.6f %d\n",std::chrono::duration<double,std::milli>(end-t).count(),result);}
 else {candidate::HopcroftKarp h(n,m,e);auto end=std::chrono::steady_clock::now();result=h.size();if(!validate(h,n,m,e))return 4;std::printf("%.6f %d\n",std::chrono::duration<double,std::milli>(end-t).count(),result);}
}
