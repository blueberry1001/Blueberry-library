import ctypes,hashlib,json,os,pathlib,platform,subprocess,time,tomllib,traceback
p=pathlib.Path(__file__).resolve().parent;g=p/'official/gen';inputs=p/'official/inputs';inputs.mkdir(exist_ok=True)
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.43.34808');sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10');v='10.0.22621.0'
clang=pathlib.Path(r'C:\Program Files\Unity\Hub\Editor\6000.5.2f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe')
env=os.environ.copy();env['PATH']=str(vc/'bin/Hostx64/x64')+os.pathsep+env['PATH'];env['INCLUDE']=os.pathsep.join(map(str,[vc/'include',*(sdk/'Include'/v/x for x in ('ucrt','shared','um'))]));env['LIB']=os.pathsep.join(map(str,[vc/'lib/x64',*(sdk/'Lib'/v/x/'x64' for x in ('ucrt','um'))]))
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<8)
info=tomllib.loads((p/'official/info.toml').read_text(encoding='utf8'));expected=json.loads((p/'official/hash.json').read_text(encoding='utf8'));d={'status':'running','revision':'73876f1cbcf082d2b22722924b924d3d65a2f00e','platform':platform.platform(),'affinity':'0x100','builds':[],'tests':[]}
def save(): (p/'official-results.json').write_text(json.dumps(d,indent=2)+'\n')
def build(src,exe):
 cmd=[str(clang),'--target=x86_64-pc-windows-msvc','-fuse-ld=link','-std=gnu++20','-O2','-DNDEBUG',str(src),'-o',str(exe)]
 r=subprocess.run(cmd,cwd=p,env=env,capture_output=True,text=True,errors='replace',timeout=180);d['builds'].append({'cmd':cmd,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});save()
 if r.returncode:raise RuntimeError('build failed '+str(src))
def solve(exe,ver,input_data):
 t=time.perf_counter();r=subprocess.run([str(exe),str(ver)],input=input_data,capture_output=True,env=env,timeout=120);return {'version':ver,'exit':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace'),'process_ms':1000*(time.perf_counter()-t)}
try:
 exe=p/'official-solver.exe';build(p/'official_driver.cpp',exe)
 for test in info['tests']:
  name=test['name'];count=test['number'];stem=pathlib.Path(name).stem
  if name.endswith('.cpp'): generator=inputs/(stem+'.exe');build(g/name,generator)
  for seed in range(count):
   case=stem+f'_{seed:02d}.in'
   if name.endswith('.cpp'):
    result=subprocess.run([str(generator),str(seed)],cwd=p,env=env,capture_output=True,timeout=120)
    if result.returncode:raise RuntimeError('generator failed '+case+' '+result.stderr.decode(errors='replace'))
    data=result.stdout.replace(b'\r\n',b'\n')
   else:data=(g/case).read_bytes().replace(b'\r\n',b'\n')
   digest=hashlib.sha256(data).hexdigest();row={'case':case,'bytes':len(data),'sha256':digest,'expected':expected[case],'runs':[]};d['tests'].append(row);save()
   if digest!=row['expected']:raise RuntimeError('input hash mismatch '+case)
   for sample in range(3 if stem in ('cycle','line_random','unique_matching','augmented_cycle','max_random') else 1):
    results=[]
    for ver in ([0,1] if sample%2==0 else [1,0]):
     x=solve(exe,ver,data);x['sample']=sample;row['runs'].append(x);save()
     if x['exit']:raise RuntimeError('certificate failure '+case+' '+str(ver))
     results.append(x['stdout'].split()[1])
    if len(set(results))!=1:raise RuntimeError('cardinality mismatch '+case)
 d['status']='complete';save()
except BaseException:
 d['status']='failed';d['traceback']=traceback.format_exc();save();raise
