#define main compare_original_main
#include "compare.cpp"
#undef main
int main() {
 for(int bits=0;bits<(1<<16);++bits) {
  Edges edges;
  for(int u=0;u<4;++u)for(int v=0;v<4;++v)if(bits>>(u*4+v)&1)edges.emplace_back(u,v);
  int expected=brute(4,4,edges);
  baseline::HopcroftKarp a(4,4,edges);candidate::HopcroftKarp b(4,4,edges);
  if(!valid(a,4,4,edges,expected)||!valid(b,4,4,edges,expected)){std::printf("FAILED mask=%d\n",bits);return 1;}
 }
 std::puts("OK: 65536 simple bipartite graphs with brute and covers");
}
