import ctypes,hashlib,json,os,pathlib,subprocess,time,traceback
p=pathlib.Path(__file__).resolve().parent;expected=json.loads((p/'official/hash.json').read_text(encoding='utf8'));env=os.environ.copy()
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),1<<8)
d={'status':'running','affinity':'0x100','tests':[]}
def save(): (p/'official-remeasure.json').write_text(json.dumps(d,indent=2)+'\n')
try:
 for name,seed in [('unique_matching',0),('unique_matching',2),('augmented_cycle',1),('augmented_cycle',2),('cycle',0),('line_random',0),('max_random',0)]:
  case=name+f'_{seed:02d}.in';gen=p/'official/inputs'/(name+'.exe');r=subprocess.run([str(gen),str(seed)],capture_output=True,env=env,timeout=120)
  if r.returncode:raise RuntimeError('generator failed')
  data=r.stdout.replace(b'\r\n',b'\n');digest=hashlib.sha256(data).hexdigest()
  if digest!=expected[case]:raise RuntimeError('digest failed')
  row={'case':case,'sha256':digest,'runs':[]};d['tests'].append(row)
  for sample in range(-1,7):
   for version in ([0,1] if sample%2 else [1,0]):
    t=time.perf_counter();r=subprocess.run([str(p/'official-solver.exe'),str(version)],input=data,capture_output=True,env=env,timeout=120);x={'sample':sample,'version':version,'exit':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace'),'process_ms':1000*(time.perf_counter()-t)};row['runs'].append(x);save()
    if r.returncode:raise RuntimeError('solver failed')
 d['status']='complete';save()
except BaseException:
 d['status']='failed';d['traceback']=traceback.format_exc();save();raise
