#pragma once
#define L_MAX 100000
#define R_MAX 100000
#define M_MAX 200000
