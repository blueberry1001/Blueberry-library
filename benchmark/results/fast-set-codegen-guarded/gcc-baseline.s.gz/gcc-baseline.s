	.file	"fast-set-assembly-codegen.cpp"
	.text
	.p2align 4
	.globl	next_set
	.type	next_set, @function
next_set:
.LFB2878:
	.cfi_startproc
	endbr64
	movl	(%rdi), %edx
	cmpl	%edx, %esi
	jge	.L15
	movl	4(%rdi), %eax
	testl	%eax, %eax
	je	.L15
	movabsq	$-6148914691236517205, %r8
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	xorl	%eax, %eax
	testl	%esi, %esi
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	16(%rdi), %rcx
	cmovs	%eax, %esi
	movq	8(%rdi), %rdi
	movq	%rcx, %rax
	movslq	%esi, %rsi
	subq	%rdi, %rax
	sarq	$3, %rax
	imulq	%r8, %rax
	movq	%rax, %rbx
	cmpq	%rdi, %rcx
	je	.L1
	movq	%rdi, %r11
	xorl	%r10d, %r10d
	movq	$-1, %rbp
.L4:
	movq	(%r11), %r9
	movq	8(%r11), %rax
	movq	%rsi, %r8
	shrq	$6, %r8
	subq	%r9, %rax
	sarq	$3, %rax
	cmpq	%rax, %r8
	jnb	.L1
	movl	%esi, %ecx
	movq	%rbp, %rax
	salq	%cl, %rax
	andq	(%r9,%r8,8), %rax
	je	.L19
	rep bsfq	%rax, %rax
	andq	$-64, %rsi
	cltq
	addq	%rsi, %rax
	testq	%r10, %r10
	je	.L5
	leaq	(%r10,%r10,2), %rdx
	movl	$64, %r8d
	leaq	-24(%rdi,%rdx,8), %rdx
	jmp	.L7
	.p2align 4,,10
	.p2align 3
.L9:
	movq	%rcx, %rdx
.L7:
	movq	(%rdx), %rcx
	movq	%rax, %rsi
	salq	$6, %rsi
	movq	(%rcx,%rax,8), %rcx
	xorl	%eax, %eax
	rep bsfq	%rcx, %rax
	testq	%rcx, %rcx
	leaq	-24(%rdx), %rcx
	cltq
	cmove	%r8, %rax
	addq	%rsi, %rax
	cmpq	%rdi, %rdx
	jne	.L9
.L5:
	movl	%eax, %edx
.L1:
	movl	%edx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L15:
	.cfi_restore 3
	.cfi_restore 6
	movl	%edx, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L19:
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	.cfi_offset 6, -16
	addq	$1, %r10
	leaq	1(%r8), %rsi
	addq	$24, %r11
	cmpq	%rbx, %r10
	jb	.L4
	jmp	.L1
	.cfi_endproc
.LFE2878:
	.size	next_set, .-next_set
	.p2align 4
	.globl	prev_set
	.type	prev_set, @function
prev_set:
.LFB2879:
	.cfi_startproc
	endbr64
	testl	%esi, %esi
	js	.L31
	movl	4(%rdi), %eax
	testl	%eax, %eax
	je	.L31
	movl	(%rdi), %eax
	movq	8(%rdi), %r9
	leal	-1(%rax), %ecx
	movq	16(%rdi), %rax
	cmpl	%esi, %ecx
	movq	%rax, %r11
	cmovg	%esi, %ecx
	movabsq	$-6148914691236517205, %rsi
	subq	%r9, %r11
	sarq	$3, %r11
	movslq	%ecx, %rdx
	imulq	%rsi, %r11
	cmpq	%r9, %rax
	je	.L31
	movq	%rdx, %rax
	movq	(%r9), %rsi
	notl	%ecx
	movq	$-1, %r10
	shrq	$6, %rax
	shrq	%cl, %r10
	andq	(%rsi,%rax,8), %r10
	jne	.L28
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	24(%r9), %rdi
	movq	$-1, %rbx
	jmp	.L29
	.p2align 4,,10
	.p2align 3
.L41:
	addq	$1, %r10
	leaq	-1(%rax), %rdx
	cmpq	%r11, %r10
	jnb	.L32
	negq	%rax
	movq	(%rdi), %r8
	movq	%rdx, %rsi
	addq	$24, %rdi
	movq	%rax, %rcx
	shrq	$6, %rsi
	movq	%rbx, %rax
	shrq	%cl, %rax
	andq	(%r8,%rsi,8), %rax
	jne	.L23
	movq	%rsi, %rax
.L29:
	cmpq	$63, %rdx
	ja	.L41
.L32:
	movl	$-1, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L23:
	.cfi_restore_state
	orq	$63, %rdx
	bsrq	%rax, %rax
	xorl	$63, %eax
	subq	%rax, %rdx
	leaq	(%r10,%r10,2), %rax
	leaq	-24(%r9,%rax,8), %rcx
	jmp	.L27
	.p2align 4,,10
	.p2align 3
.L34:
	movq	%rax, %rcx
.L27:
	movq	(%rcx), %rax
	movq	%rdx, %rsi
	salq	$6, %rsi
	movq	(%rax,%rdx,8), %rdx
	movl	$64, %eax
	testq	%rdx, %rdx
	je	.L26
	bsrq	%rdx, %rax
	xorl	$63, %eax
.L26:
	leaq	63(%rsi), %rdx
	subq	%rax, %rdx
	leaq	-24(%rcx), %rax
	cmpq	%rcx, %r9
	jne	.L34
	movl	%edx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L31:
	.cfi_restore 3
	movl	$-1, %eax
	ret
.L28:
	orq	$63, %rdx
	bsrq	%r10, %r10
	xorl	$63, %r10d
	subq	%r10, %rdx
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE2879:
	.size	prev_set, .-prev_set
	.section	.rodata._ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_.str1.1,"aMS",@progbits,1
.LC0:
	.string	"vector::_M_realloc_insert"
	.section	.rodata._ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_.str1.8,"aMS",@progbits,1
	.align 8
.LC1:
	.string	"cannot create std::vector larger than max_size()"
	.section	.text._ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"axG",@progbits,_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.type	_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, @function
_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_:
.LFB3341:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA3341
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	movabsq	$-6148914691236517205, %rcx
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	8(%rdi), %rbp
	movq	(%rdi), %r12
	movq	%rbp, %rax
	subq	%r12, %rax
	sarq	$3, %rax
	imulq	%rcx, %rax
	movabsq	$384307168202282325, %rcx
	cmpq	%rcx, %rax
	je	.L85
	movq	%rbx, %r14
	movq	%rdi, %r13
	subq	%r12, %r14
	cmpq	%rbp, %r12
	je	.L86
	leaq	(%rax,%rax), %rdi
	movq	%rdi, 8(%rsp)
	cmpq	%rax, %rdi
	jb	.L64
	testq	%rdi, %rdi
	jne	.L87
	xorl	%r15d, %r15d
.L48:
	movq	(%rsi), %rax
	movl	(%rdx), %esi
	addq	%r15, %r14
	movl	%esi, 16(%rsp)
	movq	%rax, %rsi
	shrq	$60, %rsi
	jne	.L88
	pxor	%xmm0, %xmm0
	movq	$0, 16(%r14)
	movups	%xmm0, (%r14)
	testq	%rax, %rax
	je	.L50
	salq	$3, %rax
	movq	%rax, %rdi
	movq	%rax, 24(%rsp)
.LEHB0:
	call	_Znwm@PLT
.LEHE0:
	movq	24(%rsp), %rdx
	movslq	16(%rsp), %rcx
	movq	%rax, (%r14)
	addq	%rax, %rdx
	movq	%rdx, %rsi
	movq	%rdx, 16(%r14)
	subq	%rax, %rsi
	andl	$8, %esi
	je	.L51
	movq	%rcx, (%rax)
	addq	$8, %rax
	cmpq	%rdx, %rax
	je	.L52
	.p2align 4,,10
	.p2align 3
.L51:
	movq	%rcx, (%rax)
	addq	$16, %rax
	movq	%rcx, -8(%rax)
	cmpq	%rdx, %rax
	jne	.L51
.L52:
	movq	%rdx, 8(%r14)
	cmpq	%r12, %rbx
	je	.L66
	movq	%r12, %rax
	movq	%r15, %rdx
	.p2align 4,,10
	.p2align 3
.L54:
	movdqu	(%rax), %xmm1
	movq	16(%rax), %rcx
	addq	$24, %rax
	addq	$24, %rdx
	movups	%xmm1, -24(%rdx)
	movq	%rcx, -8(%rdx)
	cmpq	%rax, %rbx
	jne	.L54
	leaq	-24(%rbx), %rax
	subq	%r12, %rax
	shrq	$3, %rax
	leaq	24(%r15,%rax,8), %r14
.L53:
	addq	$24, %r14
	cmpq	%rbp, %rbx
	je	.L55
	movq	%rbx, %rax
	movq	%r14, %rdx
	.p2align 4,,10
	.p2align 3
.L56:
	movdqu	(%rax), %xmm2
	movq	16(%rax), %rcx
	addq	$24, %rax
	addq	$24, %rdx
	movups	%xmm2, -24(%rdx)
	movq	%rcx, -8(%rdx)
	cmpq	%rax, %rbp
	jne	.L56
	subq	%rbx, %rbp
	leaq	-24(%rbp), %rax
	shrq	$3, %rax
	leaq	24(%r14,%rax,8), %r14
.L55:
	testq	%r12, %r12
	je	.L57
	movq	16(%r13), %rsi
	movq	%r12, %rdi
	subq	%r12, %rsi
	call	_ZdlPvm@PLT
.L57:
	movq	8(%rsp), %rax
	movq	%r15, 0(%r13)
	movq	%r14, 8(%r13)
	leaq	(%rax,%rax,2), %rax
	leaq	(%r15,%rax,8), %rax
	movq	%rax, 16(%r13)
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L64:
	.cfi_restore_state
	movabsq	$9223372036854775800, %rdi
	movq	%rcx, 8(%rsp)
.L47:
	movq	%rdx, 24(%rsp)
	movq	%rsi, 16(%rsp)
.LEHB1:
	call	_Znwm@PLT
.LEHE1:
	movq	16(%rsp), %rsi
	movq	24(%rsp), %rdx
	movq	%rax, %r15
	jmp	.L48
	.p2align 4,,10
	.p2align 3
.L50:
	movq	$0, (%r14)
	xorl	%edx, %edx
	movq	$0, 16(%r14)
	jmp	.L52
	.p2align 4,,10
	.p2align 3
.L86:
	addq	$1, %rax
	jc	.L64
	movabsq	$384307168202282325, %rcx
	cmpq	%rcx, %rax
	cmovbe	%rax, %rcx
	leaq	(%rcx,%rcx,2), %rdi
	movq	%rcx, 8(%rsp)
	salq	$3, %rdi
	jmp	.L47
	.p2align 4,,10
	.p2align 3
.L66:
	movq	%r15, %r14
	jmp	.L53
.L87:
	movabsq	$384307168202282325, %rax
	cmpq	%rax, %rdi
	cmovbe	%rdi, %rax
	leaq	(%rax,%rax,2), %rdi
	movq	%rax, 8(%rsp)
	salq	$3, %rdi
	jmp	.L47
.L88:
	leaq	.LC1(%rip), %rdi
.LEHB2:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE2:
.L85:
	leaq	.LC0(%rip), %rdi
.LEHB3:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE3:
.L67:
	endbr64
	movq	%rax, %rdi
.L58:
	call	__cxa_begin_catch@PLT
	testq	%r15, %r15
	je	.L89
	imulq	$24, 8(%rsp), %rsi
	movq	%r15, %rdi
	call	_ZdlPvm@PLT
.L62:
.LEHB4:
	call	__cxa_rethrow@PLT
.LEHE4:
.L89:
	movq	(%r14), %rdi
	movq	16(%r14), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L62
	call	_ZdlPvm@PLT
	jmp	.L62
.L68:
	endbr64
	movq	%rax, %rbx
.L61:
	call	__cxa_end_catch@PLT
	movq	%rbx, %rdi
.LEHB5:
	call	_Unwind_Resume@PLT
.LEHE5:
	.cfi_endproc
.LFE3341:
	.globl	__gxx_personality_v0
	.section	.gcc_except_table._ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"aG",@progbits,_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.align 4
.LLSDA3341:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATT3341-.LLSDATTD3341
.LLSDATTD3341:
	.byte	0x1
	.uleb128 .LLSDACSE3341-.LLSDACSB3341
.LLSDACSB3341:
	.uleb128 .LEHB0-.LFB3341
	.uleb128 .LEHE0-.LEHB0
	.uleb128 .L67-.LFB3341
	.uleb128 0x1
	.uleb128 .LEHB1-.LFB3341
	.uleb128 .LEHE1-.LEHB1
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB2-.LFB3341
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L67-.LFB3341
	.uleb128 0x1
	.uleb128 .LEHB3-.LFB3341
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB4-.LFB3341
	.uleb128 .LEHE4-.LEHB4
	.uleb128 .L68-.LFB3341
	.uleb128 0
	.uleb128 .LEHB5-.LFB3341
	.uleb128 .LEHE5-.LEHB5
	.uleb128 0
	.uleb128 0
.LLSDACSE3341:
	.byte	0x1
	.byte	0
	.align 4
	.long	0

.LLSDATT3341:
	.section	.text._ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"axG",@progbits,_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.size	_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, .-_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.section	.text._ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,"axG",@progbits,_ZN9blueberry7FastSetC5ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,comdat
	.align 2
	.p2align 4
	.weak	_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.type	_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE, @function
_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE:
.LFB2845:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2845
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pxor	%xmm0, %xmm0
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rsi, %r14
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	xorl	%ebp, %ebp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	movq	8(%rsi), %rbx
	movq	%fs:40, %rax
	movq	%rax, 40(%rsp)
	xorl	%eax, %eax
	leaq	8(%rdi), %rax
	movl	$0, 4(%rdi)
	movq	%rax, 8(%rsp)
	movq	$0, 24(%rdi)
	movl	%ebx, (%rdi)
	movslq	%ebx, %rbx
	movups	%xmm0, 8(%rdi)
.L91:
	testq	%rbx, %rbx
	je	.L94
.L95:
	addq	$63, %rbx
	movl	$0, 28(%rsp)
	shrq	$6, %rbx
	movq	%rbx, 32(%rsp)
	cmpq	24(%r12), %rbp
	je	.L92
	pxor	%xmm1, %xmm1
	movq	$0, 16(%rbp)
	movups	%xmm1, 0(%rbp)
	testq	%rbx, %rbx
	je	.L93
	leaq	0(,%rbx,8), %r13
	movq	%r13, %rdi
.LEHB6:
	call	_Znwm@PLT
	leaq	(%rax,%r13), %r15
	movq	%rax, 0(%rbp)
	movq	%rax, %rdi
	movq	%r13, %rdx
	movq	%r15, 16(%rbp)
	xorl	%esi, %esi
	call	memset@PLT
	movq	16(%r12), %rax
	movq	%r15, 8(%rbp)
	leaq	24(%rax), %rbp
	movq	%rbp, 16(%r12)
	cmpq	$1, %rbx
	jne	.L95
	.p2align 4,,10
	.p2align 3
.L94:
	movslq	(%r12), %rsi
	movq	8(%r12), %r9
	testl	%esi, %esi
	jle	.L107
	movq	(%r14), %rdi
	xorl	%eax, %eax
	movl	$1, %r10d
	.p2align 4,,10
	.p2align 3
.L106:
	cmpb	$49, (%rdi,%rax)
	jne	.L105
	movl	%eax, %edx
	movq	(%r9), %r8
	movl	%eax, %ecx
	movq	%r10, %rbx
	sarl	$6, %edx
	salq	%cl, %rbx
	addl	$1, 4(%r12)
	movslq	%edx, %rdx
	orq	%rbx, (%r8,%rdx,8)
.L105:
	addq	$1, %rax
	cmpq	%rsi, %rax
	jne	.L106
.L107:
	movabsq	$-6148914691236517205, %rax
	subq	%r9, %rbp
	movq	%rbp, %rbx
	sarq	$3, %rbx
	imulq	%rax, %rbx
	cmpq	$24, %rbp
	jbe	.L90
	movl	$1, %r11d
	movl	$1, %r10d
	.p2align 4,,10
	.p2align 3
.L98:
	movq	8(%r9), %rdx
	movq	(%r9), %rdi
	xorl	%eax, %eax
	movq	%rdx, %r8
	subq	%rdi, %r8
	sarq	$3, %r8
	cmpq	%rdi, %rdx
	je	.L110
	.p2align 4,,10
	.p2align 3
.L109:
	cmpq	$0, (%rdi,%rax,8)
	je	.L108
	movq	24(%r9), %rdx
	movq	%rax, %rsi
	movl	%eax, %ecx
	movq	%r10, %r14
	shrq	$6, %rsi
	salq	%cl, %r14
	orq	%r14, (%rdx,%rsi,8)
.L108:
	addq	$1, %rax
	cmpq	%r8, %rax
	jb	.L109
.L110:
	addq	$1, %r11
	addq	$24, %r9
	cmpq	%rbx, %r11
	jb	.L98
.L90:
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L131
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L93:
	.cfi_restore_state
	movq	$0, 0(%rbp)
	addq	$24, %rbp
	movq	$0, -8(%rbp)
	movq	$0, -16(%rbp)
	movq	%rbp, 16(%r12)
	jmp	.L94
	.p2align 4,,10
	.p2align 3
.L92:
	movq	8(%rsp), %rdi
	leaq	28(%rsp), %rcx
	leaq	32(%rsp), %rdx
	movq	%rbp, %rsi
	call	_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
.LEHE6:
	movq	16(%r12), %rbp
	cmpq	$1, %rbx
	jne	.L91
	jmp	.L94
.L99:
	movq	16(%r12), %r13
	movq	8(%r12), %rbx
.L100:
	cmpq	%rbx, %r13
	jne	.L102
	movq	8(%r12), %rdi
	movq	24(%r12), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	jne	.L132
.L103:
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	je	.L104
.L131:
	call	__stack_chk_fail@PLT
.L113:
	endbr64
	movq	%rax, %rbp
	jmp	.L99
.L102:
	movq	(%rbx), %rdi
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L101
	call	_ZdlPvm@PLT
.L101:
	addq	$24, %rbx
	jmp	.L100
.L132:
	call	_ZdlPvm@PLT
	jmp	.L103
.L104:
	movq	%rbp, %rdi
.LEHB7:
	call	_Unwind_Resume@PLT
.LEHE7:
	.cfi_endproc
.LFE2845:
	.section	.gcc_except_table._ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,"aG",@progbits,_ZN9blueberry7FastSetC5ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,comdat
.LLSDA2845:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2845-.LLSDACSB2845
.LLSDACSB2845:
	.uleb128 .LEHB6-.LFB2845
	.uleb128 .LEHE6-.LEHB6
	.uleb128 .L113-.LFB2845
	.uleb128 0
	.uleb128 .LEHB7-.LFB2845
	.uleb128 .LEHE7-.LEHB7
	.uleb128 0
	.uleb128 0
.LLSDACSE2845:
	.section	.text._ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,"axG",@progbits,_ZN9blueberry7FastSetC5ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,comdat
	.size	_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE, .-_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.weak	_ZN9blueberry7FastSetC1ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.set	_ZN9blueberry7FastSetC1ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.section	.text.unlikely,"ax",@progbits
.LCOLDB2:
	.text
.LHOTB2:
	.p2align 4
	.globl	build_set
	.type	build_set, @function
build_set:
.LFB2877:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2877
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rdi, %rbp
	movl	$32, %edi
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
.LEHB8:
	call	_Znwm@PLT
.LEHE8:
	movq	%rbp, %rsi
	movq	%rax, %rdi
	movq	%rax, %rbx
.LEHB9:
	call	_ZN9blueberry7FastSetC1ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
.LEHE9:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L135:
	.cfi_restore_state
	endbr64
	movq	%rax, %rbp
	jmp	.L134
	.section	.gcc_except_table,"a",@progbits
.LLSDA2877:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2877-.LLSDACSB2877
.LLSDACSB2877:
	.uleb128 .LEHB8-.LFB2877
	.uleb128 .LEHE8-.LEHB8
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB9-.LFB2877
	.uleb128 .LEHE9-.LEHB9
	.uleb128 .L135-.LFB2877
	.uleb128 0
.LLSDACSE2877:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC2877
	.type	build_set.cold, @function
build_set.cold:
.LFSB2877:
.L134:
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -24
	.cfi_offset 6, -16
	movq	%rbx, %rdi
	movl	$32, %esi
	call	_ZdlPvm@PLT
	movq	%rbp, %rdi
.LEHB10:
	call	_Unwind_Resume@PLT
.LEHE10:
	.cfi_endproc
.LFE2877:
	.section	.gcc_except_table
.LLSDAC2877:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC2877-.LLSDACSBC2877
.LLSDACSBC2877:
	.uleb128 .LEHB10-.LCOLDB2
	.uleb128 .LEHE10-.LEHB10
	.uleb128 0
	.uleb128 0
.LLSDACSEC2877:
	.section	.text.unlikely
	.text
	.size	build_set, .-build_set
	.section	.text.unlikely
	.size	build_set.cold, .-build_set.cold
.LCOLDE2:
	.text
.LHOTE2:
	.hidden	DW.ref.__gxx_personality_v0
	.weak	DW.ref.__gxx_personality_v0
	.section	.data.rel.local.DW.ref.__gxx_personality_v0,"awG",@progbits,DW.ref.__gxx_personality_v0,comdat
	.align 8
	.type	DW.ref.__gxx_personality_v0, @object
	.size	DW.ref.__gxx_personality_v0, 8
DW.ref.__gxx_personality_v0:
	.quad	__gxx_personality_v0
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
