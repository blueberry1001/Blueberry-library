	.file	"fast-set-assembly-codegen.cpp"
	.text
	.section	.text._ZN9blueberry7FastSet9load_avx2EPKcPmi,"axG",@progbits,_ZN9blueberry7FastSet9load_avx2EPKcPmi,comdat
	.p2align 4
	.weak	_ZN9blueberry7FastSet9load_avx2EPKcPmi
	.type	_ZN9blueberry7FastSet9load_avx2EPKcPmi, @function
_ZN9blueberry7FastSet9load_avx2EPKcPmi:
.LFB9095:
	.cfi_startproc
	endbr64
	testl	%edx, %edx
	jle	.L4
	movslq	%edx, %rdx
	movl	$49, %eax
	salq	$6, %rdx
	vmovd	%eax, %xmm0
	leaq	(%rdi,%rdx), %rcx
	vpbroadcastb	%xmm0, %ymm0
	xorl	%edx, %edx
	.p2align 4,,10
	.p2align 3
.L3:
	vpcmpeqb	32(%rdi), %ymm0, %ymm2
	vpcmpeqb	(%rdi), %ymm0, %ymm1
	addq	$64, %rdi
	addq	$8, %rsi
	vpmovmskb	%ymm2, %eax
	vpmovmskb	%ymm1, %r8d
	salq	$32, %rax
	orq	%r8, %rax
	movq	%rax, -8(%rsi)
	popcntq	%rax, %rax
	addl	%eax, %edx
	cmpq	%rdi, %rcx
	jne	.L3
	movl	%edx, %eax
	vzeroupper
	ret
	.p2align 4,,10
	.p2align 3
.L4:
	xorl	%edx, %edx
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE9095:
	.size	_ZN9blueberry7FastSet9load_avx2EPKcPmi, .-_ZN9blueberry7FastSet9load_avx2EPKcPmi
	.text
	.p2align 4
	.globl	next_set
	.type	next_set, @function
next_set:
.LFB9097:
	.cfi_startproc
	endbr64
	movl	(%rdi), %edx
	cmpl	%edx, %esi
	jge	.L21
	movl	4(%rdi), %eax
	testl	%eax, %eax
	je	.L21
	movabsq	$-6148914691236517205, %r8
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	xorl	%eax, %eax
	testl	%esi, %esi
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	16(%rdi), %rcx
	cmovs	%eax, %esi
	movq	8(%rdi), %rdi
	movq	%rcx, %rax
	movslq	%esi, %rsi
	subq	%rdi, %rax
	sarq	$3, %rax
	imulq	%r8, %rax
	movq	%rax, %rbx
	cmpq	%rdi, %rcx
	je	.L7
	movq	%rdi, %r11
	xorl	%r10d, %r10d
	movq	$-1, %rbp
.L10:
	movq	(%r11), %r9
	movq	8(%r11), %rax
	movq	%rsi, %r8
	shrq	$6, %r8
	subq	%r9, %rax
	sarq	$3, %rax
	cmpq	%rax, %r8
	jnb	.L7
	movl	%esi, %ecx
	movq	%rbp, %rax
	salq	%cl, %rax
	andq	(%r9,%r8,8), %rax
	je	.L25
	rep bsfq	%rax, %rax
	andq	$-64, %rsi
	cltq
	addq	%rsi, %rax
	testq	%r10, %r10
	je	.L11
	leaq	(%r10,%r10,2), %rdx
	movl	$64, %r8d
	leaq	-24(%rdi,%rdx,8), %rdx
	jmp	.L13
	.p2align 4,,10
	.p2align 3
.L15:
	movq	%rcx, %rdx
.L13:
	movq	(%rdx), %rcx
	movq	%rax, %rsi
	salq	$6, %rsi
	movq	(%rcx,%rax,8), %rcx
	xorl	%eax, %eax
	rep bsfq	%rcx, %rax
	testq	%rcx, %rcx
	leaq	-24(%rdx), %rcx
	cltq
	cmove	%r8, %rax
	addq	%rsi, %rax
	cmpq	%rdi, %rdx
	jne	.L15
.L11:
	movl	%eax, %edx
.L7:
	movl	%edx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L21:
	.cfi_restore 3
	.cfi_restore 6
	movl	%edx, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L25:
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	.cfi_offset 6, -16
	addq	$1, %r10
	leaq	1(%r8), %rsi
	addq	$24, %r11
	cmpq	%rbx, %r10
	jb	.L10
	jmp	.L7
	.cfi_endproc
.LFE9097:
	.size	next_set, .-next_set
	.p2align 4
	.globl	prev_set
	.type	prev_set, @function
prev_set:
.LFB9098:
	.cfi_startproc
	endbr64
	testl	%esi, %esi
	js	.L37
	movl	4(%rdi), %eax
	testl	%eax, %eax
	je	.L37
	movl	(%rdi), %eax
	movq	8(%rdi), %r9
	leal	-1(%rax), %ecx
	movq	16(%rdi), %rax
	cmpl	%esi, %ecx
	movq	%rax, %r11
	cmovg	%esi, %ecx
	movabsq	$-6148914691236517205, %rsi
	subq	%r9, %r11
	sarq	$3, %r11
	movslq	%ecx, %rdx
	imulq	%rsi, %r11
	cmpq	%r9, %rax
	je	.L37
	movq	%rdx, %rax
	movq	(%r9), %rsi
	notl	%ecx
	movq	$-1, %r10
	shrq	$6, %rax
	shrq	%cl, %r10
	andq	(%rsi,%rax,8), %r10
	jne	.L34
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	24(%r9), %rdi
	movq	$-1, %rbx
	jmp	.L35
	.p2align 4,,10
	.p2align 3
.L47:
	addq	$1, %r10
	leaq	-1(%rax), %rdx
	cmpq	%r11, %r10
	jnb	.L38
	negq	%rax
	movq	(%rdi), %r8
	movq	%rdx, %rsi
	addq	$24, %rdi
	movq	%rax, %rcx
	shrq	$6, %rsi
	movq	%rbx, %rax
	shrq	%cl, %rax
	andq	(%r8,%rsi,8), %rax
	jne	.L29
	movq	%rsi, %rax
.L35:
	cmpq	$63, %rdx
	ja	.L47
.L38:
	movl	$-1, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L29:
	.cfi_restore_state
	orq	$63, %rdx
	bsrq	%rax, %rax
	xorl	$63, %eax
	subq	%rax, %rdx
	leaq	(%r10,%r10,2), %rax
	leaq	-24(%r9,%rax,8), %rcx
	jmp	.L33
	.p2align 4,,10
	.p2align 3
.L40:
	movq	%rax, %rcx
.L33:
	movq	(%rcx), %rax
	movq	%rdx, %rsi
	salq	$6, %rsi
	movq	(%rax,%rdx,8), %rdx
	movl	$64, %eax
	testq	%rdx, %rdx
	je	.L32
	bsrq	%rdx, %rax
	xorl	$63, %eax
.L32:
	leaq	63(%rsi), %rdx
	subq	%rax, %rdx
	leaq	-24(%rcx), %rax
	cmpq	%rcx, %r9
	jne	.L40
	movl	%edx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L37:
	.cfi_restore 3
	movl	$-1, %eax
	ret
.L34:
	orq	$63, %rdx
	bsrq	%r10, %r10
	xorl	$63, %r10d
	subq	%r10, %rdx
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE9098:
	.size	prev_set, .-prev_set
	.section	.text._ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev,"axG",@progbits,_ZNSt6vectorIS_ImSaImEESaIS1_EED5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev
	.type	_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev, @function
_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev:
.LFB9400:
	.cfi_startproc
	endbr64
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	8(%rdi), %rbp
	movq	(%rdi), %rbx
	cmpq	%rbx, %rbp
	je	.L49
	.p2align 4,,10
	.p2align 3
.L51:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L50
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L50:
	addq	$24, %rbx
	cmpq	%rbx, %rbp
	jne	.L51
	movq	(%r12), %rbx
.L49:
	testq	%rbx, %rbx
	je	.L48
	movq	16(%r12), %rsi
	movq	%rbx, %rdi
	subq	%rbx, %rsi
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L48:
	.cfi_restore_state
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE9400:
	.size	_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev, .-_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev
	.weak	_ZNSt6vectorIS_ImSaImEESaIS1_EED1Ev
	.set	_ZNSt6vectorIS_ImSaImEESaIS1_EED1Ev,_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev
	.section	.rodata._ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_.str1.1,"aMS",@progbits,1
.LC1:
	.string	"vector::_M_realloc_insert"
	.section	.rodata._ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_.str1.8,"aMS",@progbits,1
	.align 8
.LC2:
	.string	"cannot create std::vector larger than max_size()"
	.section	.text._ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"axG",@progbits,_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.type	_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, @function
_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_:
.LFB9563:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA9563
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	movabsq	$-6148914691236517205, %rcx
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	8(%rdi), %rbp
	movq	(%rdi), %r12
	movq	%rbp, %rax
	subq	%r12, %rax
	sarq	$3, %rax
	imulq	%rcx, %rax
	movabsq	$384307168202282325, %rcx
	cmpq	%rcx, %rax
	je	.L101
	movq	%rbx, %r14
	movq	%rdi, %r13
	subq	%r12, %r14
	cmpq	%rbp, %r12
	je	.L102
	leaq	(%rax,%rax), %rdi
	movq	%rdi, 8(%rsp)
	cmpq	%rax, %rdi
	jb	.L80
	testq	%rdi, %rdi
	jne	.L103
	xorl	%r15d, %r15d
.L64:
	movq	(%rsi), %rax
	movl	(%rdx), %esi
	addq	%r15, %r14
	movl	%esi, 16(%rsp)
	movq	%rax, %rsi
	shrq	$60, %rsi
	jne	.L104
	pxor	%xmm0, %xmm0
	movq	$0, 16(%r14)
	movups	%xmm0, (%r14)
	testq	%rax, %rax
	je	.L66
	salq	$3, %rax
	movq	%rax, %rdi
	movq	%rax, 24(%rsp)
.LEHB0:
	call	_Znwm@PLT
.LEHE0:
	movq	24(%rsp), %rdx
	movslq	16(%rsp), %rcx
	movq	%rax, (%r14)
	addq	%rax, %rdx
	movq	%rdx, %rsi
	movq	%rdx, 16(%r14)
	subq	%rax, %rsi
	andl	$8, %esi
	je	.L67
	movq	%rcx, (%rax)
	addq	$8, %rax
	cmpq	%rdx, %rax
	je	.L68
	.p2align 4,,10
	.p2align 3
.L67:
	movq	%rcx, (%rax)
	addq	$16, %rax
	movq	%rcx, -8(%rax)
	cmpq	%rdx, %rax
	jne	.L67
.L68:
	movq	%rdx, 8(%r14)
	cmpq	%r12, %rbx
	je	.L82
	movq	%r12, %rax
	movq	%r15, %rdx
	.p2align 4,,10
	.p2align 3
.L70:
	movdqu	(%rax), %xmm1
	movq	16(%rax), %rcx
	addq	$24, %rax
	addq	$24, %rdx
	movups	%xmm1, -24(%rdx)
	movq	%rcx, -8(%rdx)
	cmpq	%rax, %rbx
	jne	.L70
	leaq	-24(%rbx), %rax
	subq	%r12, %rax
	shrq	$3, %rax
	leaq	24(%r15,%rax,8), %r14
.L69:
	addq	$24, %r14
	cmpq	%rbp, %rbx
	je	.L71
	movq	%rbx, %rax
	movq	%r14, %rdx
	.p2align 4,,10
	.p2align 3
.L72:
	movdqu	(%rax), %xmm2
	movq	16(%rax), %rcx
	addq	$24, %rax
	addq	$24, %rdx
	movups	%xmm2, -24(%rdx)
	movq	%rcx, -8(%rdx)
	cmpq	%rax, %rbp
	jne	.L72
	subq	%rbx, %rbp
	leaq	-24(%rbp), %rax
	shrq	$3, %rax
	leaq	24(%r14,%rax,8), %r14
.L71:
	testq	%r12, %r12
	je	.L73
	movq	16(%r13), %rsi
	movq	%r12, %rdi
	subq	%r12, %rsi
	call	_ZdlPvm@PLT
.L73:
	movq	8(%rsp), %rax
	movq	%r15, 0(%r13)
	movq	%r14, 8(%r13)
	leaq	(%rax,%rax,2), %rax
	leaq	(%r15,%rax,8), %rax
	movq	%rax, 16(%r13)
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L80:
	.cfi_restore_state
	movabsq	$9223372036854775800, %rdi
	movq	%rcx, 8(%rsp)
.L63:
	movq	%rdx, 24(%rsp)
	movq	%rsi, 16(%rsp)
.LEHB1:
	call	_Znwm@PLT
.LEHE1:
	movq	16(%rsp), %rsi
	movq	24(%rsp), %rdx
	movq	%rax, %r15
	jmp	.L64
	.p2align 4,,10
	.p2align 3
.L66:
	movq	$0, (%r14)
	xorl	%edx, %edx
	movq	$0, 16(%r14)
	jmp	.L68
	.p2align 4,,10
	.p2align 3
.L102:
	addq	$1, %rax
	jc	.L80
	movabsq	$384307168202282325, %rcx
	cmpq	%rcx, %rax
	cmovbe	%rax, %rcx
	leaq	(%rcx,%rcx,2), %rdi
	movq	%rcx, 8(%rsp)
	salq	$3, %rdi
	jmp	.L63
	.p2align 4,,10
	.p2align 3
.L82:
	movq	%r15, %r14
	jmp	.L69
.L103:
	movabsq	$384307168202282325, %rax
	cmpq	%rax, %rdi
	cmovbe	%rdi, %rax
	leaq	(%rax,%rax,2), %rdi
	movq	%rax, 8(%rsp)
	salq	$3, %rdi
	jmp	.L63
.L104:
	leaq	.LC2(%rip), %rdi
.LEHB2:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE2:
.L101:
	leaq	.LC1(%rip), %rdi
.LEHB3:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE3:
.L83:
	endbr64
	movq	%rax, %rdi
.L74:
	call	__cxa_begin_catch@PLT
	testq	%r15, %r15
	je	.L105
	imulq	$24, 8(%rsp), %rsi
	movq	%r15, %rdi
	call	_ZdlPvm@PLT
.L78:
.LEHB4:
	call	__cxa_rethrow@PLT
.LEHE4:
.L105:
	movq	(%r14), %rdi
	movq	16(%r14), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L78
	call	_ZdlPvm@PLT
	jmp	.L78
.L84:
	endbr64
	movq	%rax, %rbx
.L77:
	call	__cxa_end_catch@PLT
	movq	%rbx, %rdi
.LEHB5:
	call	_Unwind_Resume@PLT
.LEHE5:
	.cfi_endproc
.LFE9563:
	.globl	__gxx_personality_v0
	.section	.gcc_except_table._ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"aG",@progbits,_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.align 4
.LLSDA9563:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATT9563-.LLSDATTD9563
.LLSDATTD9563:
	.byte	0x1
	.uleb128 .LLSDACSE9563-.LLSDACSB9563
.LLSDACSB9563:
	.uleb128 .LEHB0-.LFB9563
	.uleb128 .LEHE0-.LEHB0
	.uleb128 .L83-.LFB9563
	.uleb128 0x1
	.uleb128 .LEHB1-.LFB9563
	.uleb128 .LEHE1-.LEHB1
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB2-.LFB9563
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L83-.LFB9563
	.uleb128 0x1
	.uleb128 .LEHB3-.LFB9563
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB4-.LFB9563
	.uleb128 .LEHE4-.LEHB4
	.uleb128 .L84-.LFB9563
	.uleb128 0
	.uleb128 .LEHB5-.LFB9563
	.uleb128 .LEHE5-.LEHB5
	.uleb128 0
	.uleb128 0
.LLSDACSE9563:
	.byte	0x1
	.byte	0
	.align 4
	.long	0

.LLSDATT9563:
	.section	.text._ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"axG",@progbits,_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.size	_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, .-_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.globl	__popcountdi2
	.section	.text._ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,"axG",@progbits,_ZN9blueberry7FastSetC5ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,comdat
	.align 2
	.p2align 4
	.weak	_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.type	_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE, @function
_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE:
.LFB9064:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA9064
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pxor	%xmm0, %xmm0
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	movq	8(%rsi), %rbp
	movq	%rsi, 24(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	leaq	8(%rdi), %rax
	movl	$0, 4(%rdi)
	movq	%rax, 8(%rsp)
	movq	$0, 24(%rdi)
	movl	%ebp, (%rdi)
	movslq	%ebp, %rbp
	movups	%xmm0, 8(%rdi)
.L107:
	testq	%rbp, %rbp
	je	.L110
	movq	16(%r12), %rbx
.L111:
	addq	$63, %rbp
	movl	$0, 44(%rsp)
	movq	%rbx, %r14
	shrq	$6, %rbp
	movq	%rbp, 48(%rsp)
	cmpq	24(%r12), %rbx
	je	.L108
	pxor	%xmm2, %xmm2
	movq	$0, 16(%rbx)
	movups	%xmm2, (%rbx)
	testq	%rbp, %rbp
	je	.L109
	leaq	0(,%rbp,8), %r13
	movq	%r13, %rdi
.LEHB6:
	call	_Znwm@PLT
	leaq	(%rax,%r13), %r15
	movq	%rax, (%rbx)
	movq	%rax, %rdi
	movq	%r13, %rdx
	movq	%r15, 16(%rbx)
	xorl	%esi, %esi
	call	memset@PLT
	movq	16(%r12), %rbx
	movq	%r15, 8(%r14)
	addq	$24, %rbx
	movq	%rbx, 16(%r12)
	cmpq	$1, %rbp
	jne	.L111
.L110:
	movl	(%r12), %ebx
	cmpl	$63, %ebx
	jg	.L112
	.p2align 4,,10
	.p2align 3
.L148:
	movq	8(%r12), %r14
	xorl	%r15d, %r15d
.L117:
	cmpl	%r15d, %ebx
	jle	.L125
	movq	24(%rsp), %rax
	movslq	%r15d, %rdx
	movl	$1, %r8d
	movq	(%rax), %rsi
	.p2align 4,,10
	.p2align 3
.L124:
	cmpb	$49, (%rsi,%rdx)
	jne	.L123
	testl	%edx, %edx
	leal	63(%rdx), %eax
	movq	(%r14), %rdi
	movl	%edx, %ecx
	cmovns	%edx, %eax
	movq	%r8, %r11
	addl	$1, 4(%r12)
	salq	%cl, %r11
	sarl	$6, %eax
	cltq
	orq	%r11, (%rdi,%rax,8)
.L123:
	addq	$1, %rdx
	cmpl	%edx, %ebx
	jg	.L124
.L125:
	movabsq	$-6148914691236517205, %rdx
	movq	16(%r12), %rax
	subq	%r14, %rax
	movq	%rax, %r11
	sarq	$3, %r11
	imulq	%rdx, %r11
	cmpq	$24, %rax
	jbe	.L106
	movl	$1, %r10d
	movl	$1, %r9d
	.p2align 4,,10
	.p2align 3
.L122:
	movq	8(%r14), %rdx
	movq	(%r14), %rdi
	xorl	%eax, %eax
	movq	%rdx, %r8
	subq	%rdi, %r8
	sarq	$3, %r8
	cmpq	%rdx, %rdi
	je	.L128
	.p2align 4,,10
	.p2align 3
.L127:
	cmpq	$0, (%rdi,%rax,8)
	je	.L126
	movq	24(%r14), %rdx
	movq	%rax, %rsi
	movl	%eax, %ecx
	movq	%r9, %rbx
	shrq	$6, %rsi
	salq	%cl, %rbx
	orq	%rbx, (%rdx,%rsi,8)
.L126:
	addq	$1, %rax
	cmpq	%r8, %rax
	jb	.L127
.L128:
	addq	$1, %r10
	addq	$24, %r14
	cmpq	%r11, %r10
	jb	.L122
.L134:
.L106:
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L147
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L109:
	.cfi_restore_state
	movq	$0, (%rbx)
	addq	$24, %rbx
	movq	$0, -8(%rbx)
	movq	$0, -16(%rbx)
	movq	%rbx, 16(%r12)
	movl	(%r12), %ebx
	cmpl	$63, %ebx
	jg	.L112
	jmp	.L148
	.p2align 4,,10
	.p2align 3
.L108:
	movq	8(%rsp), %rdi
	leaq	44(%rsp), %rcx
	leaq	48(%rsp), %rdx
	movq	%rbx, %rsi
	call	_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
.LEHE6:
	cmpq	$1, %rbp
	jne	.L107
	jmp	.L110
	.p2align 4,,10
	.p2align 3
.L112:
	movq	24(%rsp), %rax
	leal	-63(%rbx), %edx
	xorl	%r15d, %r15d
	movl	%edx, 20(%rsp)
	movq	(%rax), %rax
	movq	%rax, 8(%rsp)
	movq	__cpu_model@GOTPCREL(%rip), %rax
	movl	12(%rax), %eax
	notl	%eax
	testl	$1028, %eax
	je	.L149
.L116:
	movq	8(%r12), %r13
	movdqa	.LC3(%rip), %xmm1
	movslq	%r15d, %rbp
	.p2align 4,,10
	.p2align 3
.L118:
	movq	8(%rsp), %rax
	xorl	%ecx, %ecx
	xorl	%r9d, %r9d
	leaq	(%rax,%rbp), %rdi
.L119:
	movdqu	(%rdi), %xmm0
	addq	$16, %rdi
	pcmpeqb	%xmm1, %xmm0
	pmovmskb	%xmm0, %eax
	salq	%cl, %rax
	addl	$16, %ecx
	orq	%rax, %r9
	cmpl	$64, %ecx
	jne	.L119
	movl	%r15d, %eax
	movq	0(%r13), %rcx
	movq	%r9, %rdi
	addl	$64, %r15d
	sarl	$6, %eax
	addq	$64, %rbp
	movq	%r13, %r14
	cltq
	movq	%r9, (%rcx,%rax,8)
	call	__popcountdi2@PLT
	addl	%eax, 4(%r12)
	cmpl	%r15d, 20(%rsp)
	movdqa	.LC3(%rip), %xmm1
	jg	.L118
	jmp	.L117
.L149:
	movq	8(%r12), %r14
	movl	%ebx, %r15d
	movq	8(%rsp), %rdi
	sarl	$6, %r15d
	movq	(%r14), %rsi
	movl	%r15d, %edx
	sall	$6, %r15d
	call	_ZN9blueberry7FastSet9load_avx2EPKcPmi
	movl	%eax, 4(%r12)
	leal	-63(%rbx), %eax
	cmpl	%eax, %r15d
	jl	.L116
	jmp	.L117
.L114:
	movq	8(%rsp), %rdi
	call	_ZNSt6vectorIS_ImSaImEESaIS1_EED1Ev
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	je	.L115
.L147:
	call	__stack_chk_fail@PLT
.L135:
	endbr64
	movq	%rax, %rbx
	jmp	.L114
.L115:
	movq	%rbx, %rdi
.LEHB7:
	call	_Unwind_Resume@PLT
.LEHE7:
	.cfi_endproc
.LFE9064:
	.section	.gcc_except_table._ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,"aG",@progbits,_ZN9blueberry7FastSetC5ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,comdat
.LLSDA9064:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE9064-.LLSDACSB9064
.LLSDACSB9064:
	.uleb128 .LEHB6-.LFB9064
	.uleb128 .LEHE6-.LEHB6
	.uleb128 .L135-.LFB9064
	.uleb128 0
	.uleb128 .LEHB7-.LFB9064
	.uleb128 .LEHE7-.LEHB7
	.uleb128 0
	.uleb128 0
.LLSDACSE9064:
	.section	.text._ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,"axG",@progbits,_ZN9blueberry7FastSetC5ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,comdat
	.size	_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE, .-_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.weak	_ZN9blueberry7FastSetC1ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.set	_ZN9blueberry7FastSetC1ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.section	.text.unlikely,"ax",@progbits
.LCOLDB5:
	.text
.LHOTB5:
	.p2align 4
	.globl	build_set
	.type	build_set, @function
build_set:
.LFB9096:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA9096
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rdi, %rbp
	movl	$32, %edi
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
.LEHB8:
	call	_Znwm@PLT
.LEHE8:
	movq	%rbp, %rsi
	movq	%rax, %rdi
	movq	%rax, %rbx
.LEHB9:
	call	_ZN9blueberry7FastSetC1ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
.LEHE9:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L152:
	.cfi_restore_state
	endbr64
	movq	%rax, %rbp
	jmp	.L151
	.section	.gcc_except_table,"a",@progbits
.LLSDA9096:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE9096-.LLSDACSB9096
.LLSDACSB9096:
	.uleb128 .LEHB8-.LFB9096
	.uleb128 .LEHE8-.LEHB8
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB9-.LFB9096
	.uleb128 .LEHE9-.LEHB9
	.uleb128 .L152-.LFB9096
	.uleb128 0
.LLSDACSE9096:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC9096
	.type	build_set.cold, @function
build_set.cold:
.LFSB9096:
.L151:
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -24
	.cfi_offset 6, -16
	movq	%rbx, %rdi
	movl	$32, %esi
	call	_ZdlPvm@PLT
	movq	%rbp, %rdi
.LEHB10:
	call	_Unwind_Resume@PLT
.LEHE10:
	.cfi_endproc
.LFE9096:
	.section	.gcc_except_table
.LLSDAC9096:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC9096-.LLSDACSBC9096
.LLSDACSBC9096:
	.uleb128 .LEHB10-.LCOLDB5
	.uleb128 .LEHE10-.LEHB10
	.uleb128 0
	.uleb128 0
.LLSDACSEC9096:
	.section	.text.unlikely
	.text
	.size	build_set, .-build_set
	.section	.text.unlikely
	.size	build_set.cold, .-build_set.cold
.LCOLDE5:
	.text
.LHOTE5:
	.section	.rodata.cst16,"aM",@progbits,16
	.align 16
.LC3:
	.byte	49
	.byte	49
	.byte	49
	.byte	49
	.byte	49
	.byte	49
	.byte	49
	.byte	49
	.byte	49
	.byte	49
	.byte	49
	.byte	49
	.byte	49
	.byte	49
	.byte	49
	.byte	49
	.hidden	DW.ref.__gxx_personality_v0
	.weak	DW.ref.__gxx_personality_v0
	.section	.data.rel.local.DW.ref.__gxx_personality_v0,"awG",@progbits,DW.ref.__gxx_personality_v0,comdat
	.align 8
	.type	DW.ref.__gxx_personality_v0, @object
	.size	DW.ref.__gxx_personality_v0, 8
DW.ref.__gxx_personality_v0:
	.quad	__gxx_personality_v0
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
