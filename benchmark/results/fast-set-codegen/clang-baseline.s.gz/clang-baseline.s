	.text
	.file	"fast-set-assembly-codegen.cpp"
	.globl	build_set                       # -- Begin function build_set
	.p2align	4, 0x90
	.type	build_set,@function
build_set:                              # @build_set
.Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, DW.ref.__gxx_personality_v0
	.cfi_lsda 27, .Lexception0
# %bb.0:
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rdi, %r14
	movl	$32, %edi
	callq	_Znwm@PLT
	movq	%rax, %rbx
.Ltmp0:
	movq	%rax, %rdi
	movq	%r14, %rsi
	callq	_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
.Ltmp1:
# %bb.1:
	movq	%rbx, %rax
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB0_2:
	.cfi_def_cfa_offset 32
.Ltmp2:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	_ZdlPv@PLT
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end0:
	.size	build_set, .Lfunc_end0-build_set
	.cfi_endproc
	.section	.gcc_except_table,"a",@progbits
	.p2align	2, 0x0
GCC_except_table0:
.Lexception0:
	.byte	255                             # @LPStart Encoding = omit
	.byte	255                             # @TType Encoding = omit
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end0-.Lcst_begin0
.Lcst_begin0:
	.uleb128 .Lfunc_begin0-.Lfunc_begin0    # >> Call Site 1 <<
	.uleb128 .Ltmp0-.Lfunc_begin0           #   Call between .Lfunc_begin0 and .Ltmp0
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp0-.Lfunc_begin0           # >> Call Site 2 <<
	.uleb128 .Ltmp1-.Ltmp0                  #   Call between .Ltmp0 and .Ltmp1
	.uleb128 .Ltmp2-.Lfunc_begin0           #     jumps to .Ltmp2
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp1-.Lfunc_begin0           # >> Call Site 3 <<
	.uleb128 .Lfunc_end0-.Ltmp1             #   Call between .Ltmp1 and .Lfunc_end0
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
.Lcst_end0:
	.p2align	2, 0x0
                                        # -- End function
	.section	.text._ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,"axG",@progbits,_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,comdat
	.weak	_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE # -- Begin function _ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.p2align	4, 0x90
	.type	_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,@function
_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE: # @_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.cfi_startproc
# %bb.0:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rsi, %r14
	movq	%rdi, %rbx
	movl	8(%rsi), %esi
	callq	_ZN9blueberry7FastSetC2Ei
	movl	(%rbx), %eax
	testl	%eax, %eax
	jle	.LBB1_1
# %bb.12:
	movq	(%r14), %rsi
	movq	8(%rbx), %rdx
	movl	4(%rbx), %edi
	xorl	%ecx, %ecx
	jmp	.LBB1_13
	.p2align	4, 0x90
.LBB1_15:                               #   in Loop: Header=BB1_13 Depth=1
	incq	%rcx
	cmpq	%rcx, %rax
	je	.LBB1_2
.LBB1_13:                               # =>This Inner Loop Header: Depth=1
	cmpb	$49, (%rsi,%rcx)
	jne	.LBB1_15
# %bb.14:                               #   in Loop: Header=BB1_13 Depth=1
	movl	$1, %r8d
	shlq	%cl, %r8
	movq	(%rdx), %r9
	movl	%ecx, %r10d
	shrl	$6, %r10d
	orq	%r8, (%r9,%r10,8)
	incl	%edi
	movl	%edi, 4(%rbx)
	jmp	.LBB1_15
.LBB1_1:
	movq	8(%rbx), %rdx
.LBB1_2:
	movq	16(%rbx), %rax
	subq	%rdx, %rax
	sarq	$3, %rax
	movabsq	$-6148914691236517205, %rsi     # imm = 0xAAAAAAAAAAAAAAAB
	imulq	%rax, %rsi
	cmpq	$2, %rsi
	jb	.LBB1_11
# %bb.3:
	movl	$1, %edi
	movl	$1, %r8d
	jmp	.LBB1_4
	.p2align	4, 0x90
.LBB1_10:                               #   in Loop: Header=BB1_4 Depth=1
	incq	%r8
	cmpq	%rsi, %r8
	je	.LBB1_11
.LBB1_4:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB1_17 Depth 2
	leaq	(%r8,%r8,2), %rax
	movq	-24(%rdx,%rax,8), %r10
	movq	-16(%rdx,%rax,8), %r11
	subq	%r10, %r11
	je	.LBB1_10
# %bb.5:                                #   in Loop: Header=BB1_4 Depth=1
	leaq	(%rdx,%rax,8), %r9
	sarq	$3, %r11
	cmpq	$2, %r11
	cmovbq	%rdi, %r11
	jae	.LBB1_16
# %bb.6:                                #   in Loop: Header=BB1_4 Depth=1
	xorl	%eax, %eax
.LBB1_7:                                #   in Loop: Header=BB1_4 Depth=1
	testb	$1, %r11b
	je	.LBB1_10
# %bb.8:                                #   in Loop: Header=BB1_4 Depth=1
	cmpq	$0, (%r10,%rax,8)
	je	.LBB1_10
# %bb.9:                                #   in Loop: Header=BB1_4 Depth=1
	movl	$1, %r10d
	movl	%eax, %ecx
	shlq	%cl, %r10
	movq	(%r9), %rcx
	shrq	$6, %rax
	orq	%r10, (%rcx,%rax,8)
	jmp	.LBB1_10
	.p2align	4, 0x90
.LBB1_16:                               #   in Loop: Header=BB1_4 Depth=1
	movq	%r11, %rbx
	andq	$-2, %rbx
	xorl	%eax, %eax
	jmp	.LBB1_17
	.p2align	4, 0x90
.LBB1_21:                               #   in Loop: Header=BB1_17 Depth=2
	addq	$2, %rax
	cmpq	%rax, %rbx
	je	.LBB1_7
.LBB1_17:                               #   Parent Loop BB1_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	cmpq	$0, (%r10,%rax,8)
	je	.LBB1_19
# %bb.18:                               #   in Loop: Header=BB1_17 Depth=2
	movl	%eax, %ecx
	andb	$62, %cl
	movl	$1, %r14d
	shlq	%cl, %r14
	movq	(%r9), %rcx
	movq	%rax, %r15
	shrq	$6, %r15
	orq	%r14, (%rcx,%r15,8)
.LBB1_19:                               #   in Loop: Header=BB1_17 Depth=2
	cmpq	$0, 8(%r10,%rax,8)
	je	.LBB1_21
# %bb.20:                               #   in Loop: Header=BB1_17 Depth=2
	leaq	1(%rax), %rcx
	movl	$1, %r14d
                                        # kill: def $cl killed $cl killed $rcx
	shlq	%cl, %r14
	movq	(%r9), %rcx
	movq	%rax, %r15
	shrq	$6, %r15
	orq	%r14, (%rcx,%r15,8)
	jmp	.LBB1_21
.LBB1_11:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE, .Lfunc_end1-_ZN9blueberry7FastSetC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.cfi_endproc
                                        # -- End function
	.text
	.globl	next_set                        # -- Begin function next_set
	.p2align	4, 0x90
	.type	next_set,@function
next_set:                               # @next_set
	.cfi_startproc
# %bb.0:
	movl	(%rdi), %eax
	cmpl	%esi, %eax
	jle	.LBB2_22
# %bb.1:
	cmpl	$0, 4(%rdi)
	je	.LBB2_22
# %bb.2:
	movl	%esi, %ecx
	movq	8(%rdi), %rdx
	movq	16(%rdi), %rsi
	subq	%rdx, %rsi
	je	.LBB2_22
# %bb.3:
	sarq	$3, %rsi
	movabsq	$-6148914691236517205, %r8      # imm = 0xAAAAAAAAAAAAAAAB
	imulq	%rsi, %r8
	xorl	%esi, %esi
	testl	%ecx, %ecx
	cmovlel	%esi, %ecx
	cmpq	$1, %r8
	adcq	$0, %r8
	leaq	8(%rdx), %rdi
	movq	%rcx, %r9
	.p2align	4, 0x90
.LBB2_4:                                # =>This Inner Loop Header: Depth=1
	shrq	$6, %r9
	movq	-8(%rdi), %r10
	movq	(%rdi), %r11
	subq	%r10, %r11
	sarq	$3, %r11
	cmpq	%r11, %r9
	jae	.LBB2_22
# %bb.5:                                #   in Loop: Header=BB2_4 Depth=1
	movq	(%r10,%r9,8), %r10
	shrq	%cl, %r10
	shlq	%cl, %r10
	testq	%r10, %r10
	jne	.LBB2_7
# %bb.6:                                #   in Loop: Header=BB2_4 Depth=1
	incq	%r9
	incq	%rsi
	addq	$24, %rdi
	movq	%r9, %rcx
	cmpq	%rsi, %r8
	jne	.LBB2_4
	jmp	.LBB2_22
.LBB2_7:
	andq	$-64, %rcx
	rep		bsfq	%r10, %r8
	orq	%rcx, %r8
	testq	%rsi, %rsi
	je	.LBB2_8
# %bb.9:
	testb	$1, %sil
	jne	.LBB2_11
# %bb.10:
                                        # implicit-def: $rax
	movq	%rsi, %rcx
	jmp	.LBB2_15
.LBB2_8:
	movq	%r8, %rax
                                        # kill: def $eax killed $eax killed $rax
	retq
.LBB2_11:
	movq	-32(%rdi), %rax
	movq	(%rax,%r8,8), %rax
	shlq	$6, %r8
	testq	%rax, %rax
	je	.LBB2_12
# %bb.13:
	rep		bsfq	%rax, %rax
	jmp	.LBB2_14
.LBB2_12:
	movl	$64, %eax
.LBB2_14:
	addq	%r8, %rax
	leaq	-1(%rsi), %rcx
	movq	%rax, %r8
.LBB2_15:
	cmpq	$1, %rsi
	jne	.LBB2_16
.LBB2_22:
                                        # kill: def $eax killed $eax killed $rax
	retq
.LBB2_16:
	leaq	(%rcx,%rcx,2), %rax
	leaq	(%rdx,%rax,8), %rdx
	addq	$-24, %rdx
	movq	%r8, %rax
	jmp	.LBB2_17
	.p2align	4, 0x90
.LBB2_21:                               #   in Loop: Header=BB2_17 Depth=1
	shlq	$6, %rax
	addq	%rsi, %rax
	addq	$-2, %rcx
	addq	$-48, %rdx
	testq	%rcx, %rcx
	je	.LBB2_22
.LBB2_17:                               # =>This Inner Loop Header: Depth=1
	movq	(%rdx), %rsi
	movq	(%rsi,%rax,8), %r8
	movl	$64, %esi
	movl	$64, %edi
	testq	%r8, %r8
	je	.LBB2_19
# %bb.18:                               #   in Loop: Header=BB2_17 Depth=1
	rep		bsfq	%r8, %rdi
.LBB2_19:                               #   in Loop: Header=BB2_17 Depth=1
	shlq	$6, %rax
	addq	%rdi, %rax
	movq	-24(%rdx), %rdi
	movq	(%rdi,%rax,8), %rdi
	testq	%rdi, %rdi
	je	.LBB2_21
# %bb.20:                               #   in Loop: Header=BB2_17 Depth=1
	rep		bsfq	%rdi, %rsi
	jmp	.LBB2_21
.Lfunc_end2:
	.size	next_set, .Lfunc_end2-next_set
	.cfi_endproc
                                        # -- End function
	.globl	prev_set                        # -- Begin function prev_set
	.p2align	4, 0x90
	.type	prev_set,@function
prev_set:                               # @prev_set
	.cfi_startproc
# %bb.0:
	movl	$-1, %eax
	testl	%esi, %esi
	js	.LBB3_22
# %bb.1:
	cmpl	$0, 4(%rdi)
	je	.LBB3_22
# %bb.2:
	movq	8(%rdi), %rdx
	movq	16(%rdi), %rcx
	subq	%rdx, %rcx
	je	.LBB3_22
# %bb.3:
	sarq	$3, %rcx
	movabsq	$-6148914691236517205, %r9      # imm = 0xAAAAAAAAAAAAAAAB
	imulq	%rcx, %r9
	movl	(%rdi), %ecx
	decl	%ecx
	cmpl	%esi, %ecx
	cmovgel	%esi, %ecx
	cmpq	$1, %r9
	adcq	$0, %r9
	movslq	%ecx, %rdi
	xorl	%esi, %esi
	movq	%rdx, %r8
	movq	%rdi, %r10
	.p2align	4, 0x90
.LBB3_4:                                # =>This Inner Loop Header: Depth=1
	shrq	$6, %r10
	movq	(%r8), %rcx
	movq	(%rcx,%r10,8), %r11
	movl	%edi, %ecx
	notb	%cl
	shlq	%cl, %r11
	shrq	%cl, %r11
	testq	%r11, %r11
	jne	.LBB3_7
# %bb.5:                                #   in Loop: Header=BB3_4 Depth=1
	cmpq	$64, %rdi
	jb	.LBB3_22
# %bb.6:                                #   in Loop: Header=BB3_4 Depth=1
	decq	%r10
	incq	%rsi
	addq	$24, %r8
	movq	%r10, %rdi
	cmpq	%rsi, %r9
	jne	.LBB3_4
	jmp	.LBB3_22
.LBB3_7:
	orq	$63, %rdi
	bsrq	%r11, %rax
	xorq	$63, %rax
	subq	%rax, %rdi
	testq	%rsi, %rsi
	je	.LBB3_8
# %bb.9:
	testb	$1, %sil
	jne	.LBB3_11
# %bb.10:
                                        # implicit-def: $rax
	movq	%rsi, %rcx
	jmp	.LBB3_15
.LBB3_8:
	movq	%rdi, %rax
                                        # kill: def $eax killed $eax killed $rax
	retq
.LBB3_11:
	movq	%rdi, %rax
	shlq	$6, %rax
	orq	$63, %rax
	movq	-24(%r8), %rcx
	movq	(%rcx,%rdi,8), %rcx
	testq	%rcx, %rcx
	je	.LBB3_12
# %bb.13:
	bsrq	%rcx, %rcx
	xorq	$63, %rcx
	jmp	.LBB3_14
.LBB3_12:
	movl	$64, %ecx
.LBB3_14:
	subq	%rcx, %rax
	leaq	-1(%rsi), %rcx
	movq	%rax, %rdi
.LBB3_15:
	cmpq	$1, %rsi
	jne	.LBB3_16
.LBB3_22:
                                        # kill: def $eax killed $eax killed $rax
	retq
.LBB3_16:
	leaq	(%rcx,%rcx,2), %rax
	leaq	(%rdx,%rax,8), %rdx
	addq	$-24, %rdx
	movq	%rdi, %rax
	jmp	.LBB3_17
	.p2align	4, 0x90
.LBB3_21:                               #   in Loop: Header=BB3_17 Depth=1
	shlq	$6, %rax
	orq	$63, %rax
	subq	%rsi, %rax
	addq	$-2, %rcx
	addq	$-48, %rdx
	testq	%rcx, %rcx
	je	.LBB3_22
.LBB3_17:                               # =>This Inner Loop Header: Depth=1
	movq	(%rdx), %rsi
	movq	(%rsi,%rax,8), %r8
	movl	$64, %esi
	movl	$64, %edi
	testq	%r8, %r8
	je	.LBB3_19
# %bb.18:                               #   in Loop: Header=BB3_17 Depth=1
	bsrq	%r8, %rdi
	xorq	$63, %rdi
.LBB3_19:                               #   in Loop: Header=BB3_17 Depth=1
	shlq	$6, %rax
	orq	$63, %rax
	subq	%rdi, %rax
	movq	-24(%rdx), %rdi
	movq	(%rdi,%rax,8), %rdi
	testq	%rdi, %rdi
	je	.LBB3_21
# %bb.20:                               #   in Loop: Header=BB3_17 Depth=1
	bsrq	%rdi, %rsi
	xorq	$63, %rsi
	jmp	.LBB3_21
.Lfunc_end3:
	.size	prev_set, .Lfunc_end3-prev_set
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          # -- Begin function _ZN9blueberry7FastSetC2Ei
.LCPI4_0:
	.zero	16
	.section	.text._ZN9blueberry7FastSetC2Ei,"axG",@progbits,_ZN9blueberry7FastSetC2Ei,comdat
	.weak	_ZN9blueberry7FastSetC2Ei
	.p2align	4, 0x90
	.type	_ZN9blueberry7FastSetC2Ei,@function
_ZN9blueberry7FastSetC2Ei:              # @_ZN9blueberry7FastSetC2Ei
.Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, DW.ref.__gxx_personality_v0
	.cfi_lsda 27, .Lexception1
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	%esi, (%rdi)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 4(%rdi)
	movups	%xmm0, 16(%rdi)
	testl	%esi, %esi
	je	.LBB4_10
# %bb.1:
	movq	%rdi, %rbx
	leaq	8(%rdi), %r14
	movslq	%esi, %rax
	leaq	12(%rsp), %r12
	jmp	.LBB4_2
	.p2align	4, 0x90
.LBB4_8:                                #   in Loop: Header=BB4_2 Depth=1
.Ltmp5:
	movq	%r14, %rdi
	movq	%r13, %rsi
	leaq	16(%rsp), %rdx
	movq	%r12, %rcx
	callq	_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
.Ltmp6:
.LBB4_9:                                #   in Loop: Header=BB4_2 Depth=1
	movq	16(%rsp), %rax
	cmpq	$1, %rax
	jbe	.LBB4_10
.LBB4_2:                                # =>This Inner Loop Header: Depth=1
	addq	$63, %rax
	movq	%rax, %r15
	shrq	$6, %r15
	movq	%r15, 16(%rsp)
	movl	$0, 12(%rsp)
	movq	16(%rbx), %r13
	cmpq	24(%rbx), %r13
	je	.LBB4_8
# %bb.3:                                #   in Loop: Header=BB4_2 Depth=1
	xorps	%xmm0, %xmm0
	movups	%xmm0, (%r13)
	movq	$0, 16(%r13)
	cmpq	$64, %rax
	jae	.LBB4_5
# %bb.4:                                #   in Loop: Header=BB4_2 Depth=1
	xorl	%r15d, %r15d
	jmp	.LBB4_7
	.p2align	4, 0x90
.LBB4_5:                                #   in Loop: Header=BB4_2 Depth=1
	leaq	(,%r15,8), %rbp
.Ltmp3:
	movq	%rbp, %rdi
	callq	_Znwm@PLT
.Ltmp4:
# %bb.6:                                #   in Loop: Header=BB4_2 Depth=1
	movq	%rax, (%r13)
	leaq	(%rax,%r15,8), %r15
	movq	%r15, 16(%r13)
	movq	%rax, %rdi
	xorl	%esi, %esi
	movq	%rbp, %rdx
	callq	memset@PLT
.LBB4_7:                                #   in Loop: Header=BB4_2 Depth=1
	movq	%r15, 8(%r13)
	addq	$24, 16(%rbx)
	jmp	.LBB4_9
.LBB4_10:
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB4_11:
	.cfi_def_cfa_offset 80
.Ltmp7:
	movq	%rax, %rbx
	movq	%r14, %rdi
	callq	_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end4:
	.size	_ZN9blueberry7FastSetC2Ei, .Lfunc_end4-_ZN9blueberry7FastSetC2Ei
	.cfi_endproc
	.section	.gcc_except_table._ZN9blueberry7FastSetC2Ei,"aG",@progbits,_ZN9blueberry7FastSetC2Ei,comdat
	.p2align	2, 0x0
GCC_except_table4:
.Lexception1:
	.byte	255                             # @LPStart Encoding = omit
	.byte	255                             # @TType Encoding = omit
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end1-.Lcst_begin1
.Lcst_begin1:
	.uleb128 .Ltmp5-.Lfunc_begin1           # >> Call Site 1 <<
	.uleb128 .Ltmp4-.Ltmp5                  #   Call between .Ltmp5 and .Ltmp4
	.uleb128 .Ltmp7-.Lfunc_begin1           #     jumps to .Ltmp7
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp4-.Lfunc_begin1           # >> Call Site 2 <<
	.uleb128 .Lfunc_end4-.Ltmp4             #   Call between .Ltmp4 and .Lfunc_end4
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
.Lcst_end1:
	.p2align	2, 0x0
                                        # -- End function
	.section	.text._ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev,"axG",@progbits,_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev,comdat
	.weak	_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev # -- Begin function _ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev
	.p2align	4, 0x90
	.type	_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev,@function
_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev:    # @_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev
	.cfi_startproc
# %bb.0:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	(%rdi), %rbx
	movq	8(%rdi), %r15
	cmpq	%r15, %rbx
	je	.LBB5_6
# %bb.1:
	movq	%rdi, %r14
	jmp	.LBB5_2
	.p2align	4, 0x90
.LBB5_4:                                #   in Loop: Header=BB5_2 Depth=1
	addq	$24, %rbx
	cmpq	%r15, %rbx
	je	.LBB5_5
.LBB5_2:                                # =>This Inner Loop Header: Depth=1
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.LBB5_4
# %bb.3:                                #   in Loop: Header=BB5_2 Depth=1
	callq	_ZdlPv@PLT
	jmp	.LBB5_4
.LBB5_5:
	movq	(%r14), %rbx
.LBB5_6:
	testq	%rbx, %rbx
	je	.LBB5_7
# %bb.8:
	movq	%rbx, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	_ZdlPv@PLT                      # TAILCALL
.LBB5_7:
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end5:
	.size	_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev, .Lfunc_end5-_ZNSt6vectorIS_ImSaImEESaIS1_EED2Ev
	.cfi_endproc
                                        # -- End function
	.section	.text._ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"axG",@progbits,_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.weak	_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_ # -- Begin function _ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.p2align	4, 0x90
	.type	_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,@function
_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_: # @_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
.Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, DW.ref.__gxx_personality_v0
	.cfi_lsda 27, .Lexception2
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %r12
	movq	(%rdi), %r8
	movq	8(%rdi), %r14
	movq	%r14, %rax
	subq	%r8, %rax
	movabsq	$9223372036854775800, %rsi      # imm = 0x7FFFFFFFFFFFFFF8
	cmpq	%rsi, %rax
	je	.LBB6_34
# %bb.1:
	sarq	$3, %rax
	movabsq	$-6148914691236517205, %r9      # imm = 0xAAAAAAAAAAAAAAAB
	imulq	%r9, %rax
	cmpq	$1, %rax
	movq	%rax, %r10
	adcq	$0, %r10
	leaq	(%r10,%rax), %r13
	movabsq	$384307168202282325, %rsi       # imm = 0x555555555555555
	cmpq	%rsi, %r13
	cmovaeq	%rsi, %r13
	addq	%rax, %r10
	cmovbq	%rsi, %r13
	movq	%r12, %rbx
	movq	%r8, 8(%rsp)                    # 8-byte Spill
	subq	%r8, %rbx
	sarq	$3, %rbx
	imulq	%r9, %rbx
	testq	%r13, %r13
	movq	%rdi, 16(%rsp)                  # 8-byte Spill
	je	.LBB6_2
# %bb.3:
	leaq	(,%r13,8), %rax
	leaq	(%rax,%rax,2), %rdi
	movq	%rcx, %r15
	movq	%rdx, %rbp
	callq	_Znwm@PLT
	movq	%rbp, %rdx
	movq	%r15, %rcx
	jmp	.LBB6_4
.LBB6_2:
	xorl	%eax, %eax
.LBB6_4:
	leaq	(%rbx,%rbx,2), %rsi
	movq	%rax, (%rsp)                    # 8-byte Spill
	leaq	(%rax,%rsi,8), %rbp
	movq	(%rdx), %r15
	movq	%r15, %rax
	shrq	$60, %rax
	jne	.LBB6_5
# %bb.7:
	movslq	(%rcx), %rbx
	pxor	%xmm0, %xmm0
	movdqu	%xmm0, (%rbp)
	movq	$0, 16(%rbp)
	testq	%r15, %r15
	je	.LBB6_8
# %bb.9:
	leaq	(,%r15,8), %rdi
.Ltmp8:
	callq	_Znwm@PLT
.Ltmp9:
# %bb.10:
	movq	%rax, (%rbp)
	leaq	(%rax,%r15,8), %rcx
	movq	%rcx, 16(%rbp)
	decq	%r15
	movabsq	$2305843009213693951, %rsi      # imm = 0x1FFFFFFFFFFFFFFF
	andq	%r15, %rsi
	cmpq	$3, %rsi
	jae	.LBB6_12
# %bb.11:
	movq	%rax, %rdx
	movq	16(%rsp), %r15                  # 8-byte Reload
	movq	8(%rsp), %rdi                   # 8-byte Reload
	jmp	.LBB6_15
.LBB6_8:
	xorl	%ecx, %ecx
	movq	16(%rsp), %r15                  # 8-byte Reload
	movq	8(%rsp), %rdi                   # 8-byte Reload
	jmp	.LBB6_16
.LBB6_12:
	incq	%rsi
	movq	%rsi, %rdi
	andq	$-4, %rdi
	leaq	(%rax,%rdi,8), %rdx
	movq	%rbx, %xmm0
	pshufd	$68, %xmm0, %xmm0               # xmm0 = xmm0[0,1,0,1]
	xorl	%r8d, %r8d
	movq	16(%rsp), %r15                  # 8-byte Reload
	.p2align	4, 0x90
.LBB6_13:                               # =>This Inner Loop Header: Depth=1
	movdqu	%xmm0, (%rax,%r8,8)
	movdqu	%xmm0, 16(%rax,%r8,8)
	addq	$4, %r8
	cmpq	%r8, %rdi
	jne	.LBB6_13
# %bb.14:
	cmpq	%rdi, %rsi
	movq	8(%rsp), %rdi                   # 8-byte Reload
	je	.LBB6_16
	.p2align	4, 0x90
.LBB6_15:                               # =>This Inner Loop Header: Depth=1
	movq	%rbx, (%rdx)
	addq	$8, %rdx
	cmpq	%rcx, %rdx
	jne	.LBB6_15
.LBB6_16:
	movq	%rcx, 8(%rbp)
	movq	(%rsp), %rbx                    # 8-byte Reload
	movq	%rbx, %rbp
	cmpq	%r12, %rdi
	je	.LBB6_19
# %bb.17:
	pxor	%xmm0, %xmm0
	movq	%rbx, %rbp
	movq	%rdi, %rax
	.p2align	4, 0x90
.LBB6_18:                               # =>This Inner Loop Header: Depth=1
	movups	(%rax), %xmm1
	movups	%xmm1, (%rbp)
	movq	16(%rax), %rcx
	movq	%rcx, 16(%rbp)
	movdqu	%xmm0, (%rax)
	movq	$0, 16(%rax)
	addq	$24, %rbp
	addq	$24, %rax
	cmpq	%r12, %rax
	jne	.LBB6_18
.LBB6_19:
	addq	$24, %rbp
	cmpq	%r12, %r14
	je	.LBB6_22
# %bb.20:
	pxor	%xmm0, %xmm0
	.p2align	4, 0x90
.LBB6_21:                               # =>This Inner Loop Header: Depth=1
	movups	(%r12), %xmm1
	movups	%xmm1, (%rbp)
	movq	16(%r12), %rax
	movq	%rax, 16(%rbp)
	movdqu	%xmm0, (%r12)
	movq	$0, 16(%r12)
	addq	$24, %rbp
	addq	$24, %r12
	cmpq	%r14, %r12
	jne	.LBB6_21
.LBB6_22:
	testq	%rdi, %rdi
	je	.LBB6_24
# %bb.23:
	callq	_ZdlPv@PLT
.LBB6_24:
	movq	%rbx, (%r15)
	movq	%rbp, 8(%r15)
	leaq	(,%r13,2), %rax
	addq	%r13, %rax
	leaq	(%rbx,%rax,8), %rax
	movq	%rax, 16(%r15)
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB6_34:
	.cfi_def_cfa_offset 80
	leaq	.L.str.1(%rip), %rdi
	callq	_ZSt20__throw_length_errorPKc@PLT
.LBB6_5:
.Ltmp11:
	leaq	.L.str(%rip), %rdi
	callq	_ZSt20__throw_length_errorPKc@PLT
.Ltmp12:
# %bb.6:
.LBB6_27:
.Ltmp10:
	movq	%rax, %rdi
	callq	__cxa_begin_catch@PLT
	jmp	.LBB6_28
.LBB6_25:
.Ltmp13:
	movq	%rax, %rdi
	callq	__cxa_begin_catch@PLT
	cmpq	$0, (%rsp)                      # 8-byte Folded Reload
	jne	.LBB6_28
# %bb.26:
	movq	(%rbp), %rax
	movq	%rax, (%rsp)                    # 8-byte Spill
	testq	%rax, %rax
	je	.LBB6_29
.LBB6_28:
	movq	(%rsp), %rdi                    # 8-byte Reload
	callq	_ZdlPv@PLT
.LBB6_29:
.Ltmp14:
	callq	__cxa_rethrow@PLT
.Ltmp15:
# %bb.33:
.LBB6_30:
.Ltmp16:
	movq	%rax, %rbx
.Ltmp17:
	callq	__cxa_end_catch@PLT
.Ltmp18:
# %bb.31:
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB6_32:
.Ltmp19:
	movq	%rax, %rdi
	callq	__clang_call_terminate
.Lfunc_end6:
	.size	_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, .Lfunc_end6-_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.cfi_endproc
	.section	.gcc_except_table._ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"aG",@progbits,_ZNSt6vectorIS_ImSaImEESaIS1_EE17_M_realloc_insertIJRmiEEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.p2align	2, 0x0
GCC_except_table6:
.Lexception2:
	.byte	255                             # @LPStart Encoding = omit
	.byte	155                             # @TType Encoding = indirect pcrel sdata4
	.uleb128 .Lttbase0-.Lttbaseref0
.Lttbaseref0:
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end2-.Lcst_begin2
.Lcst_begin2:
	.uleb128 .Lfunc_begin2-.Lfunc_begin2    # >> Call Site 1 <<
	.uleb128 .Ltmp8-.Lfunc_begin2           #   Call between .Lfunc_begin2 and .Ltmp8
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp8-.Lfunc_begin2           # >> Call Site 2 <<
	.uleb128 .Ltmp9-.Ltmp8                  #   Call between .Ltmp8 and .Ltmp9
	.uleb128 .Ltmp10-.Lfunc_begin2          #     jumps to .Ltmp10
	.byte	1                               #   On action: 1
	.uleb128 .Ltmp9-.Lfunc_begin2           # >> Call Site 3 <<
	.uleb128 .Ltmp11-.Ltmp9                 #   Call between .Ltmp9 and .Ltmp11
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp11-.Lfunc_begin2          # >> Call Site 4 <<
	.uleb128 .Ltmp12-.Ltmp11                #   Call between .Ltmp11 and .Ltmp12
	.uleb128 .Ltmp13-.Lfunc_begin2          #     jumps to .Ltmp13
	.byte	1                               #   On action: 1
	.uleb128 .Ltmp12-.Lfunc_begin2          # >> Call Site 5 <<
	.uleb128 .Ltmp14-.Ltmp12                #   Call between .Ltmp12 and .Ltmp14
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp14-.Lfunc_begin2          # >> Call Site 6 <<
	.uleb128 .Ltmp15-.Ltmp14                #   Call between .Ltmp14 and .Ltmp15
	.uleb128 .Ltmp16-.Lfunc_begin2          #     jumps to .Ltmp16
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp17-.Lfunc_begin2          # >> Call Site 7 <<
	.uleb128 .Ltmp18-.Ltmp17                #   Call between .Ltmp17 and .Ltmp18
	.uleb128 .Ltmp19-.Lfunc_begin2          #     jumps to .Ltmp19
	.byte	1                               #   On action: 1
	.uleb128 .Ltmp18-.Lfunc_begin2          # >> Call Site 8 <<
	.uleb128 .Lfunc_end6-.Ltmp18            #   Call between .Ltmp18 and .Lfunc_end6
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
.Lcst_end2:
	.byte	1                               # >> Action Record 1 <<
                                        #   Catch TypeInfo 1
	.byte	0                               #   No further actions
	.p2align	2, 0x0
                                        # >> Catch TypeInfos <<
	.long	0                               # TypeInfo 1
.Lttbase0:
	.p2align	2, 0x0
                                        # -- End function
	.section	.text.__clang_call_terminate,"axG",@progbits,__clang_call_terminate,comdat
	.hidden	__clang_call_terminate          # -- Begin function __clang_call_terminate
	.weak	__clang_call_terminate
	.p2align	4, 0x90
	.type	__clang_call_terminate,@function
__clang_call_terminate:                 # @__clang_call_terminate
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	__cxa_begin_catch@PLT
	callq	_ZSt9terminatev@PLT
.Lfunc_end7:
	.size	__clang_call_terminate, .Lfunc_end7-__clang_call_terminate
	.cfi_endproc
                                        # -- End function
	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"cannot create std::vector larger than max_size()"
	.size	.L.str, 49

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"vector::_M_realloc_insert"
	.size	.L.str.1, 26

	.section	".linker-options","e",@llvm_linker_options
	.hidden	DW.ref.__gxx_personality_v0
	.weak	DW.ref.__gxx_personality_v0
	.section	.data.DW.ref.__gxx_personality_v0,"awG",@progbits,DW.ref.__gxx_personality_v0,comdat
	.p2align	3, 0x0
	.type	DW.ref.__gxx_personality_v0,@object
	.size	DW.ref.__gxx_personality_v0, 8
DW.ref.__gxx_personality_v0:
	.quad	__gxx_personality_v0
	.ident	"Ubuntu clang version 18.1.3 (1ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym __gxx_personality_v0
	.addrsig_sym _Unwind_Resume
